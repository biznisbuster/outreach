import { defineConfig } from "drizzle-kit";

const dbPath = process.env.DATABASE_URL?.replace("file:", "") || "/data/outreach.db";

export default defineConfig({
  schema: "./src/lib/db/schema.ts",
  out: "./drizzle",
  dialect: "sqlite",
  dbCredentials: {
    url: dbPath,
  },
  verbose: true,
  strict: true,
});
