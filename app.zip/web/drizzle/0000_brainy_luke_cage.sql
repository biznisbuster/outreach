CREATE TABLE `ai_chats` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`messages_json` text NOT NULL,
	`created_at` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `blocklist` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`reason` text,
	`created_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `campaigns` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`category` text,
	`city` text,
	`prompt_template_id` integer,
	`created_at` integer DEFAULT (unixepoch())
);
--> statement-breakpoint
CREATE TABLE `comments` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`body` text NOT NULL,
	`created_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `email_replies` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`email_send_id` integer,
	`from_email` text NOT NULL,
	`subject` text,
	`body` text,
	`received_at` integer NOT NULL,
	`matched_by` text,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`email_send_id`) REFERENCES `email_sends`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `email_sends` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`sender_id` integer,
	`sequence_step_id` integer,
	`prompt_template_id` integer,
	`subject` text NOT NULL,
	`body` text NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`generated_by_ai` integer DEFAULT false NOT NULL,
	`reviewed` integer DEFAULT false NOT NULL,
	`queued_at` integer,
	`sent_at` integer,
	`message_id` text,
	`error` text,
	`opened_count` integer DEFAULT 0 NOT NULL,
	`opened_first_at` integer,
	`clicked_count` integer DEFAULT 0 NOT NULL,
	`replied` integer DEFAULT false NOT NULL,
	`replied_at` integer,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`sender_id`) REFERENCES `senders`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`sequence_step_id`) REFERENCES `sequence_steps`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`prompt_template_id`) REFERENCES `prompt_templates`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`campaign_id` integer NOT NULL,
	`name` text NOT NULL,
	`category` text,
	`phone_raw` text,
	`phone_e164` text,
	`email` text,
	`website_raw` text,
	`website_normalized` text,
	`address` text,
	`city` text,
	`postal_code` text,
	`google_rating` real,
	`reviews_count` integer,
	`source` text,
	`source_url` text,
	`lat` real,
	`lng` real,
	`status_id` integer,
	`do_not_contact` integer DEFAULT false NOT NULL,
	`dedup_key` text NOT NULL,
	`imported_at` integer DEFAULT (unixepoch()),
	`import_batch_id` text,
	`created_at` integer DEFAULT (unixepoch()),
	`updated_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`status_id`) REFERENCES `statuses`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `leads_dedup_key_uq` ON `leads` (`dedup_key`);--> statement-breakpoint
CREATE INDEX `leads_campaign_id_idx` ON `leads` (`campaign_id`);--> statement-breakpoint
CREATE INDEX `leads_status_id_idx` ON `leads` (`status_id`);--> statement-breakpoint
CREATE INDEX `leads_email_idx` ON `leads` (`email`);--> statement-breakpoint
CREATE INDEX `leads_website_idx` ON `leads` (`website_normalized`);--> statement-breakpoint
CREATE TABLE `prompt_templates` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`type` text NOT NULL,
	`body` text NOT NULL,
	`is_default` integer DEFAULT false NOT NULL,
	`campaign_id` integer,
	`created_at` integer DEFAULT (unixepoch()),
	`updated_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `screenshots` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`path` text NOT NULL,
	`captured_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `senders` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`email` text NOT NULL,
	`from_name` text NOT NULL,
	`smtp_host` text NOT NULL,
	`smtp_port` integer NOT NULL,
	`username` text NOT NULL,
	`password_encrypted` text NOT NULL,
	`daily_cap` integer DEFAULT 50 NOT NULL,
	`hourly_cap` integer DEFAULT 10 NOT NULL,
	`min_delay_sec` integer DEFAULT 30 NOT NULL,
	`max_delay_sec` integer DEFAULT 120 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`last_used_at` integer
);
--> statement-breakpoint
CREATE TABLE `sequence_steps` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`sequence_id` integer NOT NULL,
	`step_number` integer NOT NULL,
	`prompt_template_id` integer,
	`delay_days` integer DEFAULT 0 NOT NULL,
	`send_window_only` integer DEFAULT true NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	FOREIGN KEY (`sequence_id`) REFERENCES `sequences`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`prompt_template_id`) REFERENCES `prompt_templates`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `sequences` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`campaign_id` integer NOT NULL,
	`name` text NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`campaign_id`) REFERENCES `campaigns`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`key` text PRIMARY KEY NOT NULL,
	`value` text
);
--> statement-breakpoint
CREATE TABLE `site_analysis` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`scrape_id` integer,
	`visual_score` integer,
	`visual_notes` text,
	`seo_score` integer,
	`total_pages` integer DEFAULT 0 NOT NULL,
	`total_words` integer DEFAULT 0 NOT NULL,
	`overall_score` real,
	`issues_json` text,
	`ai_summary` text,
	`analyzed_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`scrape_id`) REFERENCES `site_scrapes`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE TABLE `site_pages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`scrape_id` integer NOT NULL,
	`url` text NOT NULL,
	`category` text,
	`title` text,
	`meta_description` text,
	`h1` text,
	`word_count` integer DEFAULT 0 NOT NULL,
	`reading_time` integer DEFAULT 0 NOT NULL,
	`seo_metrics_json` text,
	`body_summary` text,
	`status_code` integer,
	`fetched_at` integer DEFAULT (unixepoch()),
	FOREIGN KEY (`scrape_id`) REFERENCES `site_scrapes`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `site_scrapes` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`lead_id` integer NOT NULL,
	`domain` text,
	`sitemap_url` text,
	`total_pages_discovered` integer DEFAULT 0 NOT NULL,
	`pages_scraped` integer DEFAULT 0 NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`started_at` integer,
	`finished_at` integer,
	`error` text,
	FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE TABLE `statuses` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`name` text NOT NULL,
	`color` text DEFAULT '#6b7280' NOT NULL,
	`is_terminal_won` integer DEFAULT false NOT NULL,
	`is_terminal_lost` integer DEFAULT false NOT NULL,
	`is_active` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`system_default` integer DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`password_hash` text NOT NULL,
	`created_at` integer DEFAULT (unixepoch())
);
