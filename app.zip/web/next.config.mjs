/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  serverExternalPackages: [
    "better-sqlite3",
    "nodemailer",
    "imapflow",
    "node-cron",
  ],
};

export default nextConfig;
