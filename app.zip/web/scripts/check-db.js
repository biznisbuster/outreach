const Database = require('better-sqlite3');
const db = new Database('/Users/marko/Documents/Outreach/data/outreach.db');
const tables = ['leads', 'campaigns', 'statuses', 'email_sends', 'senders'];
tables.forEach(t => {
  const c = db.prepare(`SELECT count(*) c FROM ${t}`).get();
  console.log(`${t}: ${c.c}`);
});
console.log('---leads---');
db.prepare('SELECT id, name, email, do_not_contact FROM leads').all().forEach(l => console.log(l));
console.log('---senders---');
db.prepare('SELECT id, email, active, last_used_at FROM senders').all().forEach(s => console.log(s));
console.log('---email_sends (last 5)---');
db.prepare('SELECT id, lead_id, subject, status, error, sent_at, sender_id FROM email_sends ORDER BY id DESC LIMIT 5').all().forEach(e => console.log(e));