export async function register() {
  // Inicijalizuj bazu + seed pri startu (samo server-side)
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const { getDb } = await import("@/lib/db");
    const { ensureSeed } = await import("@/lib/seed");
    try {
      getDb();
      await ensureSeed();
      console.log("[instrumentation] Baza spremna.");
    } catch (e) {
      console.error("[instrumentation] Greška pri inicijalizaciji baze:", e);
    }

    // Pokreni scheduler (slanje + IMAP polling) samo u produkciji / standalone / ako eksplicitno traženo
    const shouldStart =
      process.env.ENABLE_WORKER === "1" ||
      process.env.SCHEDULER_ENABLED === "1" ||
      process.env.NODE_ENV === "production" ||
      process.env.NEXT_RUNTIME !== "nodejs";
    if (shouldStart) {
      try {
        const { startScheduler } = await import("@/lib/workers/scheduler");
        startScheduler();
        console.log("[instrumentation] Scheduler pokrenut.");
      } catch (e) {
        console.error("[instrumentation] Scheduler nije pokrenut:", e);
      }
    }
  }
}
