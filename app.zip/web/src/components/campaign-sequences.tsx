"use client";

import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Mail } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface Step {
  id: number;
  sequenceId: number;
  stepNumber: number;
  delayDays: number;
  promptTemplateId: number | null;
  sendWindowOnly: boolean;
  active: boolean;
}
interface Sequence {
  id: number;
  name: string;
  active: boolean;
  steps: Step[];
}

export function CampaignSequences({ campaignId }: { campaignId: number }) {
  const [sequences, setSequences] = useState<Sequence[]>([]);
  const [newName, setNewName] = useState("");
  const [prompts, setPrompts] = useState<{ id: number; name: string }[]>([]);

  const load = useCallback(async () => {
    const [seqRes, promptRes] = await Promise.all([
      fetch(`/api/sequences?campaignId=${campaignId}`),
      fetch(`/api/prompts?type=email_personalization`),
    ]);
    setSequences(await seqRes.json());
    setPrompts(await promptRes.json());
  }, [campaignId]);

  useEffect(() => {
    load();
  }, [load]);

  async function createSequence() {
    if (!newName.trim()) return;
    const res = await fetch("/api/sequences", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ campaignId, name: newName }),
    });
    if (res.ok) {
      toast({ title: "Sekvenca kreirana" });
      setNewName("");
      load();
    }
  }

  async function addStep(seqId: number, currentSteps: Step[]) {
    const stepNumber = currentSteps.length > 0 ? Math.max(...currentSteps.map((s) => s.stepNumber)) + 1 : 1;
    const res = await fetch("/api/sequences/steps", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sequenceId: seqId, stepNumber, delayDays: 2, sendWindowOnly: true }),
    });
    if (res.ok) load();
  }

  async function deleteStep(stepId: number) {
    await fetch(`/api/sequences/steps/${stepId}`, { method: "DELETE" });
    load();
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Mail className="h-4 w-4" /> Sekvence (auto follow-up)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input placeholder="Naziv sekvence (npr. Follow-up 3 dana)" value={newName} onChange={(e) => setNewName(e.target.value)} />
          <Button onClick={createSequence}>
            <Plus className="h-4 w-4" /> Nova
          </Button>
        </div>

        {sequences.length === 0 ? (
          <p className="py-2 text-sm text-muted-foreground">Nema sekvenci. Kreiraj prvu da automatski šalje follow-up.</p>
        ) : (
          sequences.map((seq) => (
            <div key={seq.id} className="rounded-md border p-3">
              <div className="mb-2 flex items-center justify-between">
                <div>
                  <p className="font-medium">{seq.name}</p>
                  <Badge variant={seq.active ? "success" : "secondary"}>{seq.active ? "Aktivna" : "Pauzirana"}</Badge>
                </div>
                <Button size="sm" variant="outline" onClick={() => addStep(seq.id, seq.steps)}>
                  <Plus className="h-3.5 w-3.5" /> Korak
                </Button>
              </div>
              {seq.steps.length === 0 ? (
                <p className="text-xs text-muted-foreground">Nema koraka. Dodaj korak (prvi korak ide odmah, sledeći sa delay-om).</p>
              ) : (
                <ol className="space-y-1.5 text-sm">
                  {seq.steps.map((s) => (
                    <li key={s.id} className="flex items-center gap-2 rounded border bg-muted/40 px-2 py-1.5">
                      <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                        {s.stepNumber}
                      </span>
                      <span>
                        {s.delayDays === 0 ? "odmah" : `+ ${s.delayDays} dana`} nakon prethodnog
                      </span>
                      <span className="text-xs text-muted-foreground">· koristi prompt sekvence</span>
                      <Button size="icon" variant="ghost" className="ml-auto h-7 w-7" onClick={() => deleteStep(s.id)}>
                        <Trash2 className="h-3 w-3 text-destructive" />
                      </Button>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          ))
        )}
        <p className="text-xs text-muted-foreground">
          Kad se email iz sekvence pošalje, M3 generiše sledeći korak. Ako lead reply-uje, sekvenca se automatski stopira.
        </p>
      </CardContent>
    </Card>
  );
}