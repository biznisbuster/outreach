"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, Save, Sparkles, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export interface EmailDraft {
  id: number;
  subject: string;
  body: string;
  status: string;
  generatedByAi: boolean;
  reviewed: boolean;
  sentAt: number | null;
}

export function EmailDraftEditor({
  leadId,
  draft,
  onUpdate,
}: {
  leadId: number;
  draft: EmailDraft;
  onUpdate: () => void;
}) {
  const [subject, setSubject] = useState(draft.subject);
  const [body, setBody] = useState(draft.body);
  const [saving, setSaving] = useState(false);
  const [approving, setApproving] = useState(false);
  const [expanded, setExpanded] = useState(draft.status === "draft");

  async function save() {
    setSaving(true);
    const res = await fetch(`/api/email/drafts/${draft.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject, body }),
    });
    setSaving(false);
    if (res.ok) {
      toast({ title: "Sačuvano" });
      onUpdate();
    }
  }

  async function approve() {
    // prvo sačuvaj izmene
    await save();
    setApproving(true);
    const res = await fetch(`/api/email/drafts/${draft.id}/approve`, { method: "POST" });
    setApproving(false);
    if (res.ok) {
      toast({ title: "Odobreno", description: "Email je u redu za slanje." });
      onUpdate();
    } else {
      const data = await res.json().catch(() => ({}));
      toast({ variant: "destructive", title: "Greška", description: data.error || "Neuspelo odobravanje" });
    }
  }

  if (draft.status !== "draft") {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <div className="min-w-0 flex-1">
            <CardTitle className="truncate text-sm">{draft.subject}</CardTitle>
          </div>
          <Badge variant={draft.status === "sent" ? "success" : draft.status === "queued" ? "warning" : "secondary"}>
            {draft.status}
          </Badge>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <div className="flex items-center gap-2">
          {draft.generatedByAi && <Sparkles className="h-3.5 w-3.5 text-primary" />}
          <CardTitle className="text-sm">Draft email</CardTitle>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setExpanded(!expanded)}>
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </Button>
      </CardHeader>
      {expanded && (
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Subject</label>
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Body (plain text)</label>
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} className="min-h-[280px] font-mono text-sm" />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={save} disabled={saving}>
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Sačuvaj draft
            </Button>
            <Button size="sm" onClick={approve} disabled={approving}>
              {approving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
              Odobri i pošalji
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export function GenerateEmailButton({ leadId, onGenerated }: { leadId: number; onGenerated: () => void }) {
  const [loading, setLoading] = useState(false);
  async function generate() {
    setLoading(true);
    try {
      const res = await fetch("/api/email/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      toast({ title: "Draft generisan", description: "Pregledaj i odobri." });
      onGenerated();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setLoading(false);
    }
  }
  return (
    <Button
      size="sm"
      variant="outline"
      onClick={generate}
      disabled={loading}
      title="Koristi MiniMax M3 da personalizuje email na osnovu podataka o lead-u (kontekst, problem, CTA). Zamenjuje prazan draft sa AI generisanim tekstom."
    >
      {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
      {loading ? "Generišem…" : "AI: generiši email"}
    </Button>
  );
}