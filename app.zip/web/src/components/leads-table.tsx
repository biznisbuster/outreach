"use client";

import { useEffect, useState, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Loader2, Search, ChevronLeft, ChevronRight, Globe, Mail, Phone, Star, Settings2, ExternalLink, Ban, Trash2, Camera, Sparkles } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { shortDate } from "@/lib/utils";

export interface StatusOption {
  id: number;
  name: string;
  color: string;
  isTerminalWon: boolean;
  isTerminalLost: boolean;
}

interface LeadRow {
  lead: {
    id: number;
    name: string;
    email: string | null;
    phoneE164: string | null;
    websiteNormalized: string | null;
    city: string | null;
    googleRating: number | null;
    reviewsCount: number | null;
    doNotContact: boolean;
    createdAt: number | null;
    statusId: number | null;
  };
  statusName: string | null;
  statusColor: string | null;
  overallScore: number | null;
  visualScore: number | null;
  hasScreenshot?: number | null;
}

function ScoreBadge({ score }: { score: number | null }) {
  if (score === null || score === undefined) return <span className="text-xs text-muted-foreground">—</span>;
  const color = score >= 7 ? "success" : score >= 4 ? "warning" : "destructive";
  return <Badge variant={color as "success"}>{score.toFixed(1)}</Badge>;
}

export function LeadsTable({
  campaignId,
  statuses,
  cities: initialCities,
  maxHeight,
}: {
  campaignId: number;
  statuses: StatusOption[];
  cities: string[];
  maxHeight?: string;
}) {
  const [items, setItems] = useState<LeadRow[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [cities, setCities] = useState<string[]>(initialCities);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Set<number>>(new Set());

  // filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [cityFilter, setCityFilter] = useState<string>("all");
  const [hasEmail, setHasEmail] = useState(false);
  const [noWebsite, setNoWebsite] = useState(false);
  const [hasPhone, setHasPhone] = useState(false);
  const [lowScore, setLowScore] = useState(false);

  const debounceSearch = useDebounce(search, 400);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    params.set("campaignId", String(campaignId));
    params.set("page", String(page));
    params.set("pageSize", "100");
    if (debounceSearch) params.set("search", debounceSearch);
    if (statusFilter !== "all") params.set("statusId", statusFilter);
    if (cityFilter !== "all") params.set("city", cityFilter);
    if (hasEmail) params.set("hasEmail", "1");
    if (noWebsite) params.set("noWebsite", "1");
    if (hasPhone) params.set("hasPhone", "1");
    if (lowScore) params.set("lowScore", "1");
    const res = await fetch(`/api/leads?${params}`);
    const data = await res.json();
    setItems(data.items);
    setTotal(data.total);
    setTotalPages(data.totalPages);
    if (data.cities?.length) setCities(data.cities);
    setLoading(false);
    setSelected(new Set());
  }, [campaignId, page, debounceSearch, statusFilter, cityFilter, hasEmail, noWebsite, hasPhone, lowScore]);

  useEffect(() => {
    load();
  }, [load]);

  // Osveži podatke kada se korisnik vrati na tab/listu (npr. posle izmene
  // statusa na detail stranici) — Next ne radi automatski refetch.
  useEffect(() => {
    function onVisible() {
      if (document.visibilityState === "visible") load();
    }
    window.addEventListener("focus", load);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("focus", load);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [load]);

  async function changeStatusInline(leadId: number, statusId: number) {
    const res = await fetch(`/api/leads/${leadId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ statusId }),
    });
    if (res.ok) {
      // Optimistički lokalni update bez punog refetcha
      setItems((prev) =>
        prev.map((row) =>
          row.lead.id === leadId
            ? {
                ...row,
                lead: { ...row.lead, statusId },
                statusName: statuses.find((s) => s.id === statusId)?.name ?? row.statusName,
                statusColor: statuses.find((s) => s.id === statusId)?.color ?? row.statusColor,
              }
            : row,
        ),
      );
    } else {
      toast({ variant: "destructive", title: "Greška pri promeni statusa" });
    }
  }

  function toggleAll() {
    if (selected.size === items.length) setSelected(new Set());
    else setSelected(new Set(items.map((i) => i.lead.id)));
  }
  function toggleOne(id: number) {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  }

  async function bulkSetStatus(statusId: number) {
    const ids = [...selected];
    const res = await fetch("/api/leads/bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids, action: "setStatus", statusId }),
    });
    if (res.ok) {
      toast({ title: "Ažurirano", description: `${ids.length} leadova.` });
      load();
    }
  }

  async function bulkBlock() {
    const ids = [...selected];
    const res = await fetch("/api/leads/bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids, action: "blocklist", reason: "Bulk blokada" }),
    });
    if (res.ok) {
      toast({ title: "Blokirano", description: `${ids.length} leadova dodato u blocklist.` });
      load();
    }
  }

  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState("");
  // Bulk job tracking
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkJob, setBulkJob] = useState<{
    jobId: string;
    action: string;
    count: number;
    done: number;
    failed: number;
    current: number | null;
  } | null>(null);

  // Enrich progress (detaljniji od bulkJob-a jer je lead-by-lead)
  const [enrichProgress, setEnrichProgress] = useState<{
    total: number;
    done: number;
    updated: number;
    skipped: number;
    failed: number;
    currentName: string | null;
    currentId: number | null;
  } | null>(null);

  async function bulkDelete() {
    setDeleteConfirm("");
    setDeleteOpen(true);
  }

  async function confirmBulkDelete() {
    if (deleteConfirm !== "OBRIŠI") return;
    setDeleteOpen(false);
    const ids = [...selected];
    const res = await fetch("/api/leads/bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids, action: "delete" }),
    });
    if (res.ok) {
      toast({ title: "Obrisano", description: `${ids.length} leadova trajno obrisano.` });
      setSelected(new Set());
      load();
    } else {
      const data = await res.json().catch(() => ({}));
      toast({ variant: "destructive", title: "Greška pri brisanju", description: data.error });
    }
  }

  async function startBulkJob(action: "scrape" | "analyze", opts: { onlyWithoutScreenshot?: boolean; onlyWithoutAnalysis?: boolean } = {}) {
    if (bulkRunning) return;
    setBulkRunning(true);
    setBulkJob({ jobId: "", action, count: 0, done: 0, failed: 0, current: null });
    try {
      const body: Record<string, unknown> = {};
      if (selected.size > 0) {
        body.leadIds = [...selected];
      } else if (campaignId) {
        body.campaignId = campaignId;
        if (opts.onlyWithoutScreenshot) body.onlyWithoutScreenshot = true;
        if (opts.onlyWithoutAnalysis) body.onlyWithoutAnalysis = true;
      } else {
        toast({ variant: "destructive", title: "Selektuj leadove ili otvori kampanju" });
        setBulkRunning(false);
        return;
      }
      const res = await fetch("/api/leads/bulk-jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Bulk-Action": action },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      if (data.count === 0) {
        toast({ title: "Nema leadova za procesiranje" });
        setBulkRunning(false);
        return;
      }
      setBulkJob((b) => ({ ...b!, jobId: data.jobId, count: data.count }));
      toast({
        title: `${action === "scrape" ? "Scrape" : "Analyze"} pokrenut`,
        description: `${data.count} leadova. Prati progress u Activity panelu.`,
      });
      // poll status
      const poll = setInterval(async () => {
        try {
          const r = await fetch(`/api/leads/bulk-jobs/${data.jobId}`, { cache: "no-store" });
          if (!r.ok) return;
          const j = await r.json();
          setBulkJob((b) => ({ ...b!, done: j.done, failed: j.failed, current: j.current }));
          if (j.finishedAt) {
            clearInterval(poll);
            setBulkRunning(false);
            toast({
              title: `${action === "scrape" ? "Bulk scrape" : "Bulk analyze"} završen`,
              description: `${j.done} uspešno, ${j.failed} neuspešno od ukupno ${j.total}.`,
            });
            load();
          }
        } catch {}
      }, 2000);
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
      setBulkRunning(false);
    }
  }

  function bulkScrape(opts?: { onlyWithoutScreenshot?: boolean }) {
    return startBulkJob("scrape", opts);
  }
  function bulkAnalyze(opts?: { onlyWithoutAnalysis?: boolean }) {
    return startBulkJob("analyze", opts);
  }
  function bulkEnrich() {
    // Enrich je pojedinačno (preko scrape-leads) — za batch treba drugi endpoint.
    // Za sad šalji jedan-po-jedan. Server radi MERGE: puni samo prazna polja,
    // ne dira ručne izmene, statuse, komentare, email-ove.
    return enrichIds([...selected]);
  }

  /**
   * "Dopuni prazna polja iz Google Maps" — fetchuje sve leadove koji
   * odgovaraju trenutnom filteru, filtrira one sa praznim reviews_count/rating,
   * i pokreće enrich jedan-po-jedan. Server radi merge (ne briše ručne izmene).
   */
  async function enrichAllBlank() {
    if (bulkRunning) return;
    if (!campaignId) return;
    setBulkRunning(true);
    try {
      const params = new URLSearchParams();
      params.set("campaignId", String(campaignId));
      if (debounceSearch) params.set("search", debounceSearch);
      if (statusFilter !== "all") params.set("statusId", statusFilter);
      if (cityFilter !== "all") params.set("city", cityFilter);
      if (hasEmail) params.set("hasEmail", "1");
      if (noWebsite) params.set("noWebsite", "1");
      if (hasPhone) params.set("hasPhone", "1");
      if (lowScore) params.set("lowScore", "1");
      params.set("pageSize", "500");
      params.set("page", "1");
      const res = await fetch(`/api/leads?${params}`);
      const data = await res.json();
      const blank = (data.items || []).filter(
        (r: { lead: { reviewsCount: number | null; googleRating: number | null } }) =>
          r.lead.reviewsCount == null || r.lead.googleRating == null,
      );
      if (blank.length === 0) {
        toast({ title: "Nema leadova sa praznim reviews/rating", description: "Svi u trenutnom filteru već imaju Google podatke." });
        setBulkRunning(false);
        return;
      }
      const ids = blank.map((r: { lead: { id: number } }) => r.lead.id);
      await enrichIds(ids);
    } catch (e) {
      setBulkRunning(false);
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    }
  }

  async function enrichIds(ids: number[]) {
    if (ids.length === 0) {
      toast({ title: "Selektuj leadove za Enrich" });
      return;
    }
    setBulkRunning(true);
    let updated = 0;
    let skipped = 0;
    let failed = 0;
    setEnrichProgress({ total: ids.length, done: 0, updated: 0, skipped: 0, failed: 0, currentName: null, currentId: null });

    for (let i = 0; i < ids.length; i++) {
      const id = ids[i];
      // Učitaj ime leada za prikaz u progress baru
      const leadRow = items.find((it) => it.lead.id === id);
      const leadName = leadRow?.lead.name ?? `#${id}`;
      setEnrichProgress((p) => (p ? { ...p, currentId: id, currentName: leadName, done: i } : p));

      try {
        const r = await fetch(`/api/leads/${id}/enrich`, { method: "POST" });
        if (r.ok) {
          const j = await r.json();
          if (j.updated) updated++;
          else skipped++;
        } else {
          const errBody = await r.json().catch(() => ({}));
          // Ako je scraper nedostupan, odmah prekini — nema smisla nastaviti
          if (typeof errBody?.error === "string" && errBody.error.includes("nije dostupan")) {
            failed += ids.length - i;
            setEnrichProgress((p) => (p ? { ...p, failed, currentName: null, currentId: null } : p));
            toast({
              variant: "destructive",
              title: "Enrich prekinut",
              description: `Scrape-leads servis nedostupan posle ${i} leadova. Pokreni servis i pokušaj ponovo.`,
            });
            break;
          }
          failed++;
        }
      } catch {
        failed++;
      }
      setEnrichProgress((p) =>
        p ? { ...p, done: i + 1, updated, skipped, failed } : p,
      );
      await new Promise((r) => setTimeout(r, 1500));
    }
    setBulkRunning(false);
    setEnrichProgress(null);
    toast({
      title: "Enrich završen",
      description: `${updated} dopunjeno, ${skipped} bez Google Maps mesta, ${failed} grešaka (od ${ids.length}).`,
    });
    load();
  }

  const activeFilters = [hasEmail, noWebsite, hasPhone, lowScore].filter(Boolean).length;

  return (
    <div className={`flex flex-col overflow-hidden rounded-lg border bg-card ${maxHeight ? "" : "flex-1"}`} style={maxHeight ? { maxHeight } : undefined}>
      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-2 border-b bg-card px-4 py-3">
        <div className="relative min-w-[220px] flex-1">
          <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Pretraga (naziv, email, sajt, grad)..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="pl-8"
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setStatusFilter(v);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Svi statusi</SelectItem>
            <SelectItem value="null">Bez statusa</SelectItem>
            {statuses.map((s) => (
              <SelectItem key={s.id} value={String(s.id)}>
                {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {cities.length > 0 && (
          <Select
            value={cityFilter}
            onValueChange={(v) => {
              setCityFilter(v);
              setPage(1);
            }}
          >
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Grad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Svi gradovi</SelectItem>
              {cities.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant={hasEmail || noWebsite || hasPhone || lowScore ? "default" : "outline"} size="sm">
              <Settings2 className="h-4 w-4" />
              Filteri
              {activeFilters > 0 && <Badge className="ml-1">{activeFilters}</Badge>}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Brzi filteri</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <FilterCheck label="Ima email" checked={hasEmail} onChange={(v) => { setHasEmail(v); setPage(1); }} />
            <FilterCheck label="Nema website" checked={noWebsite} onChange={(v) => { setNoWebsite(v); setPage(1); }} />
            <FilterCheck label="Ima telefon" checked={hasPhone} onChange={(v) => { setHasPhone(v); setPage(1); }} />
            <FilterCheck label="Ocena sajta < 5" checked={lowScore} onChange={(v) => { setLowScore(v); setPage(1); }} />
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Bulk actions */}
      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 border-b bg-primary/5 px-4 py-2 text-sm">
          <span className="font-medium">{selected.size} selektovano</span>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Button variant="default" size="sm" onClick={() => bulkScrape()} disabled={bulkRunning}>
              {bulkRunning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
              Scrape
            </Button>
            <Button variant="default" size="sm" onClick={() => bulkAnalyze()} disabled={bulkRunning}>
              {bulkRunning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              Analiziraj (M3)
            </Button>
            <Button variant="outline" size="sm" onClick={() => bulkEnrich()} disabled={bulkRunning}>
              {bulkRunning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
              Enrich
            </Button>
            <div className="mx-1 h-5 w-px bg-border" />
            <Select onValueChange={(v) => bulkSetStatus(Number(v))}>
              <SelectTrigger className="h-8 w-[140px]">
                <SelectValue placeholder="Promeni status" />
              </SelectTrigger>
              <SelectContent>
                {statuses.map((s) => (
                  <SelectItem key={s.id} value={String(s.id)}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={bulkBlock}>
              <Ban className="h-3.5 w-3.5" />
              Blocklist
            </Button>
            <Button variant="destructive" size="sm" onClick={bulkDelete}>
              Obriši
            </Button>
          </div>
        </div>
      )}

      {/* Quick bulk actions — vidljive i kad NIŠTA nije selektovano */}
      {selected.size === 0 && campaignId && total > 0 && (
        <div className="flex flex-wrap items-center gap-2 border-b bg-muted/30 px-4 py-2 text-sm">
          <span className="text-muted-foreground">Brze akcije:</span>
          <Button variant="ghost" size="sm" onClick={() => bulkScrape({ onlyWithoutScreenshot: true })} disabled={bulkRunning}>
            <Camera className="h-3.5 w-3.5" /> Scrape sve bez screenshota
          </Button>
          <Button variant="ghost" size="sm" onClick={() => bulkAnalyze({ onlyWithoutAnalysis: true })} disabled={bulkRunning}>
            <Sparkles className="h-3.5 w-3.5" /> Analiziraj sve bez ocene
          </Button>
          <Button variant="ghost" size="sm" onClick={enrichAllBlank} disabled={bulkRunning} title="Dopuni prazna polja (reviews_count, google_rating) iz Google Maps. Ne dira ručne izmene.">
            <Search className="h-3.5 w-3.5" /> Dopuni prazna polja
          </Button>
        </div>
      )}

      {/* Enrich progress banner */}
      {enrichProgress && (
        <div className="border-b border-emerald-200 bg-emerald-50 px-4 py-3 text-sm">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
            <strong className="text-emerald-900">Enrich u toku</strong>
            <span className="tabular-nums text-emerald-800">
              {enrichProgress.done} / {enrichProgress.total}
              <span className="ml-2 text-emerald-700">
                · {enrichProgress.updated} dopunjeno · {enrichProgress.skipped} bez mesta · {enrichProgress.failed} grešaka
              </span>
            </span>
            {enrichProgress.currentName && (
              <span className="ml-auto truncate text-xs text-emerald-700" title={`Lead #${enrichProgress.currentId}`}>
                Trenutno: <strong>{enrichProgress.currentName}</strong>
              </span>
            )}
          </div>
          <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-emerald-100">
            <div
              className="h-full bg-emerald-600 transition-all duration-200"
              style={{ width: `${(enrichProgress.done / Math.max(enrichProgress.total, 1)) * 100}%` }}
            />
          </div>
          <p className="mt-1 text-xs text-emerald-700">
            ~{(enrichProgress.total - enrichProgress.done) * 1.5}s preostalo · ne zatvaraj ovu stranicu
          </p>
        </div>
      )}

      {/* Bulk progress banner */}
      {bulkJob && bulkJob.jobId && (
        <div className="border-b border-blue-200 bg-blue-50 px-4 py-2 text-sm">
          <div className="flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
            <strong className="text-blue-900">
              Bulk {bulkJob.action === "scrape" ? "scrape" : "analyze"} u toku
            </strong>
            <span className="text-blue-700">
              {bulkJob.done + bulkJob.failed} / {bulkJob.count} (neuspešno: {bulkJob.failed})
            </span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-blue-100">
            <div
              className="h-full bg-blue-600 transition-all"
              style={{ width: `${((bulkJob.done + bulkJob.failed) / Math.max(bulkJob.count, 1)) * 100}%` }}
            />
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        {loading ? (
          <div className="flex h-40 items-center justify-center text-muted-foreground">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Učitavanje...
          </div>
        ) : items.length === 0 ? (
          <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
            Nema leadova koji odgovaraju filterima.
          </div>
        ) : (
          <Table>
            <TableHeader className="sticky top-0 bg-card">
              <TableRow>
                <TableHead className="w-10">
                  <Checkbox checked={selected.size === items.length && items.length > 0} onCheckedChange={toggleAll} />
                </TableHead>
                <TableHead>Naziv</TableHead>
                <TableHead className="w-24">Status</TableHead>
                <TableHead className="w-12 text-center" title="Screenshot">📷</TableHead>
                <TableHead className="w-16 text-center" title="M3 ocena">M3</TableHead>
                <TableHead className="w-24">Kontakt</TableHead>
                <TableHead className="w-28">Grad</TableHead>
                <TableHead className="w-24">Google</TableHead>
                <TableHead className="w-24">Uneto</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((row) => (
                <TableRow
                  key={row.lead.id}
                  data-state={selected.has(row.lead.id) ? "selected" : undefined}
                  className="cursor-pointer"
                  onClick={(e) => {
                    if ((e.target as HTMLElement).closest("[data-stop]")) return;
                    window.location.href = `/leads/${row.lead.id}`;
                  }}
                >
                  <TableCell data-stop onClick={() => toggleOne(row.lead.id)}>
                    <Checkbox checked={selected.has(row.lead.id)} onCheckedChange={() => toggleOne(row.lead.id)} />
                  </TableCell>
                  <TableCell className="max-w-[260px]">
                    <div className="flex items-center gap-2">
                      <span className="truncate font-medium">{row.lead.name}</span>
                      {row.lead.doNotContact && (
                        <Badge variant="destructive" className="shrink-0">
                          DNC
                        </Badge>
                      )}
                    </div>
                    {row.lead.websiteNormalized && (
                      <a
                        data-stop
                        href={`https://${row.lead.websiteNormalized}`}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"
                      >
                        <Globe className="h-3 w-3" />
                        {row.lead.websiteNormalized}
                        <ExternalLink className="h-2.5 w-2.5" />
                      </a>
                    )}
                  </TableCell>
                  <TableCell data-stop onClick={(e) => e.stopPropagation()}>
                    <Select
                      value={row.lead.statusId ? String(row.lead.statusId) : "null"}
                      onValueChange={(v) => changeStatusInline(row.lead.id, Number(v))}
                    >
                      <SelectTrigger className="h-7 w-[120px] border-dashed text-xs">
                        <SelectValue placeholder="—" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="null">Bez statusa</SelectItem>
                        {statuses.map((s) => (
                          <SelectItem key={s.id} value={String(s.id)}>
                            <span className="mr-1.5 inline-block h-2 w-2 rounded-full" style={{ background: s.color }} />
                            {s.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-center">
                    {row.hasScreenshot ? (
                      <span title="Ima screenshot" className="inline-block h-2.5 w-2.5 rounded-full bg-green-500" />
                    ) : (
                      <span title="Nema screenshot" className="inline-block h-2.5 w-2.5 rounded-full border border-amber-300" />
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <ScoreBadge score={row.overallScore} />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {row.lead.email && <Mail className="h-3.5 w-3.5 text-green-600" />}
                      {row.lead.phoneE164 && <Phone className="h-3.5 w-3.5 text-blue-600" />}
                      {!row.lead.email && !row.lead.phoneE164 && <span className="text-xs text-muted-foreground">—</span>}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{row.lead.city || "—"}</TableCell>
                  <TableCell>
                    {row.lead.googleRating ? (
                      <div className="flex items-center gap-1 text-sm">
                        <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                        {row.lead.googleRating.toFixed(1)}
                        <span className="text-xs text-muted-foreground">({row.lead.reviewsCount ?? 0})</span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{shortDate(row.lead.createdAt)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between border-t bg-card px-4 py-2 text-sm text-muted-foreground">
        <span>
          {total} leadova {selected.size > 0 && `· ${selected.size} selektovano`}
        </span>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" disabled={page <= 1} onClick={() => setPage(page - 1)}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="tabular-nums">
            {page} / {totalPages}
          </span>
          <Button variant="outline" size="icon" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-700">Obriši {selected.size} leadova</DialogTitle>
            <DialogDescription>
              Ova akcija je <strong>trajna</strong>. Leadovi će biti obrisani zajedno sa svim komentarima,
              emailovima, scrapeovima i analizama.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-md bg-red-50 p-3 text-sm text-red-800">
              <strong>Da potvrdiš</strong>, ukucaj <code className="rounded bg-white px-1.5 py-0.5 font-mono font-bold">OBRIŠI</code> ispod:
            </div>
            <Input
              value={deleteConfirm}
              onChange={(e) => setDeleteConfirm(e.target.value)}
              placeholder="OBRIŠI"
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              Otkaži
            </Button>
            <Button variant="destructive" onClick={confirmBulkDelete} disabled={deleteConfirm !== "OBRIŠI"}>
              <Trash2 className="h-4 w-4" />
              Obriši trajno
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FilterCheck({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex cursor-pointer select-none items-center gap-2 px-2 py-1.5 text-sm hover:bg-accent">
      <Checkbox checked={checked} onCheckedChange={onChange} />
      {label}
    </label>
  );
}

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}
