import { getDb, schema } from "@/lib/db";
import { and, eq, sql, desc, asc } from "drizzle-orm";

/**
 * AI alati za function calling. Svaki prima args, vraća JSON-serializable rezultat.
 */

export async function queryLeads(args: {
  status?: string;
  campaign?: string;
  noReplyDays?: number;
  lowScore?: boolean;
  noWebsite?: boolean;
  noEmail?: boolean;
  city?: string;
  limit?: number;
}) {
  const db = getDb();
  const conds: ReturnType<typeof eq>[] = [];
  if (args.status) {
    const [s] = db.select().from(schema.statuses).where(eq(schema.statuses.name, args.status)).limit(1).all();
    if (s) conds.push(eq(schema.leads.statusId, s.id));
  }
  if (args.campaign) {
    const [c] = db.select().from(schema.campaigns).where(eq(schema.campaigns.name, args.campaign)).limit(1).all();
    if (c) conds.push(eq(schema.leads.campaignId, c.id));
  }
  if (args.noWebsite) conds.push(sql`${schema.leads.websiteNormalized} IS NULL`);
  if (args.noEmail) conds.push(sql`${schema.leads.email} IS NULL OR ${schema.leads.email} = ''`);
  if (args.city) conds.push(eq(schema.leads.city, args.city));
  if (args.lowScore) {
    conds.push(
      sql`EXISTS (SELECT 1 FROM site_analysis sa WHERE sa.lead_id = ${schema.leads.id} AND sa.overall_score < 5)`,
    );
  }
  if (args.noReplyDays) {
    const since = Date.now() - args.noReplyDays * 24 * 60 * 60 * 1000;
    // nema sent email u poslednjih X dana, ILI nema reply na poslednji sent
    conds.push(
      sql`(
        NOT EXISTS (SELECT 1 FROM email_sends e WHERE e.lead_id = ${schema.leads.id} AND e.status = 'sent' AND e.sent_at > ${since})
        OR EXISTS (
          SELECT 1 FROM email_sends e WHERE e.lead_id = ${schema.leads.id} AND e.status = 'sent' AND e.sent_at > ${since} AND e.replied = 0
        )
      )`,
    );
  }
  const where = conds.length ? and(...conds) : undefined;
  const limit = Math.min(args.limit || 20, 100);
  const rows = db
    .select({
      id: schema.leads.id,
      name: schema.leads.name,
      email: schema.leads.email,
      city: schema.leads.city,
      website: schema.leads.websiteNormalized,
      status: schema.statuses.name,
      overallScore: schema.siteAnalysis.overallScore,
    })
    .from(schema.leads)
    .leftJoin(schema.statuses, eq(schema.leads.statusId, schema.statuses.id))
    .leftJoin(schema.siteAnalysis, eq(schema.siteAnalysis.leadId, schema.leads.id))
    .where(where)
    .limit(limit)
    .all();
  return { count: rows.length, items: rows };
}

export async function summarizeLead(args: { leadId: number }) {
  const db = getDb();
  const [lead] = db.select().from(schema.leads).where(eq(schema.leads.id, args.leadId)).all();
  if (!lead) return { error: "Lead ne postoji" };
  const analysis = db
    .select()
    .from(schema.siteAnalysis)
    .where(eq(schema.siteAnalysis.leadId, args.leadId))
    .orderBy(desc(schema.siteAnalysis.analyzedAt))
    .limit(1)
    .all()[0];
  const comments = db
    .select({ body: schema.comments.body, at: schema.comments.createdAt })
    .from(schema.comments)
    .where(eq(schema.comments.leadId, args.leadId))
    .orderBy(desc(schema.comments.createdAt))
    .limit(5)
    .all();
  const emails = db
    .select({ id: schema.emailSends.id, subject: schema.emailSends.subject, status: schema.emailSends.status, sentAt: schema.emailSends.sentAt, replied: schema.emailSends.replied })
    .from(schema.emailSends)
    .where(eq(schema.emailSends.leadId, args.leadId))
    .orderBy(desc(schema.emailSends.queuedAt))
    .limit(10)
    .all();
  return { lead, analysis, comments, emails };
}

export async function getTodayTodos() {
  const db = getDb();
  // follow-up due = sent_at + 3 dana, bez reply-ja
  const threeDaysAgo = Date.now() - 3 * 24 * 60 * 60 * 1000;
  const followUps = db
    .select({ id: schema.leads.id, name: schema.leads.name, email: schema.leads.email, city: schema.leads.city })
    .from(schema.leads)
    .where(
      sql`EXISTS (
        SELECT 1 FROM email_sends e
        WHERE e.lead_id = ${schema.leads.id}
          AND e.status = 'sent'
          AND e.replied = 0
          AND e.sent_at < ${threeDaysAgo}
          AND e.sent_at > ${threeDaysAgo - 5 * 24 * 60 * 60 * 1000}
      )`,
    )
    .limit(20)
    .all();
  // drafts čekaju pregled
  const drafts = db
    .select({ id: schema.leads.id, name: schema.leads.name })
    .from(schema.leads)
    .where(
      sql`EXISTS (SELECT 1 FROM email_sends e WHERE e.lead_id = ${schema.leads.id} AND e.status = 'draft')`,
    )
    .limit(20)
    .all();
  return {
    follow_ups: followUps,
    drafts_pending: drafts,
  };
}

export async function getNoReplyLeads(args: { days: number }) {
  const since = Date.now() - args.days * 24 * 60 * 60 * 1000;
  const db = getDb();
  const rows = db
    .select({
      id: schema.leads.id,
      name: schema.leads.name,
      email: schema.leads.email,
      city: schema.leads.city,
      lastSent: sql<number>`(SELECT MAX(sent_at) FROM email_sends WHERE lead_id = ${schema.leads.id} AND status = 'sent')`,
    })
    .from(schema.leads)
    .where(
      sql`EXISTS (
        SELECT 1 FROM email_sends e WHERE e.lead_id = ${schema.leads.id} AND e.status = 'sent' AND e.replied = 0 AND e.sent_at > ${since}
      ) AND NOT EXISTS (
        SELECT 1 FROM email_sends e2 WHERE e2.lead_id = ${schema.leads.id} AND e2.replied = 1
      )`,
    )
    .limit(50)
    .all();
  return { count: rows.length, items: rows };
}

export async function getTopWorstSites(args: { n: number; order?: "worst" | "best" }) {
  const db = getDb();
  const dir = args.order === "best" ? desc(schema.siteAnalysis.overallScore) : asc(schema.siteAnalysis.overallScore);
  const rows = db
    .select({
      leadId: schema.siteAnalysis.leadId,
      leadName: schema.leads.name,
      website: schema.leads.websiteNormalized,
      overallScore: schema.siteAnalysis.overallScore,
      visualScore: schema.siteAnalysis.visualScore,
      seoScore: schema.siteAnalysis.seoScore,
    })
    .from(schema.siteAnalysis)
    .innerJoin(schema.leads, eq(schema.leads.id, schema.siteAnalysis.leadId))
    .orderBy(dir)
    .limit(args.n || 5)
    .all();
  return rows;
}

export const TOOLS = [
  {
    type: "function" as const,
    function: {
      name: "queryLeads",
      description: "Filtrira leadove po statusu, kampanji, gradu, da li imaju website/email, da li je ocena sajta <5, ili da nema reply-ja X dana. Vraća listu.",
      parameters: {
        type: "object",
        properties: {
          status: { type: "string", description: "Naziv statusa (npr. Novi, Zovem)" },
          campaign: { type: "string", description: "Naziv kampanje" },
          city: { type: "string" },
          noWebsite: { type: "boolean" },
          noEmail: { type: "boolean" },
          lowScore: { type: "boolean", description: "Ocena sajta < 5" },
          noReplyDays: { type: "number", description: "Leadovi koji nisu reply-ovali u poslednjih X dana" },
          limit: { type: "number" },
        },
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "summarizeLead",
      description: "Vraća detaljan pregled jednog leada: kontakt, analizu sajta, komentare, email aktivnost.",
      parameters: {
        type: "object",
        properties: { leadId: { type: "number" } },
        required: ["leadId"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "getTodayTodos",
      description: "Vraća listu leadova koji treba da se follow-up-uju danas (poslato pre 3+ dana bez reply-ja) + draft emailove koji čekaju pregled.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "getNoReplyLeads",
      description: "Vraća leadove koji su imali poslate emailove u poslednjih X dana, ali nijedan reply.",
      parameters: {
        type: "object",
        properties: { days: { type: "number" } },
        required: ["days"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "getTopWorstSites",
      description: "Vraća Top N sajtova sa najgorim (ili najboljim) ocenama.",
      parameters: {
        type: "object",
        properties: { n: { type: "number" }, order: { type: "string", enum: ["worst", "best"] } },
        required: ["n"],
      },
    },
  },
];

export async function executeTool(name: string, argsJson: string): Promise<string> {
  let args: Record<string, unknown> = {};
  try {
    args = argsJson ? JSON.parse(argsJson) : {};
  } catch {}
  try {
    let result: unknown;
    switch (name) {
      case "queryLeads":
        result = await queryLeads(args as Parameters<typeof queryLeads>[0]);
        break;
      case "summarizeLead":
        result = await summarizeLead(args as Parameters<typeof summarizeLead>[0]);
        break;
      case "getTodayTodos":
        result = await getTodayTodos();
        break;
      case "getNoReplyLeads":
        result = await getNoReplyLeads(args as Parameters<typeof getNoReplyLeads>[0]);
        break;
      case "getTopWorstSites":
        result = await getTopWorstSites(args as Parameters<typeof getTopWorstSites>[0]);
        break;
      default:
        result = { error: `Nepoznat alat: ${name}` };
    }
    return JSON.stringify(result, null, 2);
  } catch (e) {
    return JSON.stringify({ error: e instanceof Error ? e.message : String(e) });
  }
}