import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { verifyPassword, ensureSeed } from "./seed";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: { signIn: "/login" },
  providers: [
    CredentialsProvider({
      name: "Šifra",
      credentials: {
        password: { label: "Šifra", type: "password" },
      },
      async authorize(credentials) {
        await ensureSeed().catch((e) => console.error("[auth] seed greška:", e));
        const password = credentials?.password;
        if (!password) return null;
        const ok = await verifyPassword(password).catch((e) => {
          console.error("[auth] verify greška:", e);
          return false;
        });
        if (!ok) return null;
        return { id: "1", name: "Marko", email: "marko@local" };
      },
    }),
  ],
  callbacks: {
    async jwt({ token }) {
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as { id?: string }).id = token.sub || "1";
      }
      return session;
    },
  },
  secret: process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET,
};
