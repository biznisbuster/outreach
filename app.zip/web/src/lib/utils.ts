import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return new Intl.NumberFormat("sr-RS").format(n);
}

/**
 * Konvertuje ulaz (Date | number | string | null | undefined) u validan Date ili null.
 * Drizzle serializuje Date u ISO string preko JSON-a, pa klijent dobija string.
 * Intl.DateTimeFormat.format() baca "not finite" ako prosledimo nevalidan/NaN datum.
 */
function toValidDate(d: Date | number | string | null | undefined): Date | null {
  if (d === null || d === undefined || d === "") return null;
  if (typeof d === "string") {
    const parsed = new Date(d);
    return isFinite(parsed.getTime()) ? parsed : null;
  }
  if (typeof d === "number") {
    if (!isFinite(d)) return null;
    const parsed = new Date(d);
    return isFinite(parsed.getTime()) ? parsed : null;
  }
  // Date objekat
  return isFinite(d.getTime()) ? d : null;
}

export function formatDate(d: Date | number | string | null | undefined): string {
  const date = toValidDate(d);
  if (!date) return "—";
  return new Intl.DateTimeFormat("sr-RS", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function shortDate(d: Date | number | string | null | undefined): string {
  const date = toValidDate(d);
  if (!date) return "—";
  return new Intl.DateTimeFormat("sr-RS", { day: "2-digit", month: "2-digit", year: "numeric" }).format(date);
}

export function timeAgo(d: Date | number | string | null | undefined): string {
  const date = toValidDate(d);
  if (!date) return "nikad";
  const diff = Date.now() - date.getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return "sada";
  if (min < 60) return `pre ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `pre ${h} č`;
  const days = Math.floor(h / 24);
  if (days < 30) return `pre ${days} d`;
  const months = Math.floor(days / 30);
  if (months < 12) return `pre ${months} mes`;
  return `pre ${Math.floor(months / 12)} god`;
}