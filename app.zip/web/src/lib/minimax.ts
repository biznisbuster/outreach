import OpenAI from "openai";
import { getSetting } from "./settings";

export interface MinimaxConfig {
  apiKey: string;
  baseURL: string;
  model: string;
}

export function getMinimaxConfig(): MinimaxConfig {
  return {
    apiKey: getSetting("minimax_api_key"),
    baseURL: getSetting("minimax_base_url"),
    model: getSetting("minimax_model"),
  };
}

export function isMinimaxConfigured(): boolean {
  const apiKey = getSetting("minimax_api_key");
  return Boolean(apiKey);
}

/** Vraća OpenAI-kompatibilan klijent za MiniMax M3. */
export function getMinimaxClient(): OpenAI {
  const cfg = getMinimaxConfig();
  return new OpenAI({
    apiKey: cfg.apiKey,
    baseURL: cfg.baseURL,
  });
}

/** Test ping — jednostavan poziv koji vraća OK/grešku. */
export async function pingMinimax(): Promise<{ ok: boolean; message: string }> {
  if (!isMinimaxConfigured()) {
    return { ok: false, message: "MINIMAX_API_KEY nije podešen u env." };
  }
  try {
    const client = getMinimaxClient();
    const cfg = getMinimaxConfig();
    const res = await client.chat.completions.create({
      model: cfg.model,
      messages: [
        { role: "system", content: "Odgovori samo rečju: OK" },
        { role: "user", content: "ping" },
      ],
      max_tokens: 10,
      temperature: 0,
    });
    const text = res.choices?.[0]?.message?.content?.trim() || "(prazan odgovor)";
    return { ok: true, message: `M3 odgovorio: ${text}` };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    return { ok: false, message: `Greška: ${msg}` };
  }
}

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
  name?: string;
}

/** Jednostavan tekst completion (ne-JSON). */
export async function completeText(
  systemPrompt: string,
  userPrompt: string,
  opts: { temperature?: number; maxTokens?: number } = {},
): Promise<string> {
  const client = getMinimaxClient();
  const cfg = getMinimaxConfig();
  const res = await client.chat.completions.create({
    model: cfg.model,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    temperature: opts.temperature ?? 0.7,
    max_tokens: opts.maxTokens ?? 1200,
  });
  return res.choices?.[0]?.message?.content?.trim() || "";
}

/**
 * Poziv koji zahteva JSON output. Parsuje i retry-uje jednom ako padne.
 */
export async function completeJson<T = unknown>(
  systemPrompt: string,
  userPrompt: string,
  opts: { temperature?: number; maxTokens?: number } = {},
): Promise<T> {
  const sys =
    systemPrompt +
    "\n\nVAŽNO: Odgovori ISKLJUČIVO važećim JSON-om, bez markdown blokova (bez ```json) i bez dodatnog teksta.";
  const raw = await completeText(sys, userPrompt, { temperature: opts.temperature ?? 0.2, ...opts });
  return parseJsonLenient<T>(raw);
}

export function parseJsonLenient<T = unknown>(raw: string): T {
  let txt = raw.trim();
  // 1) skini <think>...</think> ako ga ima
  const thinkClose = txt.lastIndexOf("</think>");
  if (thinkClose >= 0) txt = txt.slice(thinkClose + "</think>".length).trim();
  // 2) skini markdown code fence ```json ... ```
  const fence = txt.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) txt = fence[1].trim();
  // 3) nađi prvu { ili [ i poslednju } ili ]
  const firstBrace = txt.search(/[{[]/);
  if (firstBrace > 0) txt = txt.slice(firstBrace);
  const lastClose = Math.max(txt.lastIndexOf("}"), txt.lastIndexOf("]"));
  if (lastClose >= 0) txt = txt.slice(0, lastClose + 1);
  return JSON.parse(txt) as T;
}

/**
 * Vision poziv — za vizuelnu ocenu screenshot-a.
 * @param imageUrl apsolutna putanja do fajla (file://) ili http(s) URL ili base64 data URL
 */
export async function completeVision(
  systemPrompt: string,
  userPrompt: string,
  imageUrl: string,
  opts: { temperature?: number; maxTokens?: number } = {},
): Promise<string> {
  const client = getMinimaxClient();
  const cfg = getMinimaxConfig();
  const res = await client.chat.completions.create({
    model: cfg.model,
    messages: [
      { role: "system", content: systemPrompt },
      {
        role: "user",
        content: [
          { type: "text", text: userPrompt },
          { type: "image_url", image_url: { url: imageUrl } },
        ],
      },
    ],
    temperature: opts.temperature ?? 0.2,
    max_tokens: opts.maxTokens ?? 800,
  });
  return res.choices?.[0]?.message?.content?.trim() || "";
}
