import { getDb, schema } from "./db";
import { DEFAULT_PROMPTS, DEFAULT_STATUSES } from "./prompts";
import { eq, and } from "drizzle-orm";
import bcrypt from "bcryptjs";

let seeded = false;

/**
 * Idempotent seed: default statusi, default promptovi, i single-user ako ne postoji.
 * Poziva se pri startu app-a (instrumentation) i pri login stranici.
 */
export async function ensureSeed() {
  if (seeded) return;
  const db = getDb();

  // 1) Statusi
  const existingStatuses = db.select().from(schema.statuses).all();
  if (existingStatuses.length === 0) {
    for (const s of DEFAULT_STATUSES) {
      db.insert(schema.statuses)
        .values({
          name: s.name,
          color: s.color,
          isTerminalWon: s.isTerminalWon,
          isTerminalLost: s.isTerminalLost,
          isActive: true,
          sortOrder: s.sortOrder,
          systemDefault: s.systemDefault,
        })
        .run();
    }
    console.log("[seed] Uneseni default statusi.");
  }

  // 2) Promptovi
  for (const p of DEFAULT_PROMPTS) {
    const exists = db
      .select()
      .from(schema.promptTemplates)
      .where(and(eq(schema.promptTemplates.type, p.type), eq(schema.promptTemplates.isDefault, true)))
      .all();
    if (exists.length === 0) {
      db.insert(schema.promptTemplates)
        .values({
          name: p.name,
          type: p.type,
          body: p.body,
          isDefault: true,
        })
        .run();
    }
  }

  // 3) Single-user — kreiraj iz AUTH_PASSWORD (plain) ili AUTH_PASSWORD_HASH (bcrypt).
  // AUTH_PASSWORD je pogodniji za .env jer nema $ koji se escape-uju.
  const existingUsers = db.select().from(schema.users).all();
  if (existingUsers.length === 0) {
    const plain = process.env.AUTH_PASSWORD;
    const hash = process.env.AUTH_PASSWORD_HASH;
    let passwordHash: string | null = null;
    if (plain && plain.length > 0) {
      passwordHash = await bcrypt.hash(plain, 10);
      console.log("[seed] Kreiran default single-user iz AUTH_PASSWORD.");
    } else if (hash && !hash.startsWith("replace")) {
      passwordHash = hash;
      console.log("[seed] Kreiran default single-user iz AUTH_PASSWORD_HASH.");
    }
    if (passwordHash) {
      db.insert(schema.users).values({ passwordHash }).run();
    }
  }

  seeded = true;
}

/** Proveri šifru protiv jedinog korisnika u bazi. */
export async function verifyPassword(password: string): Promise<boolean> {
  const db = getDb();
  const user = db.select().from(schema.users).all()[0];
  if (!user) return false;
  return bcrypt.compare(password, user.passwordHash);
}
