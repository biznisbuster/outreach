import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function requireSession() {
  const session = await getServerSession(authOptions);
  return session;
}

export function unauthorized() {
  return NextResponse.json({ error: "Nije dozvoljeno" }, { status: 401 });
}

export function ok(data: unknown, status = 200) {
  return NextResponse.json(data, { status });
}

export function bad(msg: string) {
  return NextResponse.json({ error: msg }, { status: 400 });
}

export function notFound(msg = "Nije pronađeno") {
  return NextResponse.json({ error: msg }, { status: 404 });
}

/** Čita numeričke query parametre. */
export function qpInt(v: string | null, def: number): number {
  if (v === null || v === "") return def;
  const n = parseInt(v, 10);
  return Number.isNaN(n) ? def : n;
}
