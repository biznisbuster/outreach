import crypto from "node:crypto";

const ALGO = "aes-256-gcm";

function getKey(): Buffer {
  const hex = process.env.ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error(
      "ENCRYPTION_KEY mora biti 32 bajta (64 hex karaktera). Generiši: openssl rand -hex 32",
    );
  }
  return Buffer.from(hex, "hex");
}

/** Enkriptuj plaintext → "v1:iv:tag:ciphertext" (sve hex). */
export function encrypt(plaintext: string): string {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("hex")}:${tag.toString("hex")}:${enc.toString("hex")}`;
}

/** Dekriptuj vrednost koju je napravio encrypt(). */
export function decrypt(payload: string): string {
  const parts = payload.split(":");
  if (parts.length !== 4 || parts[0] !== "v1") {
    throw new Error("Nevažeći enkriptovani payload");
  }
  const [, ivHex, tagHex, dataHex] = parts;
  const key = getKey();
  const decipher = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(tagHex, "hex"));
  const dec = Buffer.concat([decipher.update(Buffer.from(dataHex, "hex")), decipher.final()]);
  return dec.toString("utf8");
}

/** HMAC token za unsubscribe (ne zahteva auth). */
export function signHmac(data: string): string {
  const key = getKey();
  return crypto.createHmac("sha256", key).update(data).digest("hex");
}

export function verifyHmac(data: string, token: string): boolean {
  const expected = signHmac(data);
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(token));
  } catch {
    return false;
  }
}
