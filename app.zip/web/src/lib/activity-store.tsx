/**
 * Globalni store za praćenje aktivnih background poslova.
 *
 * Zašto custom store:
 *  - `toast()` se zamenjuje jedan drugim (shadcn TOAST_LIMIT=3)
 *  - korisnik treba da vidi SVE paralelne procese (auto-screenshot, scrape, analyze)
 *  - persistuje se u localStorage da preživi navigaciju
 *
 * Koristi se iz:
 *  - scrape-dialog.tsx (kreira scrape jobs)
 *  - leads/[id]/page.tsx (auto-screenshot + analyze)
 *  - app/layout.tsx (renderuje ActivityPanel)
 */
"use client";

import { useEffect, useState, useCallback, useRef } from "react";

export type ActivityKind =
  | "scrape_leads"
  | "lead_scrape"
  | "lead_analyze"
  | "lead_enrich";

export type ActivityStatus = "queued" | "running" | "done" | "failed" | "cancelled";

export interface ActivityItem {
  id: string;
  kind: ActivityKind;
  label: string;
  detail?: string;
  status: ActivityStatus;
  startedAt: number;
  finishedAt?: number;
  /** Broj izvršenih koraka (npr. 4/6 biznisa) */
  count?: number;
  /** Očekivani ukupan broj */
  total?: number;
  /** Poslednji poznati stage (search, detail, email, ...) */
  stage?: string;
  /** Ljudski čitljiva poruka poslednjeg eventa */
  message?: string;
  /** HTTP endpoint za status polling (relativan URL) */
  pollUrl?: string;
  /** Meta podaci za link nazad (npr. leadId, campaignId) */
  meta?: Record<string, unknown>;
}

const LS_KEY = "outreach-activity-v1";

type Listener = (items: ActivityItem[]) => void;
let _items: ActivityItem[] = [];
const _listeners = new Set<Listener>();

function notify() {
  for (const l of _listeners) l(_items);
}

function persist() {
  if (typeof window === "undefined") return;
  try {
    // Čuvamo samo ne-završene da ne zatrpanimo LS
    const open = _items.filter((i) => i.status === "queued" || i.status === "running");
    localStorage.setItem(LS_KEY, JSON.stringify(open));
  } catch {}
}

export function listActivities(): ActivityItem[] {
  return _items;
}

export function subscribeActivities(l: Listener): () => void {
  _listeners.add(l);
  l(_items);
  return () => {
    _listeners.delete(l);
  };
}

export function addActivity(item: Omit<ActivityItem, "startedAt" | "status"> & { status?: ActivityStatus }): ActivityItem {
  const full: ActivityItem = { ...item, startedAt: Date.now(), status: item.status ?? "queued" };
  _items = [full, ..._items].slice(0, 50);
  notify();
  persist();
  return full;
}

export function updateActivity(id: string, patch: Partial<ActivityItem>) {
  _items = _items.map((i) => (i.id === id ? { ...i, ...patch } : i));
  notify();
  persist();
}

export function removeActivity(id: string) {
  _items = _items.filter((i) => i.id !== id);
  notify();
  persist();
}

export function clearFinished() {
  _items = _items.filter((i) => i.status === "queued" || i.status === "running");
  notify();
  persist();
}

/** Hook koji re-emituje listu aktivnosti komponentama. */
export function useActivities(): ActivityItem[] {
  const [items, setItems] = useState<ActivityItem[]>(_items);
  useEffect(() => subscribeActivities(setItems), []);
  // Hidriraj iz LS na mount
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return;
      const parsed: ActivityItem[] = JSON.parse(raw);
      // dodaj samo one koji nisu već tu
      const existingIds = new Set(_items.map((i) => i.id));
      const fresh = parsed.filter((i) => !existingIds.has(i.id));
      if (fresh.length === 0) return;
      _items = [...fresh, ..._items].slice(0, 50);
      notify();
    } catch {}
  }, []);
  return items;
}

/**
 * Helper: registruje lead-scrape job (pojedinačni lead) i prati progress.
 */
export function startLeadScrapeJob(opts: {
  jobId: string;
  leadId: number;
  leadName: string;
}): () => void {
  const id = `lead-scrape-${opts.jobId}`;
  addActivity({
    id,
    kind: "lead_scrape",
    label: `Scrape: ${opts.leadName}`,
    detail: `Crawl + screenshot`,
    status: "running",
    pollUrl: `/api/scrape/status/${opts.jobId}`,
    meta: { leadId: opts.leadId, scrapeJobId: opts.jobId },
  });

  let poll: ReturnType<typeof setInterval> | null = null;
  let cancelled = false;

  const tick = async () => {
    if (cancelled) return;
    try {
      const r = await fetch(`/api/scrape/status/${opts.jobId}`, { cache: "no-store" });
      if (!r.ok) return;
      const d = await r.json();
      const s = d?.status;
      const status: ActivityStatus =
        s === "done" ? "done" : s === "failed" ? "failed" : "running";
      const count = typeof d?.pages_scraped === "number" ? d.pages_scraped : undefined;
      const total = typeof d?.total_pages === "number" ? d.total_pages : undefined;
      const hasScreenshot = !!d?.screenshot;
      const stage =
        hasScreenshot
          ? "done"
          : count !== undefined && count > 0
            ? "detail"
            : "search";
      const message =
        status === "done"
          ? hasScreenshot
            ? "Screenshot spreman"
            : "Završeno (bez screenshot-a)"
          : d?.error || `Stranica ${count ?? 0}/${total ?? "?"}`;
      updateActivity(id, {
        status,
        finishedAt: status !== "running" ? Date.now() : undefined,
        count,
        total,
        stage,
        message,
      });
      if (status !== "running") {
        if (poll) clearInterval(poll);
        poll = null;
      }
    } catch {}
  };

  void tick();
  poll = setInterval(tick, 1000);

  return () => {
    cancelled = true;
    if (poll) clearInterval(poll);
    updateActivity(id, { status: "cancelled", finishedAt: Date.now() });
  };
}

/**
 * Helper: registruje scrape-leads job i pokreće polling status + progress.
 * Vraća kontrolnu funkciju za otkazivanje.
 */
export function startScrapeLeadsJob(opts: {
  jobId: string;
  category: string;
  city: string;
  maxResults?: number | null;
  extractEmails?: boolean;
  meta?: Record<string, unknown>;
}): () => void {
  const id = `scrape-leads-${opts.jobId}`;
  addActivity({
    id,
    kind: "scrape_leads",
    label: `Scrape: ${opts.category} · ${opts.city}`,
    detail: opts.maxResults ? `Max ${opts.maxResults} rezultata${opts.extractEmails ? " + email" : ""}` : undefined,
    status: "queued",
    pollUrl: `/api/scrape-leads/status/${opts.jobId}`,
    meta: { ...opts.meta, scraperJobId: opts.jobId },
  });

  let statusPoll: ReturnType<typeof setInterval> | null = null;
  let progressPoll: ReturnType<typeof setInterval> | null = null;
  let cancelled = false;

  const pollStatus = async () => {
    if (cancelled) return;
    try {
      const r = await fetch(`/api/scrape-leads/status/${opts.jobId}`, { cache: "no-store" });
      if (!r.ok) return;
      const data = await r.json();
      const status: ActivityStatus = data.status === "running" || data.status === "queued"
        ? "running"
        : data.status === "done"
          ? "done"
          : data.status === "empty" || data.status === "captcha"
            ? "failed"
            : "failed";
      updateActivity(id, {
        status,
        finishedAt: ["done", "failed", "cancelled"].includes(status) ? Date.now() : undefined,
        count: data.rowsWritten,
        total: data.rowsWritten,
        stage: data.stage ?? undefined,
      });
      if (status === "done" || status === "failed") {
        if (statusPoll) clearInterval(statusPoll);
        if (progressPoll) clearInterval(progressPoll);
        statusPoll = null;
        progressPoll = null;
      }
    } catch {}
  };

  const pollProgress = async () => {
    if (cancelled) return;
    try {
      const r = await fetch(`/api/scrape-leads/progress/${opts.jobId}`, { cache: "no-store" });
      if (!r.ok) return;
      const data = await r.json();
      const ev = data.snapshot?.last_event;
      if (!ev) return;
      updateActivity(id, {
        stage: ev.stage,
        message: ev.message,
        count: ev.count,
        total: ev.total ?? undefined,
        status: "running",
      });
    } catch {}
  };

  void pollStatus();
  statusPoll = setInterval(pollStatus, 1500);
  progressPoll = setInterval(pollProgress, 800);

  return () => {
    cancelled = true;
    if (statusPoll) clearInterval(statusPoll);
    if (progressPoll) clearInterval(progressPoll);
    updateActivity(id, { status: "cancelled", finishedAt: Date.now() });
  };
}

const STAGE_LABEL: Record<string, string> = {
  startup: "Pokretanje",
  search: "Pretraga",
  detail: "Ekstrakcija",
  email: "Email",
  captcha: "Captcha",
  export: "Upis",
  done: "Završeno",
};

function fmtDuration(ms: number): string {
  const s = Math.floor(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rs = s % 60;
  if (m < 60) return `${m}m ${rs}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

function estimateEta(item: ActivityItem): string | null {
  if (!item.count || !item.total || item.count === 0) return null;
  const elapsed = Date.now() - item.startedAt;
  const perItem = elapsed / item.count;
  const remaining = item.total - item.count;
  if (remaining <= 0) return null;
  const etaMs = perItem * remaining;
  return `~${fmtDuration(etaMs)}`;
}

import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Activity, Loader2, CheckCircle2, XCircle, X, Trash2, ChevronDown, ChevronUp, ExternalLink } from "lucide-react";

export function ActivityPanel() {
  const items = useActivities();
  const [open, setOpen] = useState(true);
  const [minimized, setMinimized] = useState(false);

  const active = items.filter((i) => i.status === "running" || i.status === "queued");
  const finished = items.filter((i) => i.status !== "running" && i.status !== "queued").slice(0, 5);

  // Ako nema apsolutno ničega — ne prikazuj. Ali ako ima bilo šta (aktivno ili završeno),
  // prikaži makar minimizovano dugme da korisnik zna da postoji nešto.
  if (items.length === 0) return null;

  const showOpen = open && !minimized;
  const hasActive = active.length > 0;

  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex max-w-sm flex-col gap-2">
      {showOpen && (
        <Card className={`pointer-events-auto w-80 shadow-2xl ${hasActive ? "ring-2 ring-primary/30" : ""}`}>
          <CardContent className="space-y-2 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-sm font-medium">
                <Activity className={`h-4 w-4 ${hasActive ? "animate-pulse text-primary" : "text-primary"}`} />
                Aktivnost
                {active.length > 0 && (
                  <span className="ml-1 rounded-full bg-primary px-1.5 text-xs text-primary-foreground">
                    {active.length}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {finished.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={() => clearFinished()} title="Očisti završene">
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => setMinimized(true)} title="Sakrij panel">
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </div>
            </div>

            {active.length === 0 && finished.length === 0 && (
              <p className="py-2 text-center text-xs text-muted-foreground">Nema aktivnih procesa.</p>
            )}

            <div className="max-h-80 space-y-2 overflow-y-auto">
              {active.map((it) => (
                <ActivityRow key={it.id} item={it} />
              ))}
              {finished.map((it) => (
                <ActivityRow key={it.id} item={it} />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {minimized && (
        <Button
          variant="default"
          size="lg"
          className="pointer-events-auto self-end gap-2 shadow-xl"
          onClick={() => setMinimized(false)}
        >
          <Activity className={`h-4 w-4 ${hasActive ? "animate-pulse" : ""}`} />
          {hasActive ? (
            <>
              {active.length} aktivan proces
            </>
          ) : (
            <>Aktivnost ({finished.length})</>
          )}
          <ChevronUp className="h-3 w-3" />
        </Button>
      )}

      {!showOpen && !minimized && (
        <Button
          variant="outline"
          size="sm"
          className="pointer-events-auto self-end shadow-md"
          onClick={() => setOpen(true)}
        >
          <Activity className="h-4 w-4" />
          Aktivnost ({items.length})
        </Button>
      )}
    </div>
  );
}
function ActivityRow({ item }: { item: ActivityItem }) {
  const elapsed = (item.finishedAt ?? Date.now()) - item.startedAt;
  const isRunning = item.status === "running" || item.status === "queued";
  const eta = isRunning ? estimateEta(item) : null;
  const pct = item.count && item.total && item.total > 0 ? Math.min(100, Math.round((item.count / item.total) * 100)) : null;
  const StageLabel = item.stage ? STAGE_LABEL[item.stage] ?? item.stage : null;

  return (
    <div className="rounded-md border bg-card/50 p-2 text-xs">
      <div className="flex items-start justify-between gap-1">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1">
            {isRunning ? (
              <Loader2 className="h-3 w-3 animate-spin text-blue-600" />
            ) : item.status === "done" ? (
              <CheckCircle2 className="h-3 w-3 text-green-600" />
            ) : item.status === "cancelled" ? (
              <X className="h-3 w-3 text-slate-500" />
            ) : (
              <XCircle className="h-3 w-3 text-red-600" />
            )}
            <span className="truncate font-medium">{item.label}</span>
          </div>
          {item.detail && <div className="truncate text-muted-foreground">{item.detail}</div>}
          {StageLabel && <div className="truncate text-muted-foreground">{StageLabel}{item.message ? ` · ${item.message}` : ""}</div>}
        </div>
        <div className="flex shrink-0 items-center gap-1 text-right">
          <span className="font-mono text-muted-foreground">{fmtDuration(elapsed)}</span>
          {isRunning && (
            <Button
              variant="ghost"
              size="sm"
              className="h-5 w-5 p-0"
              onClick={() => removeActivity(item.id)}
              title="Ukloni iz liste"
            >
              <X className="h-2.5 w-2.5" />
            </Button>
          )}
        </div>
      </div>
      {pct !== null && (
        <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-muted">
          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${pct}%` }} />
        </div>
      )}
      <div className="mt-1 flex items-center justify-between text-muted-foreground">
        <span>
          {item.count ?? 0}
          {item.total ? ` / ${item.total}` : ""}
        </span>
        {eta && <span>{eta}</span>}
      </div>
      {item.status === "done" && item.meta && typeof item.meta === "object" && (
        <>
          {"scraperJobId" in item.meta && (
            <Link
              href={`/campaigns/${String((item.meta as Record<string, unknown>).campaignId ?? "")}`}
              className="mt-1 inline-flex items-center gap-1 text-primary hover:underline"
            >
              Otvori kampanju <ExternalLink className="h-2.5 w-2.5" />
            </Link>
          )}
          {"leadId" in item.meta && (
            <Link
              href={`/leads/${String((item.meta as Record<string, unknown>).leadId)}`}
              className="mt-1 inline-flex items-center gap-1 text-primary hover:underline"
            >
              Otvori lead <ExternalLink className="h-2.5 w-2.5" />
            </Link>
          )}
        </>
      )}
    </div>
  );
}
