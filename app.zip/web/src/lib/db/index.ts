import Database from "better-sqlite3";
import { drizzle, type BetterSQLite3Database } from "drizzle-orm/better-sqlite3";
import { migrate } from "drizzle-orm/better-sqlite3/migrator";
import path from "node:path";
import fs from "node:fs";
import * as schema from "./schema";

declare global {
  // eslint-disable-next-line no-var
  var __outreachDb: { db: BetterSQLite3Database<typeof schema>; raw: Database.Database } | undefined;
}

function resolveDbPath(): string {
  const raw = process.env.DATABASE_URL ?? "file:/data/outreach.db";
  const p = raw.startsWith("file:") ? raw.slice(5) : raw;
  return path.isAbsolute(p) ? p : path.resolve(process.cwd(), p);
}

function ensureDir(filePath: string) {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function createConnection() {
  const dbPath = resolveDbPath();
  ensureDir(dbPath);

  const raw = new Database(dbPath);
  // WAL + short transactions — dovoljno za single-user
  raw.pragma("journal_mode = WAL");
  raw.pragma("synchronous = NORMAL");
  raw.pragma("busy_timeout = 5000");
  raw.pragma("foreign_keys = ON");

  const db = drizzle(raw, { schema });

  // Pokreni migracije ako postoje (fajl-sistem migracija u /drizzle)
  const migrationsFolder = path.join(process.cwd(), "drizzle");
  if (fs.existsSync(migrationsFolder)) {
    try {
      migrate(db, { migrationsFolder });
    } catch (e) {
      // Ako migracioni folder postoji ali je nekompatibilan, loguj i nastavi
      console.error("[db] migration warning:", e);
    }
  }

  // Lightweight bootstrap: tabele koje ne zahtevaju Drizzle migraciju.
  // Svaka CREATE koristi IF NOT EXISTS pa je idempotentno.
  raw.exec(`
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
      actor TEXT NOT NULL DEFAULT 'system',
      action TEXT NOT NULL,
      entity TEXT NOT NULL,
      entity_id INTEGER,
      meta TEXT
    );
    CREATE INDEX IF NOT EXISTS audit_log_ts_idx ON audit_log(ts);
    CREATE INDEX IF NOT EXISTS audit_log_entity_idx ON audit_log(entity, entity_id);
  `);

  return { db, raw };
}

export function getDb() {
  if (!globalThis.__outreachDb) {
    globalThis.__outreachDb = createConnection();
  }
  return globalThis.__outreachDb.db;
}

export function getRaw() {
  if (!globalThis.__outreachDb) {
    globalThis.__outreachDb = createConnection();
  }
  return globalThis.__outreachDb.raw;
}

export { schema };
