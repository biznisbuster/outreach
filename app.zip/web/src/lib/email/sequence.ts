import { getDb, schema } from "@/lib/db";
import { eq, and, asc } from "drizzle-orm";
import { generateEmailDraft } from "@/lib/email/generate";

/**
 * Nakon uspešnog slanja emaila za lead, proveri da li postoji aktivna sekvenca
 * u kampanji i enqueue-uj sledeći korak (ako nije već reply-ovao).
 */
export async function advanceSequence(
  emailSendId: number,
  leadId: number,
  campaignId: number,
  sentAt: Date,
): Promise<{ advanced: boolean; nextQueued?: number }> {
  const db = getDb();

  // da li je lead reply-ovao (bilo koji email_send)?
  const anyReplied = db
    .select({ id: schema.emailSends.id })
    .from(schema.emailSends)
    .where(and(eq(schema.emailSends.leadId, leadId), eq(schema.emailSends.replied, true)))
    .limit(1)
    .all();
  if (anyReplied.length > 0) {
    // stop sekvenca — zaustavi sve queued za lead
    db.update(schema.emailSends)
      .set({ status: "failed", error: "Sekvenca stopirana: lead reply-ovao" })
      .where(and(eq(schema.emailSends.leadId, leadId), eq(schema.emailSends.status, "queued")))
      .run();
    return { advanced: false };
  }

  // nađi aktivnu sekvencu
  const [sequence] = db
    .select()
    .from(schema.sequences)
    .where(and(eq(schema.sequences.campaignId, campaignId), eq(schema.sequences.active, true)))
    .all();
  if (!sequence) return { advanced: false };

  // nađi poslednji poslati step za ovaj lead (ili start)
  const steps = db
    .select()
    .from(schema.sequenceSteps)
    .where(eq(schema.sequenceSteps.sequenceId, sequence.id))
    .orderBy(asc(schema.sequenceSteps.stepNumber))
    .all();
  if (steps.length === 0) return { advanced: false };

  // odredi koji je step bio upravo poslat (po sequenceStepId email_send-a, ili inferiši)
  const [sentEs] = db
    .select()
    .from(schema.emailSends)
    .where(eq(schema.emailSends.id, emailSendId))
    .all();
  let currentStepNum = 0;
  if (sentEs?.sequenceStepId) {
    const [step] = db
      .select()
      .from(schema.sequenceSteps)
      .where(eq(schema.sequenceSteps.id, sentEs.sequenceStepId))
      .all();
    if (step) currentStepNum = step.stepNumber;
  }
  const nextStep = steps.find((s) => s.stepNumber > currentStepNum);
  if (!nextStep) return { advanced: false }; // sekvenca završena

  // izračunaj queued_at = sentAt + delayDays (dani)
  const delayMs = (nextStep.delayDays || 0) * 24 * 60 * 60 * 1000;
  const queuedAt = new Date(sentAt.getTime() + delayMs);

  // generiši draft za sledeći korak
  const draft = await generateEmailDraft(leadId, nextStep.promptTemplateId ?? undefined);
  if (!draft) return { advanced: false };

  const rows = db
    .insert(schema.emailSends)
    .values({
      leadId,
      sequenceStepId: nextStep.id,
      promptTemplateId: nextStep.promptTemplateId ?? null,
      subject: draft.subject,
      body: draft.body,
      status: "queued",
      generatedByAi: true,
      reviewed: false,
      queuedAt,
    })
    .returning()
    .all();

  return { advanced: true, nextQueued: rows[0]?.id };
}