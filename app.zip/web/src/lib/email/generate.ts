import { getDb, schema } from "@/lib/db";
import { eq, desc } from "drizzle-orm";
import { completeText, isMinimaxConfigured } from "@/lib/minimax";

/**
 * Skupi kontekst za personalizaciju emaila: lead + site analiza + maps + sender.
 * Koristi se kao {{context}} u promptu.
 */
export function buildEmailContext(leadId: number): { context: object; senderFromName?: string; senderEmail?: string } {
  const db = getDb();
  const [lead] = db
    .select()
    .from(schema.leads)
    .where(eq(schema.leads.id, leadId))
    .all();
  if (!lead) return { context: {} };

  const analysis = db
    .select()
    .from(schema.siteAnalysis)
    .where(eq(schema.siteAnalysis.leadId, leadId))
    .orderBy(desc(schema.siteAnalysis.analyzedAt))
    .limit(1)
    .all()[0];

  const topPages = db
    .select({
      url: schema.sitePages.url,
      title: schema.sitePages.title,
      h1: schema.sitePages.h1,
    })
    .from(schema.siteScrapes)
    .innerJoin(schema.sitePages, eq(schema.sitePages.scrapeId, schema.siteScrapes.id))
    .where(eq(schema.siteScrapes.leadId, leadId))
    .orderBy(desc(schema.siteScrapes.startedAt))
    .limit(1)
    .all()[0]
    ? db
        .select({ url: schema.sitePages.url, title: schema.sitePages.title, h1: schema.sitePages.h1 })
        .from(schema.sitePages)
        .innerJoin(schema.siteScrapes, eq(schema.siteScrapes.id, schema.sitePages.scrapeId))
        .where(eq(schema.siteScrapes.leadId, leadId))
        .limit(3)
        .all()
    : [];

  const activeSender = db
    .select()
    .from(schema.senders)
    .where(eq(schema.senders.active, true))
    .limit(1)
    .all()[0];

  const context = {
    lead: {
      name: lead.name,
      category: lead.category,
      phone: lead.phoneE164,
      email: lead.email,
      website: lead.websiteNormalized,
      google_rating: lead.googleRating,
      reviews_count: lead.reviewsCount,
      city: lead.city,
      address: lead.address,
      source: lead.source,
      source_url: lead.sourceUrl,
    },
    site: analysis
      ? {
          visual_score: analysis.visualScore,
          visual_notes: analysis.visualNotes ? safeParseArr(analysis.visualNotes) : [],
          seo_score: analysis.seoScore,
          overall_score: analysis.overallScore,
          ai_summary: analysis.aiSummary,
          issues: analysis.issuesJson ? safeParseArr(analysis.issuesJson) : [],
          top_pages: topPages.map((p) => ({ url: p.url, title: p.title, h1: p.h1 })),
        }
      : null,
    maps: lead.sourceUrl
      ? {
          source_url: lead.sourceUrl,
          rating: lead.googleRating,
          reviews_count: lead.reviewsCount,
        }
      : null,
    sender: activeSender
      ? { from_name: activeSender.fromName, email: activeSender.email }
      : null,
  };

  return {
    context,
    senderFromName: activeSender?.fromName,
    senderEmail: activeSender?.email,
  };
}

function safeParseArr(s: string): string[] {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}

/**
 * Generiše email draft za lead. Vraća {subject, body} ili null ako MiniMax nije konfigurisan.
 */
export async function generateEmailDraft(
  leadId: number,
  promptTemplateId?: number,
): Promise<{ subject: string; body: string } | null> {
  if (!isMinimaxConfigured()) return null;
  const db = getDb();
  const template = promptTemplateId
    ? db.select().from(schema.promptTemplates).where(eq(schema.promptTemplates.id, promptTemplateId)).limit(1).all()[0]
    : db
        .select()
        .from(schema.promptTemplates)
        .where(eq(schema.promptTemplates.type, "email_personalization"))
        .orderBy(desc(schema.promptTemplates.isDefault))
        .limit(1)
        .all()[0];
  if (!template) return null;

  const { context, senderFromName, senderEmail } = buildEmailContext(leadId);

  // popuni placeholder-e
  let prompt = template.body
    .replace(/\{\{context\}\}/g, JSON.stringify(context, null, 2))
    .replace(/\{\{sender_from_name\}\}/g, senderFromName || "Marko")
    .replace(/\{\{sender_email\}\}/g, senderEmail || "marko@example.com");

  const raw = await completeText(
    "Ti si B2B copywriter za cold outreach.",
    prompt,
    { temperature: 0.7, maxTokens: 1000 },
  );

  // parsiranje SUBJECT: ... BODY: ...
  const subjectMatch = raw.match(/SUBJECT\s*:\s*(.+?)(?:\n|$)/i);
  const bodyMatch = raw.match(/BODY\s*:\s*([\s\S]+)$/i);
  let subject = subjectMatch?.[1]?.trim() || "Kratka ideja za vaš biznis";
  let body = bodyMatch?.[1]?.trim() || raw;

  // ukloni leading "—" i sl. ako nema imena sender-a
  return { subject, body };
}