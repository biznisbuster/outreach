/**
 * Centralni runtime settings.
 *
 * DB (settings.key/value) → env → hardcoded default.
 * Secrets (api_key, password) enkriptuju se pre upisa koristeći
 * `lib/crypto.ts` (isti AES-256-GCM kao za SMTP šifre).
 *
 * Keširanje: 1 sekunda u memoriji, da ne udaramo SQLite na svaki poziv.
 */
import { getDb, schema } from "./db";
import { eq } from "drizzle-orm";
import { encrypt, decrypt } from "./crypto";

export interface SettingDef {
  key: string;
  defaultValue: string;
  isSecret?: boolean;
  group: string; // UI sekcija
  label: string;
  description?: string;
  placeholder?: string;
  type: "text" | "password" | "number" | "select" | "boolean";
  options?: string[];
  envHint?: string; // koja env var se koristi kao fallback
}

export const SETTINGS_CATALOG: Record<string, SettingDef> = {
  // ─── MiniMax M3 (AI) ────────────────────────────────────────────
  minimax_api_key: {
    key: "minimax_api_key",
    defaultValue: "",
    isSecret: true,
    group: "MiniMax M3 (AI)",
    label: "API ključ",
    description: "Tvoj MiniMax M3 API ključ. Koristi se za email personalizaciju i vizuelnu ocenu sajtova.",
    placeholder: "sk-...",
    type: "password",
    envHint: "MINIMAX_API_KEY",
  },
  minimax_base_url: {
    key: "minimax_base_url",
    defaultValue: "https://api.minimax.io/v1",
    group: "MiniMax M3 (AI)",
    label: "Base URL",
    type: "text",
    envHint: "MINIMAX_BASE_URL",
  },
  minimax_model: {
    key: "minimax_model",
    defaultValue: "MiniMax-M3",
    group: "MiniMax M3 (AI)",
    label: "Model",
    type: "text",
    envHint: "MINIMAX_MODEL",
  },

  // ─── Scraper servisi ──────────────────────────────────────────────
  scraper_url: {
    key: "scraper_url",
    defaultValue: "http://localhost:8001",
    group: "Scraper servisi",
    label: "Lead scraper URL (page-by-page crawl)",
    description: "Stari scraper servis. Pokreće crawl + screenshot jednog lead-ovog sajta.",
    type: "text",
    envHint: "SCRAPER_URL",
  },
  scraper_leads_url: {
    key: "scraper_leads_url",
    defaultValue: "http://localhost:8002",
    group: "Scraper servisi",
    label: "Scrape-leads URL (Google Maps)",
    description: "maps-cold-calling FastAPI wrapper. Pokreće Google Maps pretragu po (kategorija, grad).",
    type: "text",
    envHint: "SCRAPER_LEADS_URL",
  },
  auto_screenshot_on_open: {
    key: "auto_screenshot_on_open",
    defaultValue: "0",
    group: "Scraper servisi",
    label: "Auto-screenshot pri otvaranju leada",
    description: "Ako je uključeno, otvaranje lead detail stranice automatski pokreće scrape (screenshot).",
    type: "select",
    options: ["0", "1"],
  },

  // ─── Slanje emaila (prozor) ───────────────────────────────────────
  send_window_start: {
    key: "send_window_start",
    defaultValue: "09:00",
    group: "Slanje emaila",
    label: "Početak prozora (HH:MM)",
    type: "text",
    envHint: "SEND_WINDOW_START",
  },
  send_window_end: {
    key: "send_window_end",
    defaultValue: "17:00",
    group: "Slanje emaila",
    label: "Kraj prozora (HH:MM)",
    type: "text",
    envHint: "SEND_WINDOW_END",
  },
  send_window_tz: {
    key: "send_window_tz",
    defaultValue: "Europe/Belgrade",
    group: "Slanje emaila",
    label: "Vremenska zona",
    type: "text",
    envHint: "SEND_WINDOW_TZ",
  },
  send_window_days: {
    key: "send_window_days",
    defaultValue: "mon-fri",
    group: "Slanje emaila",
    label: "Dani (mon-fri, mon,wed,fri)",
    type: "text",
    envHint: "SEND_WINDOW_DAYS",
  },
  default_sender_hourly_cap: {
    key: "default_sender_hourly_cap",
    defaultValue: "10",
    group: "Slanje emaila",
    label: "Podrazumevani hourly cap (po senderu)",
    type: "number",
    envHint: "DEFAULT_SENDER_HOURLY_CAP",
  },
  default_sender_daily_cap: {
    key: "default_sender_daily_cap",
    defaultValue: "50",
    group: "Slanje emaila",
    label: "Podrazumevani daily cap (po senderu)",
    type: "number",
    envHint: "DEFAULT_SENDER_DAILY_CAP",
  },

  // ─── Unsubscribe ──────────────────────────────────────────────────
  unsubscribe_base_url: {
    key: "unsubscribe_base_url",
    defaultValue: "",
    group: "Ostalo",
    label: "Unsubscribe base URL",
    description: "Bazni URL za unsubscribe link u emailovima (npr. https://outreach.tvojdomen.rs).",
    type: "text",
    envHint: "UNSUBSCRIBE_BASE_URL",
  },

  // ─── IMAP (reply tracking) ────────────────────────────────────────
  imap_host: {
    key: "imap_host",
    defaultValue: "",
    group: "IMAP (reply tracking)",
    label: "IMAP host",
    placeholder: "imap.gmail.com",
    type: "text",
    envHint: "IMAP_HOST",
  },
  imap_port: {
    key: "imap_port",
    defaultValue: "993",
    group: "IMAP (reply tracking)",
    label: "Port",
    type: "number",
    envHint: "IMAP_PORT",
  },
  imap_user: {
    key: "imap_user",
    defaultValue: "",
    group: "IMAP (reply tracking)",
    label: "Korisničko ime",
    type: "text",
    envHint: "IMAP_USER",
  },
  imap_password: {
    key: "imap_password",
    defaultValue: "",
    isSecret: true,
    group: "IMAP (reply tracking)",
    label: "Lozinka (app password)",
    type: "password",
    envHint: "IMAP_PASSWORD",
  },
  imap_folder: {
    key: "imap_folder",
    defaultValue: "INBOX",
    group: "IMAP (reply tracking)",
    label: "Folder",
    type: "text",
    envHint: "IMAP_FOLDER",
  },
  imap_poll_minutes: {
    key: "imap_poll_minutes",
    defaultValue: "5",
    group: "IMAP (reply tracking)",
    label: "Interval pollanja (min)",
    type: "number",
    envHint: "IMAP_POLL_MINUTES",
  },
};

type CacheEntry = { value: string; ts: number };
const _cache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 1000;

function _readDB(key: string): string | undefined {
  const db = getDb();
  const [row] = db.select().from(schema.settings).where(eq(schema.settings.key, key)).all();
  if (!row?.value) return undefined;
  const def = SETTINGS_CATALOG[key];
  try {
    if (def?.isSecret && row.value.startsWith("v1:")) return decrypt(row.value);
  } catch {
    // vrednost nije šifrovana (možda legacy plaintext), vrati kako jeste
  }
  return row.value;
}

function _envFallback(key: string): string | undefined {
  const def = SETTINGS_CATALOG[key];
  if (!def?.envHint) return undefined;
  const v = process.env[def.envHint];
  return v && !v.startsWith("replace") ? v : undefined;
}

/**
 * Čita setting. Redosled: in-memory cache (1s) → DB → env → default.
 */
export function getSetting(key: string): string {
  const def = SETTINGS_CATALOG[key];
  if (!def) {
    // Nepoznat ključ — vrati iz DB/env ako postoji, inače prazan string
    const cached = _cache.get(key);
    if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.value;
    const dbVal = _readDB(key);
    if (dbVal !== undefined) {
      _cache.set(key, { value: dbVal, ts: Date.now() });
      return dbVal;
    }
    return process.env[key.toUpperCase()] ?? "";
  }

  const cached = _cache.get(key);
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.value;

  const dbVal = _readDB(key);
  if (dbVal !== undefined && dbVal !== "") {
    _cache.set(key, { value: dbVal, ts: Date.now() });
    return dbVal;
  }
  const envVal = _envFallback(key);
  if (envVal !== undefined && envVal !== "") {
    _cache.set(key, { value: envVal, ts: Date.now() });
    return envVal;
  }
  _cache.set(key, { value: def.defaultValue, ts: Date.now() });
  return def.defaultValue;
}

/** Čita setting kao broj. */
export function getSettingInt(key: string): number {
  const n = Number(getSetting(key));
  return Number.isFinite(n) ? n : 0;
}

/** Čita setting kao boolean (1/0, true/false). */
export function getSettingBool(key: string): boolean {
  const v = getSetting(key);
  return v === "1" || v.toLowerCase() === "true";
}

/** Čita secret setting — placeholder ako nije podešen. */
export function getSettingOrEmpty(key: string): string {
  return getSetting(key);
}

/**
 * Upisuje setting. Ako je `isSecret=true`, enkriptuje pre upisa.
 * Briše cache za dati ključ.
 */
export function setSetting(key: string, value: string, isSecret = false): void {
  const db = getDb();
  const stored = isSecret && value ? encrypt(value) : value;
  // UPSERT — Drizzle nema native ON CONFLICT u sqlite-core, koristimo replace
  const existing = db.select().from(schema.settings).where(eq(schema.settings.key, key)).all();
  if (existing.length > 0) {
    db.update(schema.settings).set({ value: stored }).where(eq(schema.settings.key, key)).run();
  } else {
    db.insert(schema.settings).values({ key, value: stored }).run();
  }
  _cache.delete(key);
}

/** Briše setting iz DB (sledeći getSetting čita env/default). */
export function clearSetting(key: string): void {
  const db = getDb();
  db.delete(schema.settings).where(eq(schema.settings.key, key)).run();
  _cache.delete(key);
}

/** Vraća sve setting-e za UI (sa indikatorom izvora). */
export interface SettingView {
  key: string;
  value: string;
  isSecret: boolean;
  isSet: boolean; // != default
  source: "db" | "env" | "default";
  def: SettingDef;
}

export function getAllSettings(): SettingView[] {
  const db = getDb();
  const dbRows = new Map(
    db.select().from(schema.settings).all().map((r) => [r.key, r.value ?? ""]),
  );
  return Object.values(SETTINGS_CATALOG).map((def) => {
    let value = "";
    let source: "db" | "env" | "default" = "default";
    let displayValue = "";
    if (dbRows.has(def.key)) {
      const raw = dbRows.get(def.key)!;
      try {
        displayValue = def.isSecret && raw.startsWith("v1:") ? decrypt(raw) : raw;
      } catch {
        displayValue = raw;
      }
      source = "db";
      // Za secret polja vraćamo decrypted vrednost da UI može da zadrži draft
      // (input type=password + Reveal dugme i dalje kontrolišu prikaz).
      value = displayValue;
    } else {
      const envVal = _envFallback(def.key);
      if (envVal) {
        source = "env";
        displayValue = envVal;
        value = def.isSecret ? "" : envVal;
      } else {
        displayValue = def.defaultValue;
        value = def.defaultValue;
      }
    }
    const isSet = source !== "default" || displayValue !== def.defaultValue;
    return { key: def.key, value, isSecret: !!def.isSecret, isSet, source, def };
  });
}

/** Grupiše settingse po `group` polju, za UI sekcije. */
export function groupSettings(settings: SettingView[]): Record<string, SettingView[]> {
  const out: Record<string, SettingView[]> = {};
  for (const s of settings) {
    (out[s.def.group] ??= []).push(s);
  }
  return out;
}

/** Čisti in-memory cache (korisno za testiranje ili posle setSetting u istom procesu). */
export function clearSettingsCache(): void {
  _cache.clear();
}