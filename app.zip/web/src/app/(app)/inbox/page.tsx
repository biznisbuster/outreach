"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Inbox, Mail, RefreshCw, ArrowRight } from "lucide-react";
import { formatDate, timeAgo } from "@/lib/utils";

interface Reply {
  id: number;
  leadId: number;
  leadName: string;
  leadEmail: string;
  fromEmail: string;
  subject: string;
  receivedAt: number;
  matchedBy: string;
  emailSendId: number;
  sentSubject: string;
}

export default function InboxPage() {
  const [items, setItems] = useState<Reply[]>([]);
  const [loading, setLoading] = useState(true);
  const [polling, setPolling] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/inbox");
    const data = await res.json();
    setItems(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function manualPoll() {
    setPolling(true);
    try {
      const res = await fetch("/api/admin/imap-poll", { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        // silent reload
        load();
      }
    } finally {
      setPolling(false);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Inbox (reply tracking)</h1>
          <p className="text-sm text-muted-foreground">Automatski matchovani reply-evi iz IMAP-a.</p>
        </div>
        <Button onClick={manualPoll} disabled={polling}>
          {polling ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          Polluj IMAP
        </Button>
      </div>

      <div className="p-6">
        {loading ? (
          <div className="flex h-32 items-center justify-center text-muted-foreground">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Učitavanje...
          </div>
        ) : items.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <Inbox className="mb-3 h-10 w-10 text-muted-foreground" />
              <h3 className="font-semibold">Nema reply-jeva</h3>
              <p className="mb-4 max-w-sm text-sm text-muted-foreground">
                IMAP polling automatski detektuje odgovore i stopira sekvencu. Reply će se pojaviti ovde kad stigne.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-1">
            {items.map((it) => (
              <Link
                key={it.id}
                href={`/leads/${it.leadId}`}
                className="flex items-center justify-between rounded-md border bg-card p-3 transition-colors hover:bg-accent"
              >
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Mail className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="truncate font-medium">{it.leadName}</p>
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      <p className="truncate text-sm text-muted-foreground">reply na „{it.sentSubject}"</p>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Od: {it.fromEmail} · Match: <Badge variant="secondary">{it.matchedBy}</Badge>
                    </p>
                  </div>
                </div>
                <div className="ml-2 text-right text-xs text-muted-foreground">
                  <p>{timeAgo(it.receivedAt)}</p>
                  <p>{formatDate(it.receivedAt)}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}