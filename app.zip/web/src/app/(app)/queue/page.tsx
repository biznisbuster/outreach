"use client";

import { useCallback, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Inbox, Send, AlertTriangle, FileEdit, CheckCircle2, Ban } from "lucide-react";
import { formatDate } from "@/lib/utils";
import Link from "next/link";

interface QueueItem {
  id: number;
  subject: string;
  status: string;
  queuedAt: number | null;
  sentAt: number | null;
  error: string | null;
  reviewed: boolean;
  leadId: number;
  leadName: string;
  leadEmail: string;
  campaignId: number;
  senderEmail: string | null;
  replied: boolean;
}

const STATUS_KEYS = ["draft", "queued", "sent", "failed", "bounced"] as const;

function pickDefaultStatus(counts: Record<string, number>): string {
  if ((counts.queued || 0) > 0) return "queued";
  for (const k of STATUS_KEYS) {
    if ((counts[k] || 0) > 0) return k;
  }
  return "sent";
}

export default function QueuePage() {
  const [items, setItems] = useState<QueueItem[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [status, setStatus] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (status) params.set("status", status);
    params.set("limit", "200");
    const res = await fetch(`/api/queue?${params}`);
    const data = await res.json();
    setItems(data.items);
    const map: Record<string, number> = {};
    for (const c of data.counts) map[c.status] = Number(c.c);
    setCounts(map);
    if (status === null) setStatus(pickDefaultStatus(map));
    setLoading(false);
  }, [status]);

  useEffect(() => {
    load();
    const i = setInterval(load, 5000);
    return () => clearInterval(i);
  }, [load]);

  const total = Object.values(counts).reduce((a, b) => a + b, 0);

  return (
    <div>
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Red slanja</h1>
          <p className="text-sm text-muted-foreground">
            Ukupno: <span className="font-medium text-foreground">{total}</span>
            {STATUS_KEYS.map((k) => counts[k] ? ` · ${k} ${counts[k]}` : "").join("")}
          </p>
        </div>
        <Select value={status ?? "sent"} onValueChange={setStatus}>
          <SelectTrigger className="w-[200px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="queued">Queued ({counts.queued || 0})</SelectItem>
            <SelectItem value="draft">Draft ({counts.draft || 0})</SelectItem>
            <SelectItem value="sent">Poslato ({counts.sent || 0})</SelectItem>
            <SelectItem value="failed">Failed ({counts.failed || 0})</SelectItem>
            <SelectItem value="bounced">Bounced ({counts.bounced || 0})</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4 p-6">
        {/* Status overview */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <StatusCard label="Draft" count={counts.draft || 0} icon={<FileEdit className="h-4 w-4" />} color="bg-slate-100" />
          <StatusCard label="Queued" count={counts.queued || 0} icon={<Inbox className="h-4 w-4" />} color="bg-amber-100" />
          <StatusCard label="Sent" count={counts.sent || 0} icon={<Send className="h-4 w-4" />} color="bg-green-100" />
          <StatusCard label="Failed" count={counts.failed || 0} icon={<AlertTriangle className="h-4 w-4" />} color="bg-red-100" />
          <StatusCard label="Bounced" count={counts.bounced || 0} icon={<Ban className="h-4 w-4" />} color="bg-orange-100" />
        </div>

        {loading ? (
          <div className="flex h-32 items-center justify-center text-muted-foreground">
            <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Učitavanje...
          </div>
        ) : items.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 text-center text-sm text-muted-foreground">
              <Inbox className="mb-2 h-10 w-10" />
              Nema emailova u ovoj kategoriji.
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-1">
            {items.map((it) => (
              <Link
                key={it.id}
                href={`/leads/${it.leadId}`}
                className="flex items-center justify-between rounded-md border bg-card p-3 transition-colors hover:bg-accent"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-medium">{it.subject}</p>
                    {it.replied && (
                      <Badge variant="success" className="shrink-0">
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        Odgovorio
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {it.leadName} &lt;{it.leadEmail}&gt; · {it.senderEmail ? `preko ${it.senderEmail}` : "bez sendera"}
                  </p>
                  {it.error && <p className="mt-1 text-xs text-destructive">⚠ {it.error}</p>}
                </div>
                <div className="ml-2 flex shrink-0 flex-col items-end gap-1 text-xs text-muted-foreground">
                  {it.queuedAt && <span>Queued: {formatDate(it.queuedAt)}</span>}
                  {it.sentAt && <span>Sent: {formatDate(it.sentAt)}</span>}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatusCard({ label, count, icon, color }: { label: string; count: number; icon: React.ReactNode; color: string }) {
  return (
    <Card>
      <CardContent className="flex items-center justify-between p-4">
        <div>
          <p className="text-xs uppercase text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold">{count}</p>
        </div>
        <div className={`flex h-9 w-9 items-center justify-center rounded-md ${color}`}>{icon}</div>
      </CardContent>
    </Card>
  );
}