"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, CheckCircle2, XCircle, Zap, Mail, Save, Trash2, Server, Settings as SettingsIcon, Clock, Inbox, Shield, Sparkles, Calendar } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface SettingDef {
  key: string;
  defaultValue: string;
  isSecret?: boolean;
  group: string;
  label: string;
  description?: string;
  placeholder?: string;
  type: "text" | "password" | "number" | "select" | "boolean";
  options?: string[];
  envHint?: string;
}

interface SettingView {
  key: string;
  value: string;
  isSecret: boolean;
  isSet: boolean;
  source: "db" | "env" | "default";
  def: SettingDef;
}

const ICONS: Record<string, React.ReactNode> = {
  "MiniMax M3 (AI)": <Zap className="h-5 w-5 text-primary" />,
  "Scraper servisi": <Server className="h-5 w-5 text-primary" />,
  "Slanje emaila": <Clock className="h-5 w-5 text-primary" />,
  "Ostalo": <SettingsIcon className="h-5 w-5 text-primary" />,
  "IMAP (reply tracking)": <Inbox className="h-5 w-5 text-primary" />,
};

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingView[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  // lokalni draft za svaku vrednost (da typing ne triggeruje save)
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  // koja secret polja su "otkrivena" (prikazuju se plaintext)
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});

  // test konekcije
  const [minimaxState, setMinimaxState] = useState<{ status: "idle" | "loading" | "ok" | "err"; msg?: string }>({ status: "idle" });
  const [imapState, setImapState] = useState<{ status: "idle" | "loading" | "ok" | "err"; msg?: string }>({ status: "idle" });

  useEffect(() => {
    void load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/settings/save");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      setSettings(data.settings);
      const initial: Record<string, string> = {};
      for (const s of data.settings as SettingView[]) {
        initial[s.key] = s.value;
      }
      setDrafts(initial);
    } catch (e) {
      toast({ variant: "destructive", title: "Greška pri učitavanju", description: String(e) });
    } finally {
      setLoading(false);
    }
  }

  function setDraft(key: string, value: string) {
    setDrafts((d) => ({ ...d, [key]: value }));
  }

  function dirty(key: string, original: string, draft: string): boolean {
    if (key === "minimax_api_key" || key === "imap_password") {
      // za secrets — dirty ako je draft neprazan (smatramo kao "novu vrednost")
      // ili ako je bilo prazno a sad ima
      return draft.length > 0;
    }
    return draft !== original;
  }

  async function saveAll() {
    setSaving(true);
    try {
      const changes: Array<{ key: string; value: string; isSecret?: boolean; clear?: boolean }> = [];
      for (const s of settings) {
        const draft = drafts[s.key] ?? "";
        if (!dirty(s.key, s.value, draft)) continue;
        const isSecret = !!s.def.isSecret;
        // Za secret polja: ako je draft prazan, ne menjaj (ostavi staru vrednost)
        if (isSecret && draft === "") continue;
        changes.push({ key: s.key, value: draft, isSecret });
      }
      if (changes.length === 0) {
        toast({ title: "Nema izmena" });
        return;
      }
      const res = await fetch("/api/settings/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ changes }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      toast({ title: "Sačuvano", description: `${data.saved} izmena.` });
      await load();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: String(e) });
    } finally {
      setSaving(false);
    }
  }

  async function clearOne(key: string) {
    try {
      const res = await fetch("/api/settings/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ changes: [{ key, clear: true }] }),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      toast({ title: "Resetovano na env/default" });
      await load();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: String(e) });
    }
  }

  async function testMinimax() {
    setMinimaxState({ status: "loading" });
    try {
      const res = await fetch("/api/settings/test-minimax", { method: "POST" });
      const data = await res.json();
      if (data.ok) setMinimaxState({ status: "ok", msg: data.message });
      else setMinimaxState({ status: "err", msg: data.message });
    } catch (e) {
      setMinimaxState({ status: "err", msg: String(e) });
    }
  }

  async function testImap() {
    setImapState({ status: "loading" });
    try {
      const res = await fetch("/api/settings/test-imap", { method: "POST" });
      const data = await res.json();
      if (data.ok) setImapState({ status: "ok", msg: data.message });
      else setImapState({ status: "err", msg: data.message });
    } catch (e) {
      setImapState({ status: "err", msg: String(e) });
    }
  }

  const grouped: Record<string, SettingView[]> = {};
  for (const s of settings) {
    (grouped[s.def.group] ??= []).push(s);
  }
  const groupOrder = [
    "MiniMax M3 (AI)",
    "Scraper servisi",
    "Slanje emaila",
    "IMAP (reply tracking)",
    "Ostalo",
  ];

  const hasDirty = settings.some((s) => dirty(s.key, s.value, drafts[s.key] ?? ""));

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Učitavanje...
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Podešavanja</h1>
          <p className="text-sm text-muted-foreground">Globalne konfiguracije — čuvaju se u bazi, fallback na .env</p>
        </div>
        <Button onClick={saveAll} disabled={saving || !hasDirty}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Sačuvaj sve izmene
        </Button>
      </div>

      <div className="space-y-6 p-6">
        {groupOrder.filter((g) => grouped[g]).map((group) => (
          <Card key={group}>
            <CardHeader>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                  {ICONS[group]}
                </div>
                <div>
                  <CardTitle className="text-base">{group}</CardTitle>
                  {group === "MiniMax M3 (AI)" && (
                    <CardDescription>AI model za email personalizaciju i vizuelnu ocenu sajtova</CardDescription>
                  )}
                  {group === "Scraper servisi" && (
                    <CardDescription>URL-ovi scraping servisa i auto-screenshot</CardDescription>
                  )}
                  {group === "Slanje emaila" && (
                    <CardDescription>Vremenski prozor i default kapaciteti</CardDescription>
                  )}
                  {group === "IMAP (reply tracking)" && (
                    <CardDescription>Polling inbox-a za reply detection</CardDescription>
                  )}
                  {group === "Ostalo" && (
                    <CardDescription>Ostale globalne konfiguracije</CardDescription>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {grouped[group].map((s) => (
                <SettingRow
                  key={s.key}
                  s={s}
                  draft={drafts[s.key] ?? ""}
                  onChange={(v) => setDraft(s.key, v)}
                  revealed={!!revealed[s.key]}
                  onToggleReveal={() => setRevealed((r) => ({ ...r, [s.key]: !r[s.key] }))}
                  onClear={() => clearOne(s.key)}
                />
              ))}
            </CardContent>
          </Card>
        ))}

        {/* Test konekcije */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Shield className="h-4 w-4 text-primary" />
              Test konekcije
            </CardTitle>
            <CardDescription>Proverava da li su sačuvane vrednosti ispravne</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            <TestCard
              title="MiniMax M3"
              state={minimaxState}
              onTest={testMinimax}
              icon={<Zap className="h-4 w-4" />}
            />
            <TestCard
              title="IMAP"
              state={imapState}
              onTest={testImap}
              icon={<Mail className="h-4 w-4" />}
            />
          </CardContent>
        </Card>

        <ChangelogSection />
      </div>
    </div>
  );
}

function SettingRow({
  s,
  draft,
  onChange,
  revealed,
  onToggleReveal,
  onClear,
}: {
  s: SettingView;
  draft: string;
  onChange: (v: string) => void;
  revealed: boolean;
  onToggleReveal: () => void;
  onClear: () => void;
}) {
  const isSecret = !!s.def.isSecret;
  const sourceBadge =
    s.source === "db"
      ? { label: "iz baze", cls: "bg-green-100 text-green-700" }
      : s.source === "env"
        ? { label: `env ${s.def.envHint ?? ""}`, cls: "bg-blue-100 text-blue-700" }
        : { label: "default", cls: "bg-slate-100 text-slate-600" };

  // Za secret polja koja nisu otkrivena, prikazuj placeholder (••••••••) ako ima vrednost
  const displayValue = isSecret && !revealed && draft ? "••••••••••" : draft;
  const isPlaceholder = isSecret && !revealed && !!draft;

  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-3 sm:gap-4">
      <div className="sm:col-span-1">
        <Label htmlFor={`s-${s.key}`} className="text-sm font-medium">
          {s.def.label}
        </Label>
        {s.def.description && (
          <p className="mt-0.5 text-xs text-muted-foreground">{s.def.description}</p>
        )}
        <div className="mt-1 flex items-center gap-2">
          <span className={`rounded px-1.5 py-0.5 text-xs ${sourceBadge.cls}`}>{sourceBadge.label}</span>
          {s.def.envHint && s.source === "env" && (
            <span className="text-xs text-muted-foreground">env: {s.def.envHint}</span>
          )}
        </div>
      </div>
      <div className="sm:col-span-2">
        <div className="flex items-center gap-2">
          {s.def.type === "select" ? (
            <select
              id={`s-${s.key}`}
              value={draft}
              onChange={(e) => onChange(e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm"
            >
              {(s.def.options ?? []).map((opt) => (
                <option key={opt} value={opt}>
                  {opt === "1" ? "Uključeno" : opt === "0" ? "Isključeno" : opt}
                </option>
              ))}
            </select>
          ) : (
            <Input
              id={`s-${s.key}`}
              type={isSecret && !revealed ? "password" : s.def.type === "number" ? "number" : "text"}
              value={isPlaceholder ? "" : displayValue}
              placeholder={isSecret ? (draft ? "Nepromenjeno (ostavi prazno da ne menjaš)" : s.def.placeholder ?? "••••••••") : s.def.placeholder ?? s.def.defaultValue}
              onChange={(e) => onChange(e.target.value)}
              className="flex-1"
              autoComplete="off"
            />
          )}
          {isSecret && (
            <Button type="button" variant="outline" size="sm" onClick={onToggleReveal}>
              {revealed ? "Sakrij" : "Prikaži"}
            </Button>
          )}
          {s.source !== "default" && (
            <Button type="button" variant="ghost" size="sm" onClick={onClear} title="Resetuj na default">
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function TestCard({
  title,
  state,
  onTest,
  icon,
}: {
  title: string;
  state: { status: "idle" | "loading" | "ok" | "err"; msg?: string };
  onTest: () => void;
  icon: React.ReactNode;
}) {
  return (
    <div className="rounded-md border bg-card p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-primary">{icon}</span>
          <span className="font-medium">{title}</span>
        </div>
        <Button onClick={onTest} size="sm" variant="outline" disabled={state.status === "loading"}>
          {state.status === "loading" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Testiraj"}
        </Button>
      </div>
      {state.status === "ok" && (
        <div className="mt-2 flex items-start gap-2 text-sm text-green-700">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>{state.msg}</span>
        </div>
      )}
      {state.status === "err" && (
        <div className="mt-2 flex items-start gap-2 text-sm text-red-700">
          <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>{state.msg}</span>
        </div>
      )}
    </div>
  );
}
interface ChangelogEntry {
  date: string;
  title: string;
  body: string;
}

function ChangelogSection() {
  const [entries, setEntries] = useState<ChangelogEntry[]>([]);
  const [meta, setMeta] = useState<{ version?: string; scraperSource?: string }>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/scrape-leads/changelog?limit=12", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (cancelled || !data) return;
        setEntries(data.entries ?? []);
        setMeta({ version: data.version, scraperSource: data.scraperSource });
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <CardTitle className="text-base">Šta je novo u scraper-leads</CardTitle>
            <CardDescription>
              Verzija {meta.version ?? "—"} · izvor: {meta.scraperSource ?? "—"}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" /> Učitavanje istorije…
          </div>
        ) : entries.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nema unosa.</p>
        ) : (
          <div className="space-y-3">
            {entries.map((e, i) => (
              <div
                key={`${e.date}-${i}`}
                className="rounded-md border bg-muted/20 p-3"
              >
                <div className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="font-mono text-xs text-muted-foreground">{e.date}</span>
                  <span className="font-medium">{e.title}</span>
                  {i === 0 && (
                    <span className="rounded bg-green-100 px-1.5 py-0.5 text-xs text-green-700">
                      najnovije
                    </span>
                  )}
                </div>
                <pre className="mt-2 whitespace-pre-wrap text-xs text-muted-foreground">{e.body}</pre>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
