import Link from "next/link";
import { getDb, schema } from "@/lib/db";
import { sql, eq } from "drizzle-orm";
import { Card, CardContent } from "@/components/ui/card";
import { Users, MapPin, ChevronRight } from "lucide-react";
import { CreateCampaignDialog } from "./create-dialog";

export const dynamic = "force-dynamic";

export default function CampaignsPage() {
  const db = getDb();
  const rows = db
    .select({
      id: schema.campaigns.id,
      name: schema.campaigns.name,
      category: schema.campaigns.category,
      city: schema.campaigns.city,
      createdAt: schema.campaigns.createdAt,
      leadsCount: sql<number>`count(${schema.leads.id})`.as("leads_count"),
    })
    .from(schema.campaigns)
    .leftJoin(schema.leads, eq(schema.leads.campaignId, schema.campaigns.id))
    .groupBy(schema.campaigns.id)
    .orderBy(sql`${schema.campaigns.createdAt} DESC`)
    .all();

  return (
    <div>
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Kampanje</h1>
          <p className="text-sm text-muted-foreground">Grupiši leadove po kampanjama</p>
        </div>
        <CreateCampaignDialog />
      </div>

      <div className="p-6">
        {rows.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="font-semibold">Nema kampanja</h3>
              <p className="mb-4 max-w-sm text-sm text-muted-foreground">
                Kreiraj prvu kampanju da bi mogao da uvoziš leadove. Npr. „Frizeri Beograd“.
              </p>
              <CreateCampaignDialog inline />
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {rows.map((c) => (
              <Link
                key={c.id}
                href={`/campaigns/${c.id}`}
                className="group rounded-lg border bg-card p-4 transition-colors hover:border-primary/50 hover:bg-accent/30"
              >
                <div className="flex items-start justify-between">
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-semibold">{c.name}</h3>
                    <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                      {c.category && <span>{c.category}</span>}
                      {c.city && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {c.city}
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5" />
                </div>
                <div className="mt-3 flex items-center gap-2 text-sm">
                  <span className="flex h-7 items-center rounded-md bg-primary/10 px-2 font-medium text-primary">
                    {c.leadsCount} leadova
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
