"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, MapPin, Search, ExternalLink, Phone, Mail, Star, CheckCircle2, AlertTriangle, ArrowRight } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { startScrapeLeadsJob } from "@/lib/activity-store";

interface ScrapeRow {
  name: string;
  address?: string | null;
  city?: string | null;
  country?: string | null;
  phone_e164?: string | null;
  phone_raw?: string | null;
  website?: string | null;
  email?: string | null;
  category?: string | null;
  rating?: number | null;
  reviews_count?: number | null;
  google_place_id?: string | null;
  google_maps_url?: string | null;
  source?: string | null;
}

interface JobStatus {
  jobId: string;
  status: "queued" | "running" | "done" | "empty" | "captcha" | "failed";
  rowsWritten: number;
  elapsedSec: number;
  error: string | null;
  stage?: string | null;
}

interface ProgressSnapshot {
  last_event?: {
    stage: string;
    event: string;
    count: number;
    total?: number | null;
    message: string;
    timestamp: string;
    data?: Record<string, unknown>;
  };
  last_count?: number;
  last_update?: string;
}

const STAGE_LABEL: Record<string, string> = {
  startup: "Pokretanje",
  search: "Pretraga Google Maps",
  detail: "Ekstrakcija biznisa",
  email: "Izvlačenje email-ova",
  captcha: "Captcha",
  export: "Upis CSV-a",
  done: "Završeno",
};

function formatStage(stage?: string | null): { label: string; icon: string } {
  const s = stage ?? "";
  const label = STAGE_LABEL[s] ?? s;
  return { label, icon: s };
}

const STATUS_LABEL: Record<JobStatus["status"], string> = {
  queued: "queued",
  running: "running",
  done: "done",
  empty: "nema rezultata",
  captcha: "captcha",
  failed: "failed",
};

export function ScrapeLeadsDialog({
  campaignId,
  campaignName,
  defaultCategory,
  defaultCity,
  hasExistingLeads,
}: {
  campaignId: number;
  campaignName: string;
  defaultCategory?: string;
  defaultCity?: string;
  hasExistingLeads?: boolean;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState(defaultCategory ?? "");
  const [city, setCity] = useState(defaultCity ?? "");
  const [country, setCountry] = useState("RS");
  const [maxResults, setMaxResults] = useState(20);
  const [extractEmails, setExtractEmails] = useState(false);
  const [stealth, setStealth] = useState("lite");

  const [job, setJob] = useState<JobStatus | null>(null);
  const [progress, setProgress] = useState<ProgressSnapshot | null>(null);
  const [rows, setRows] = useState<ScrapeRow[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ created: number; updated: number; duplicates: number } | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const isRunning = job?.status === "queued" || job?.status === "running";
  const [scraperDown, setScraperDown] = useState<boolean | null>(null);
  const [scraperDownReason, setScraperDownReason] = useState<string>("");

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
      if (progressRef.current) clearInterval(progressRef.current);
    };
  }, []);

  // Provera da li je scrape-leads servis dostupan — radi se na mount i kad se dialog otvori.
  async function checkScraper() {
    try {
      const r = await fetch("/api/scrape-leads", { cache: "no-store" });
      const d = await r.json();
      if (d?.ok === true) {
        setScraperDown(false);
        setScraperDownReason("");
      } else {
        setScraperDown(true);
        setScraperDownReason(d?.reason || "Servis ne odgovara");
      }
    } catch (e) {
      setScraperDown(true);
      setScraperDownReason(e instanceof Error ? e.message : String(e));
    }
  }

  useEffect(() => {
    checkScraper();
  }, []);

  useEffect(() => {
    if (open) checkScraper();
  }, [open]);

  useEffect(() => {
    if (open && defaultCategory !== undefined) setCategory(defaultCategory);
    if (open && defaultCity !== undefined) setCity(defaultCity);
  }, [open, defaultCategory, defaultCity]);

  function stopPolling() {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (progressRef.current) {
      clearInterval(progressRef.current);
      progressRef.current = null;
    }
  }

  function reset() {
    setJob(null);
    setProgress(null);
    setRows([]);
    setSelected(new Set());
    setImportResult(null);
    stopPolling();
  }

  async function startScrape() {
    if (!category.trim() || !city.trim()) {
      toast({ variant: "destructive", title: "Kategorija i grad su obavezni" });
      return;
    }
    reset();
    try {
      const res = await fetch("/api/scrape-leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: category.trim(),
          city: city.trim(),
          country,
          language: "sr",
          max_results: maxResults,
          extract_emails: extractEmails,
          stealth,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        // Ako je servis down, markiraj da se banner ponovo prikaže
        if (typeof data?.error === "string" && data.error.includes("nije dostupan")) {
          setScraperDown(true);
          setScraperDownReason(data.error);
        }
        throw new Error(data.error || "Greška");
      }
      setScraperDown(false);
      setJob(data);
      // ActivityPanel preuzima dalji polling + prikaz, ali i dalje držimo
      // lokalni polling da bismo znali kad da učitamo redove.
      pollRef.current = setInterval(() => pollStatus(data.jobId), 1500);
      progressRef.current = setInterval(() => pollProgress(data.jobId), 800);
      // Registruj u globalni ActivityPanel (persistuje se u localStorage)
      startScrapeLeadsJob({
        jobId: data.jobId,
        category: category.trim(),
        city: city.trim(),
        maxResults: maxResults,
        extractEmails: extractEmails,
        meta: { campaignId, campaignName },
      });
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    }
  }

  async function pollProgress(jobId: string) {
    try {
      const res = await fetch(`/api/scrape-leads/progress/${jobId}`, { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      setProgress(data.snapshot ?? null);
    } catch {
      // ignore
    }
  }

  async function pollStatus(jobId: string) {
    try {
      const res = await fetch(`/api/scrape-leads/status/${jobId}`, { cache: "no-store" });
      const data = await res.json();
      if (!res.ok) return;
      setJob(data);
      if (data.status === "done") {
        stopPolling();
        await loadRows(jobId);
      } else if (data.status === "empty") {
        stopPolling();
        toast({ title: "Nema rezultata", description: "Probaj drugi grad ili kategoriju." });
      } else if (data.status === "captcha") {
        stopPolling();
        toast({ variant: "destructive", title: "Captcha", description: "Google je blokirao scrape. Sačekaj 10-20 min." });
      } else if (data.status === "failed") {
        stopPolling();
        toast({ variant: "destructive", title: "Scrape failed", description: data.error });
      }
    } catch {
      // ignore poll errors
    }
  }

  async function loadRows(jobId: string) {
    const res = await fetch(`/api/scrape-leads/import/${jobId}`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      toast({ variant: "destructive", title: "Greška", description: data.error });
      return;
    }
    setRows(data.rows);
    setSelected(new Set(data.rows.map((_: ScrapeRow, i: number) => i)));
  }

  function toggleRow(i: number) {
    const next = new Set(selected);
    if (next.has(i)) next.delete(i);
    else next.add(i);
    setSelected(next);
  }
  function toggleAll() {
    if (selected.size === rows.length) setSelected(new Set());
    else setSelected(new Set(rows.map((_, i) => i)));
  }

  async function doImport() {
    if (!job) return;
    const selectedRows = rows.filter((_, i) => selected.has(i));
    if (selectedRows.length === 0) {
      toast({ variant: "destructive", title: "Nema selektovanih" });
      return;
    }
    setImporting(true);
    try {
      const res = await fetch("/api/scrape-leads/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jobId: job.jobId,
          campaignId,
          rows: selectedRows,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      setImportResult({ created: data.created, updated: data.updated ?? 0, duplicates: data.duplicates });
      const parts: string[] = [];
      if (data.created) parts.push(`${data.created} novih`);
      if (data.updated) parts.push(`${data.updated} ažurirano`);
      if (data.duplicates) parts.push(`${data.duplicates} duplikata`);
      toast({ title: "Import završen", description: parts.join(", ") || "0 izmena." });
      router.refresh();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setImporting(false);
    }
  }

  function handleOpenChange(next: boolean) {
    setOpen(next);
    if (!next) reset();
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          title={
            hasExistingLeads
              ? "Ponovo scrape-uj Google Maps za ovu kampanju. Postojeći leadovi se NE brišu — dodaju se samo novi (po dedup_key)."
              : "Pronađi biznise u Google Maps i uvezi ih u kampanju."
          }
        >
          <MapPin className="h-4 w-4" />
          {hasExistingLeads ? "Rescrape Google Maps" : "Scrape Google Maps"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Scrape iz Google Maps</DialogTitle>
          <DialogDescription>
            Pronađi biznise po (kategorija, grad) i uvezi ih u kampanju „{campaignName}“.
          </DialogDescription>
        </DialogHeader>

        {!job && (
          <div className="space-y-3">
            {scraperDown === true && (
              <div className="rounded-md border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-destructive">Scrape-leads servis nije pokrenut</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Pokreni ga u terminalu (drugi prozor):
                    </p>
                    <pre className="mt-1 overflow-x-auto rounded bg-muted px-2 py-1 text-xs">
                      <code>cd scraper-leads && uv run python -m maps_cold_calling.api</code>
                    </pre>
                    <p className="mt-1 truncate text-xs text-muted-foreground" title={scraperDownReason}>
                      Detalji: {scraperDownReason}
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2"
                      onClick={checkScraper}
                    >
                      Probaj ponovo
                    </Button>
                  </div>
                </div>
              </div>
            )}
            {scraperDown === false && hasExistingLeads && (
              <div className="rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                <strong>Rescrape.</strong> Postojeći leadovi se neće izbrisati — novi rezultati
                se dodaju po <code>dedup_key</code> (website / telefon / ime+grad). Ako neki
                biznis iz scrape-a već postoji, ignoriše se.
              </div>
            )}
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <Label htmlFor="scrape-cat" className="mb-1.5 block">Kategorija *</Label>
                <Input
                  id="scrape-cat"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="npr. frizerski salon"
                  autoFocus
                />
              </div>
              <div>
                <Label htmlFor="scrape-city" className="mb-1.5 block">Grad *</Label>
                <Input
                  id="scrape-city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="npr. Beograd"
                />
              </div>
              <div>
                <Label htmlFor="scrape-country" className="mb-1.5 block">Država</Label>
                <Input
                  id="scrape-country"
                  value={country}
                  onChange={(e) => setCountry(e.target.value.toUpperCase())}
                  maxLength={2}
                />
              </div>
              <div>
                <Label htmlFor="scrape-max" className="mb-1.5 block">Max rezultata</Label>
                <Input
                  id="scrape-max"
                  type="number"
                  min={1}
                  max={500}
                  value={maxResults}
                  onChange={(e) => setMaxResults(Number(e.target.value) || 20)}
                />
              </div>
              <div>
                <Label htmlFor="scrape-stealth" className="mb-1.5 block">Stealth tier</Label>
                <Select value={stealth} onValueChange={setStealth}>
                  <SelectTrigger id="scrape-stealth">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="off">off (debug)</SelectItem>
                    <SelectItem value="lite">lite (preporučeno)</SelectItem>
                    <SelectItem value="standard">standard</SelectItem>
                    <SelectItem value="aggressive">aggressive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end pb-1">
                <label className="flex cursor-pointer items-center gap-2 text-sm">
                  <Checkbox checked={extractEmails} onCheckedChange={(v) => setExtractEmails(!!v)} />
                  Pokušaj izvući email (sporije)
                </label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => handleOpenChange(false)}>
                Otkaži
              </Button>
              <Button onClick={startScrape} disabled={scraperDown === true}>
                <Search className="h-4 w-4" />
                {hasExistingLeads ? "Pokreni rescrape" : "Pokreni scrape"}
              </Button>
            </DialogFooter>
          </div>
        )}

        {job && rows.length === 0 && (
          <div className="space-y-3 py-6">
            <div className="text-center">
              <Loader2 className="mx-auto h-7 w-7 animate-spin text-primary" />
              <p className="mt-2 font-medium">Scrape u toku…</p>
              <p className="text-xs text-muted-foreground">
                Status: <strong>{STATUS_LABEL[job.status]}</strong>
                {job.status === "running" && ` · ${job.elapsedSec.toFixed(0)}s`}
              </p>
            </div>

            {/* Live progress iz v3 progress.py */}
            {progress?.last_event && (
              <div className="rounded-md border bg-muted/30 p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{STAGE_LABEL[progress.last_event.stage] ?? progress.last_event.stage}</span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {progress.last_event.count}
                    {progress.last_event.total ? ` / ${progress.last_event.total}` : ""}
                  </span>
                </div>
                {progress.last_event.total && progress.last_event.total > 0 && (
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${Math.min(100, (progress.last_event.count / progress.last_event.total) * 100)}%` }}
                    />
                  </div>
                )}
                {progress.last_event.message && (
                  <p className="mt-2 truncate text-xs text-muted-foreground">{progress.last_event.message}</p>
                )}
              </div>
            )}

            {job.error && (
              <div className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                <AlertTriangle className="mr-1 inline h-3.5 w-3.5" />
                {job.error}
              </div>
            )}
            {job.status === "failed" || job.status === "captcha" || job.status === "empty" ? (
              <div className="text-center">
                <Button variant="outline" onClick={reset}>
                  Probaj ponovo
                </Button>
              </div>
            ) : null}
          </div>
        )}

        {rows.length > 0 && job && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border bg-muted/30 px-3 py-2 text-sm">
              <div>
                <strong>{rows.length}</strong> pronađeno ·{" "}
                <strong>{selected.size}</strong> selektovano
                {importResult && (
                  <span className="ml-2 text-green-700">
                    · {importResult.created} novih, {importResult.updated} ažurirano, {importResult.duplicates} preskočeno
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={toggleAll}>
                  {selected.size === rows.length ? "Deselektuj sve" : "Selektuj sve"}
                </Button>
              </div>
            </div>

            <div className="max-h-[50vh] divide-y overflow-y-auto rounded-md border">
              {rows.map((row, i) => (
                <label
                  key={`${row.google_place_id ?? row.name}-${i}`}
                  className="flex cursor-pointer items-start gap-3 p-3 hover:bg-accent/30"
                >
                  <Checkbox
                    checked={selected.has(i)}
                    onCheckedChange={() => toggleRow(i)}
                    className="mt-1"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="truncate font-medium">{row.name}</p>
                      {row.category && <Badge variant="secondary">{row.category}</Badge>}
                    </div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      {row.address && <span>{row.address}</span>}
                      {row.phone_e164 && (
                        <span className="flex items-center gap-1">
                          <Phone className="h-3 w-3" />
                          {row.phone_e164}
                        </span>
                      )}
                      {row.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {row.email}
                        </span>
                      )}
                      {row.website && (
                        <a
                          href={`https://${row.website}`}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 hover:text-primary"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <ExternalLink className="h-3 w-3" />
                          {row.website}
                        </a>
                      )}
                      {row.rating && (
                        <span className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                          {row.rating.toFixed(1)} ({row.reviews_count ?? 0})
                        </span>
                      )}
                    </div>
                  </div>
                </label>
              ))}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => handleOpenChange(false)}>
                {importResult ? "Zatvori" : "Otkaži"}
              </Button>
              <Button onClick={doImport} disabled={importing || selected.size === 0 || !!importResult}>
                {importing ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : importResult ? (
                  <CheckCircle2 className="h-4 w-4" />
                ) : (
                  <ArrowRight className="h-4 w-4" />
                )}
                {importResult ? "Gotovo" : `Importuj ${selected.size}`}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}