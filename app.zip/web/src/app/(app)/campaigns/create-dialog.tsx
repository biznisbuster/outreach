"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Plus, Loader2 } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export function CreateCampaignDialog({ inline = false }: { inline?: boolean }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [city, setCity] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function create() {
    if (!name.trim()) return;
    setLoading(true);
    const res = await fetch("/api/campaigns", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, category, city }),
    });
    setLoading(false);
    if (!res.ok) {
      toast({ variant: "destructive", title: "Greška", description: "Kampanja nije kreirana." });
      return;
    }
    const data = await res.json();
    toast({ title: "Kreirano", description: `Kampanja „${name}“ je kreirana.` });
    setOpen(false);
    setName("");
    setCategory("");
    setCity("");
    router.push(`/campaigns/${data.id}`);
    router.refresh();
  }

  const trigger = inline ? (
    <Button onClick={() => setOpen(true)}>
      <Plus className="h-4 w-4" />
      Nova kampanja
    </Button>
  ) : (
    <Button onClick={() => setOpen(true)}>
      <Plus className="h-4 w-4" />
      Nova kampanja
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nova kampanja</DialogTitle>
          <DialogDescription>Grupa leadova (npr. „Frizeri Beograd“).</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="c-name">Naziv *</Label>
            <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="c-cat">Kategorija</Label>
              <Input id="c-cat" value={category} onChange={(e) => setCategory(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="c-city">Grad</Label>
              <Input id="c-city" value={city} onChange={(e) => setCity(e.target.value)} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Otkaži
          </Button>
          <Button onClick={create} disabled={loading || !name.trim()}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Kreiraj
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
