import Link from "next/link";
import { getDb, schema } from "@/lib/db";
import { eq, sql, asc } from "drizzle-orm";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, Users, UserPlus } from "lucide-react";
import { LeadsTable } from "@/components/leads-table";
import { CampaignSequences } from "@/components/campaign-sequences";
import { ScrapeLeadsDialog } from "../scrape-dialog";

export const dynamic = "force-dynamic";

export default async function CampaignPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: idStr } = await params;
  const db = getDb();
  const id = Number(idStr);
  const [campaign] = db.select().from(schema.campaigns).where(eq(schema.campaigns.id, id)).all();
  if (!campaign) {
    return (
      <div className="p-6">
        <p className="text-muted-foreground">Kampanja nije pronađena.</p>
        <Button asChild variant="link" className="px-0">
          <Link href="/campaigns">← Nazad na kampanje</Link>
        </Button>
      </div>
    );
  }

  const statuses = db.select().from(schema.statuses).orderBy(asc(schema.statuses.sortOrder)).all();
  const count = db
    .select({ c: sql<number>`count(*)` })
    .from(schema.leads)
    .where(eq(schema.leads.campaignId, id))
    .all()[0]?.c ?? 0;

  const actions = (
    <>
      <ScrapeLeadsDialog
        campaignId={id}
        campaignName={campaign.name}
        defaultCategory={campaign.category ?? ""}
        defaultCity={campaign.city ?? ""}
        hasExistingLeads={count > 0}
      />
      <Button asChild variant="outline">
        <Link href={`/leads/new?campaignId=${id}`}>
          <UserPlus className="h-4 w-4" />
          Dodaj klijenta
        </Link>
      </Button>
      <Button asChild variant="outline">
        <Link href={`/import?campaignId=${id}`}>
          <Upload className="h-4 w-4" />
          Uvezi leadove
        </Link>
      </Button>
    </>
  );

  return (
    <div>
      <div className="border-b px-6 py-4">
        <Link href="/campaigns" className="mb-2 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" />
          Kampanje
        </Link>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight">{campaign.name}</h1>
            <p className="text-sm text-muted-foreground">
              {[campaign.category, campaign.city].filter(Boolean).join(" · ") || "Bez kategorije"} · {count} leadova
            </p>
          </div>
          <div className="flex items-center gap-2">{actions}</div>
        </div>
      </div>

      <div className="space-y-6 p-6">
        {count === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-lg border bg-card py-16 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="font-semibold">Nema leadova u ovoj kampanji</h3>
            <p className="mb-4 max-w-sm text-sm text-muted-foreground">
              Dodaj ručno, uvezi CSV/JSON, ili pokreni scrape sa Google Maps.
            </p>
            <div className="flex items-center gap-2">{actions}</div>
          </div>
        ) : (
          <>
            <LeadsTable campaignId={id} statuses={statuses} cities={[]} maxHeight="600px" />
            <CampaignSequences campaignId={id} />
          </>
        )}
      </div>
    </div>
  );
}