import Link from "next/link";
import { getDb, schema } from "@/lib/db";
import { count, eq, gte, and, sql } from "drizzle-orm";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Send, Inbox, TrendingUp, Mail, AlertCircle, Phone, Upload, UserPlus, FileText } from "lucide-react";
import { formatNumber } from "@/lib/utils";
import { ChatPanel } from "@/components/chat-panel";
import { getCallTodo } from "@/lib/dashboard";
import { TodoRow } from "./todo-row";

function sinceDays(days: number): number {
  return Date.now() - days * 24 * 60 * 60 * 1000;
}

export default async function DashboardPage() {
  const db = getDb();

  const totalLeads = db.select({ c: count() }).from(schema.leads).all()[0]?.c ?? 0;
  const totalCampaigns = db.select({ c: count() }).from(schema.campaigns).all()[0]?.c ?? 0;

  // Sent u poslednjih 7d
  const sent7d = db
    .select({ c: count() })
    .from(schema.emailSends)
    .where(and(eq(schema.emailSends.status, "sent"), gte(schema.emailSends.sentAt, new Date(sinceDays(7)))))
    .all()[0]?.c ?? 0;

  // Reply rate — samo nad poslatim u poslednjih 30d da bude smislen
  const sent30d = db
    .select({ c: count() })
    .from(schema.emailSends)
    .where(and(eq(schema.emailSends.status, "sent"), gte(schema.emailSends.sentAt, new Date(sinceDays(30)))))
    .all()[0]?.c ?? 0;
  const replied30d = db
    .select({ c: count() })
    .from(schema.emailSends)
    .where(and(eq(schema.emailSends.status, "sent"), gte(schema.emailSends.sentAt, new Date(sinceDays(30))), eq(schema.emailSends.replied, true)))
    .all()[0]?.c ?? 0;
  const replyRate = sent30d > 0 ? Math.round((replied30d / sent30d) * 100) : 0;

  const queuedCount = db.select({ c: count() }).from(schema.emailSends).where(eq(schema.emailSends.status, "queued")).all()[0]?.c ?? 0;
  const draftsCount = db.select({ c: count() }).from(schema.emailSends).where(eq(schema.emailSends.status, "draft")).all()[0]?.c ?? 0;
  const leadsWithoutWebsite = db
    .select({ c: count() })
    .from(schema.leads)
    .where(sql`${schema.leads.websiteNormalized} IS NULL`)
    .all()[0]?.c ?? 0;

  // Status distribucija (apsolutni brojevi, bez procenata)
  const statusRows = db
    .select({ name: schema.statuses.name, color: schema.statuses.color, n: count() })
    .from(schema.leads)
    .innerJoin(schema.statuses, eq(schema.leads.statusId, schema.statuses.id))
    .groupBy(schema.statuses.id)
    .orderBy(sql`count() desc`)
    .limit(5)
    .all();
  const leadsWithStatus = statusRows.reduce((a, s) => a + Number(s.n), 0);

  const todoItems = await getCallTodo(20);

  const kpis = [
    { label: "Leadovi", value: totalLeads, icon: Users, hint: `${totalCampaigns} kampanja` },
    { label: "Poslato (7d)", value: sent7d, icon: Send, hint: `${replied30d} odgovora (30d)` },
    { label: "Reply rate", value: sent30d > 0 ? `${replyRate}%` : "—", icon: TrendingUp, hint: `poslednjih 30d` },
    { label: "U redu", value: queuedCount, icon: Inbox, hint: `${draftsCount} draftova` },
  ];

  return (
    <div>
      <div className="border-b px-6 py-4">
        <h1 className="text-xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Pregled aktivnosti i to-do za danas</p>
      </div>

      <div className="space-y-6 p-6">
        {/* KPI */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {kpis.map((k) => {
            const Icon = k.icon;
            return (
              <Card key={k.label}>
                <CardContent className="flex items-center justify-between p-5">
                  <div>
                    <p className="text-sm text-muted-foreground">{k.label}</p>
                    <p className="text-2xl font-bold">{k.value}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{k.hint}</p>
                  </div>
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Za zvanje danas — glavni fokus */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Phone className="h-4 w-4 text-primary" />
                  Za zvanje danas
                </CardTitle>
                <CardDescription>
                  Follow-up koji kasni + aktivni leadovi bez kontakta 5+ dana
                </CardDescription>
              </div>
              <span className="text-sm font-medium text-muted-foreground">
                {todoItems.length} {todoItems.length === 1 ? "lead" : "leadova"}
              </span>
            </div>
          </CardHeader>
          <CardContent>
            {todoItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-center text-sm text-muted-foreground">
                <Phone className="mb-2 h-10 w-10" />
                <p className="font-medium">Nema hitnih poziva.</p>
                <p>Svi aktivni leadovi su kontaktirani u poslednjih 5 dana.</p>
              </div>
            ) : (
              <div className="space-y-1">
                {todoItems.map((it) => (
                  <TodoRow
                    key={it.leadId}
                    leadId={it.leadId}
                    name={it.name}
                    city={it.city}
                    phoneE164={it.phoneE164}
                    statusName={it.statusName}
                    statusColor={it.statusColor}
                    reason={it.reason}
                    daysOverdue={it.daysOverdue}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-4 lg:grid-cols-3">
          {/* Status distribucija */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">Leadovi po statusu</CardTitle>
              <CardDescription>
                {leadsWithStatus > 0 ? `${leadsWithStatus} leadova sa statusom` : "Nema leadova sa statusom"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {statusRows.length === 0 ? (
                <EmptyState
                  icon={<Users className="h-8 w-8" />}
                  title="Nema leadova"
                  desc="Dodaj leadove da počneš — ručno ili kroz import."
                  cta={{ href: "/leads/new", label: "Dodaj prvog klijenta" }}
                />
              ) : (
                <div className="space-y-3">
                  {statusRows.map((s) => {
                    const pct = leadsWithStatus > 0 ? Math.round((Number(s.n) / leadsWithStatus) * 100) : 0;
                    return (
                      <div key={s.name}>
                        <div className="mb-1 flex items-center justify-between text-sm">
                          <div className="flex items-center gap-2">
                            <span className="h-2.5 w-2.5 rounded-full" style={{ background: s.color }} />
                            <span className="font-medium">{s.name}</span>
                          </div>
                          <span className="text-muted-foreground">
                            {formatNumber(s.n)} · {pct}%
                          </span>
                        </div>
                        <div className="h-2 overflow-hidden rounded-full bg-muted">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: s.color }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Alerti */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <AlertCircle className="h-4 w-4 text-amber-500" />
                Alerti
              </CardTitle>
              <CardDescription>Stvari koje treba obraditi</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <AlertRow count={draftsCount} label="Draftova čeka na pregled" href="/queue" />
              <AlertRow count={leadsWithoutWebsite} label="Leadova bez website-a" href="/campaigns" />
              <AlertRow count={queuedCount} label="Emailova u redu slanja" href="/queue" />
              {draftsCount === 0 && leadsWithoutWebsite === 0 && queuedCount === 0 && (
                <p className="py-4 text-center text-muted-foreground">Sve čisto. Nema hitnih obaveza.</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Brze akcije</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <QuickAction href="/import" icon={<Upload className="h-4 w-4" />} label="Uvezi CSV" />
              <QuickAction href="/leads/new" icon={<UserPlus className="h-4 w-4" />} label="Dodaj ručno" />
              <QuickAction href="/campaigns" icon={<Users className="h-4 w-4" />} label="Otvori kampanje" />
              <QuickAction href="/templates" icon={<FileText className="h-4 w-4" />} label="Uredi šablone" />
            </div>
          </CardContent>
        </Card>
      </div>
      <ChatPanel />
    </div>
  );
}

function AlertRow({ count, label, href }: { count: number; label: string; href: string }) {
  if (count === 0) return null;
  return (
    <Link href={href} className="flex items-center justify-between rounded-md bg-amber-50 px-3 py-2 transition-colors hover:bg-amber-100">
      <span className="text-amber-900">{label}</span>
      <span className="font-semibold text-amber-900">{count}</span>
    </Link>
  );
}

function QuickAction({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link href={href} className="flex items-center gap-2 rounded-md border p-3 text-sm font-medium transition-colors hover:bg-accent">
      <span className="text-primary">{icon}</span>
      {label}
    </Link>
  );
}

function EmptyState({ icon, title, desc, cta }: { icon: React.ReactNode; title: string; desc: string; cta?: { href: string; label: string } }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-muted text-muted-foreground">{icon}</div>
      <p className="font-medium">{title}</p>
      <p className="mb-3 text-sm text-muted-foreground">{desc}</p>
      {cta && (
        <Link href={cta.href} className="text-sm font-medium text-primary hover:underline">
          {cta.label}
        </Link>
      )}
    </div>
  );
}