"use client";

import Link from "next/link";
import { Phone, ArrowRight } from "lucide-react";

interface TodoRowProps {
  leadId: number;
  name: string;
  city: string | null;
  phoneE164: string | null;
  statusName: string | null;
  statusColor: string | null;
  reason: "followup_due" | "no_contact";
  daysOverdue: number;
}

export function TodoRow(props: TodoRowProps) {
  const { leadId, name, city, phoneE164, statusName, statusColor, reason, daysOverdue } = props;
  return (
    <div className="flex items-center justify-between rounded-md border bg-card p-3 transition-colors hover:bg-accent">
      <Link href={`/leads/${leadId}`} className="flex min-w-0 flex-1 items-center gap-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Phone className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="truncate font-medium">{name}</p>
            {statusName && (
              <span
                className="shrink-0 rounded px-1.5 py-0.5 text-xs"
                style={{ backgroundColor: `${statusColor}20`, color: statusColor || undefined }}
              >
                {statusName}
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {city || "—"}
            {phoneE164 && <> · {phoneE164}</>}
          </p>
        </div>
      </Link>
      <div className="ml-2 flex shrink-0 items-center gap-2 text-right">
        <div className="text-xs">
          <p className={reason === "followup_due" ? "font-medium text-amber-700" : "font-medium text-slate-700"}>
            {reason === "followup_due" ? "Follow-up kasni" : "Nema kontakta"}
          </p>
          <p className="text-muted-foreground">
            {daysOverdue > 0 ? `pre ${daysOverdue} d` : "danas"}
          </p>
        </div>
        <Link href={`/leads/${leadId}`} aria-label="Otvori lead">
          <ArrowRight className="h-4 w-4 text-muted-foreground" />
        </Link>
      </div>
    </div>
  );
}