import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getDb, schema } from "@/lib/db";
import { asc } from "drizzle-orm";
import { NewLeadForm } from "./form";

export const dynamic = "force-dynamic";

export default async function NewLeadPage({
  searchParams,
}: {
  searchParams: Promise<{ campaignId?: string }>;
}) {
  const session = await getServerSession(authOptions);
  if (!session) redirect("/login");
  const { campaignId } = await searchParams;
  const db = getDb();
  const campaigns = db
    .select({ id: schema.campaigns.id, name: schema.campaigns.name })
    .from(schema.campaigns)
    .orderBy(asc(schema.campaigns.name))
    .all();

  const preselectId = campaignId ? Number(campaignId) : null;

  return (
    <div>
      <div className="border-b px-6 py-4">
        <h1 className="text-xl font-bold tracking-tight">Dodaj klijenta</h1>
        <p className="text-sm text-muted-foreground">Ručni unos jednog leada — bez CSV/JSON importa.</p>
      </div>
      <div className="p-6">
        <NewLeadForm campaigns={campaigns} preselectCampaignId={preselectId} />
      </div>
    </div>
  );
}