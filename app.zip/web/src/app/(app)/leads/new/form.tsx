"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Loader2, UserPlus, ExternalLink } from "lucide-react";
import Link from "next/link";
import { toast } from "@/components/ui/use-toast";

interface CampaignOption {
  id: number;
  name: string;
}

export function NewLeadForm({
  campaigns,
  preselectCampaignId,
}: {
  campaigns: CampaignOption[];
  preselectCampaignId: number | null;
}) {
  const router = useRouter();
  const initialCampaignId = preselectCampaignId
    ? String(preselectCampaignId)
    : campaigns[0]
      ? String(campaigns[0].id)
      : "";
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    name: "",
    campaignId: initialCampaignId,
    category: "",
    email: "",
    phoneRaw: "",
    websiteRaw: "",
    address: "",
    city: "",
    postalCode: "",
    googleRating: "",
    reviewsCount: "",
    source: "manual",
    notes: "",
  });

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.city.trim() || !form.campaignId) {
      toast({ variant: "destructive", title: "Naziv, kampanja i grad su obavezni." });
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        name: form.name.trim(),
        campaignId: Number(form.campaignId),
        category: form.category.trim() || null,
        email: form.email.trim() || null,
        phoneRaw: form.phoneRaw.trim() || null,
        websiteRaw: form.websiteRaw.trim() || null,
        address: form.address.trim() || null,
        city: form.city.trim(),
        postalCode: form.postalCode.trim() || null,
        googleRating: form.googleRating ? Number(form.googleRating) : null,
        reviewsCount: form.reviewsCount ? Number(form.reviewsCount) : null,
        source: form.source.trim() || null,
        sourceUrl: null,
      };
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (res.status === 409) {
        toast({
          variant: "destructive",
          title: "Lead već postoji",
          description: (
            <span>
              {data.error} —{" "}
              <Link href={`/leads/${data.existingId}`} className="font-medium text-primary underline">
                otvori postojećeg
              </Link>
            </span>
          ),
        });
        return;
      }
      if (!res.ok) {
        throw new Error(data.error || "Greška pri kreaciji");
      }
      toast({ title: "Klijent dodat", description: form.name });
      router.push(`/leads/${data.id}`);
      router.refresh();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setSubmitting(false);
    }
  }

  if (campaigns.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <p className="font-medium">Nema kampanja</p>
          <p className="mb-4 max-w-sm text-sm text-muted-foreground">
            Pre dodavanja leada moraš kreirati bar jednu kampanju.
          </p>
          <Button asChild>
            <Link href="/campaigns">Kreiraj kampanju</Link>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <form onSubmit={onSubmit} className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost" size="sm" type="button">
          <Link href="/campaigns">
            <ArrowLeft className="h-4 w-4" />
            Nazad
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Osnovno</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Naziv *" htmlFor="name">
            <Input
              id="name"
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              placeholder="npr. Frizerski salon Marko"
              required
            />
          </Field>
          <Field label="Kampanja *" htmlFor="campaign">
            <Select value={form.campaignId} onValueChange={(v) => update("campaignId", v)}>
              <SelectTrigger id="campaign">
                <SelectValue placeholder="Izaberi kampanju" />
              </SelectTrigger>
              <SelectContent>
                {campaigns.map((c) => (
                  <SelectItem key={c.id} value={String(c.id)}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Kategorija" htmlFor="category">
            <Input
              id="category"
              value={form.category}
              onChange={(e) => update("category", e.target.value)}
              placeholder="npr. Frizerski salon"
            />
          </Field>
          <Field label="Grad *" htmlFor="city">
            <Input
              id="city"
              value={form.city}
              onChange={(e) => update("city", e.target.value)}
              placeholder="npr. Beograd"
              required
            />
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Kontakt</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Email" htmlFor="email">
            <Input
              id="email"
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="kontakt@primer.rs"
            />
          </Field>
          <Field label="Telefon" htmlFor="phone">
            <Input
              id="phone"
              value={form.phoneRaw}
              onChange={(e) => update("phoneRaw", e.target.value)}
              placeholder="+381 64 123 4567"
            />
          </Field>
          <Field label="Website" htmlFor="website" className="sm:col-span-2">
            <Input
              id="website"
              value={form.websiteRaw}
              onChange={(e) => update("websiteRaw", e.target.value)}
              placeholder="www.primer.rs"
            />
          </Field>
          <Field label="Adresa" htmlFor="address" className="sm:col-span-2">
            <Input
              id="address"
              value={form.address}
              onChange={(e) => update("address", e.target.value)}
              placeholder="Knez Mihailova 10"
            />
          </Field>
          <Field label="Poštanski broj" htmlFor="postal">
            <Input
              id="postal"
              value={form.postalCode}
              onChange={(e) => update("postalCode", e.target.value)}
              placeholder="11000"
            />
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Google reputacija</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Google ocena (1–5)" htmlFor="rating">
            <Input
              id="rating"
              type="number"
              min={1}
              max={5}
              step="0.1"
              value={form.googleRating}
              onChange={(e) => update("googleRating", e.target.value)}
              placeholder="4.6"
            />
          </Field>
          <Field label="Broj recenzija" htmlFor="reviews">
            <Input
              id="reviews"
              type="number"
              min={0}
              value={form.reviewsCount}
              onChange={(e) => update("reviewsCount", e.target.value)}
              placeholder="123"
            />
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Izvor</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Izvor" htmlFor="source">
            <Input
              id="source"
              value={form.source}
              onChange={(e) => update("source", e.target.value)}
              placeholder="manual / google / preporuka"
            />
          </Field>
        </CardContent>
      </Card>

      <div className="flex items-center justify-end gap-2">
        <Button asChild variant="outline" type="button">
          <Link href="/campaigns">Otkaži</Link>
        </Button>
        <Button type="submit" disabled={submitting}>
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
          Dodaj klijenta
        </Button>
      </div>
    </form>
  );
}

function Field({
  label,
  htmlFor,
  children,
  className,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label htmlFor={htmlFor} className="mb-1.5 block">
        {label}
      </Label>
      {children}
    </div>
  );
}