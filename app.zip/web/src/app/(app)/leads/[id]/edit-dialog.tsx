"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Save } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface LeadEditable {
  name: string;
  category: string | null;
  phoneRaw: string | null;
  email: string | null;
  websiteRaw: string | null;
  address: string | null;
  city: string | null;
  postalCode: string | null;
  googleRating: number | null;
  reviewsCount: number | null;
  source: string | null;
  sourceUrl: string | null;
}

export function EditLeadDialog({
  leadId,
  initial,
  onSaved,
}: {
  leadId: number;
  initial: LeadEditable;
  onSaved: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<LeadEditable>(initial);

  useEffect(() => {
    if (open) setForm(initial);
  }, [open, initial]);

  function update<K extends keyof LeadEditable>(key: K, value: LeadEditable[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function save() {
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        category: form.category?.trim() || null,
        phoneRaw: form.phoneRaw?.trim() || null,
        email: form.email?.trim() || null,
        websiteRaw: form.websiteRaw?.trim() || null,
        address: form.address?.trim() || null,
        city: form.city?.trim() || null,
        postalCode: form.postalCode?.trim() || null,
        googleRating: form.googleRating,
        reviewsCount: form.reviewsCount,
        source: form.source?.trim() || null,
        sourceUrl: form.sourceUrl?.trim() || null,
      };
      const res = await fetch(`/api/leads/${leadId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška pri čuvanju");
      toast({ title: "Sačuvano" });
      setOpen(false);
      onSaved();
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        Edit
      </Button>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Izmeni podatke o leadu</DialogTitle>
          <DialogDescription>Ispravi kontakt podatke i izvor. Status, komentari i email ostaju na svojim mestima.</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Naziv *" htmlFor="edit-name">
            <Input id="edit-name" value={form.name} onChange={(e) => update("name", e.target.value)} />
          </Field>
          <Field label="Kategorija" htmlFor="edit-category">
            <Input id="edit-category" value={form.category ?? ""} onChange={(e) => update("category", e.target.value || null)} />
          </Field>
          <Field label="Telefon" htmlFor="edit-phone">
            <Input id="edit-phone" value={form.phoneRaw ?? ""} onChange={(e) => update("phoneRaw", e.target.value || null)} placeholder="+381 64 123 4567" />
          </Field>
          <Field label="Email" htmlFor="edit-email">
            <Input id="edit-email" type="email" value={form.email ?? ""} onChange={(e) => update("email", e.target.value || null)} />
          </Field>
          <Field label="Website" htmlFor="edit-website" className="sm:col-span-2">
            <Input id="edit-website" value={form.websiteRaw ?? ""} onChange={(e) => update("websiteRaw", e.target.value || null)} placeholder="www.primer.rs" />
          </Field>
          <Field label="Adresa" htmlFor="edit-address" className="sm:col-span-2">
            <Input id="edit-address" value={form.address ?? ""} onChange={(e) => update("address", e.target.value || null)} />
          </Field>
          <Field label="Grad" htmlFor="edit-city">
            <Input id="edit-city" value={form.city ?? ""} onChange={(e) => update("city", e.target.value || null)} />
          </Field>
          <Field label="Poštanski broj" htmlFor="edit-postal">
            <Input id="edit-postal" value={form.postalCode ?? ""} onChange={(e) => update("postalCode", e.target.value || null)} />
          </Field>
          <Field label="Google ocena (1–5)" htmlFor="edit-rating">
            <Input
              id="edit-rating"
              type="number"
              min={1}
              max={5}
              step="0.1"
              value={form.googleRating ?? ""}
              onChange={(e) => update("googleRating", e.target.value === "" ? null : Number(e.target.value))}
            />
          </Field>
          <Field label="Broj recenzija" htmlFor="edit-reviews">
            <Input
              id="edit-reviews"
              type="number"
              min={0}
              value={form.reviewsCount ?? ""}
              onChange={(e) => update("reviewsCount", e.target.value === "" ? null : Number(e.target.value))}
            />
          </Field>
          <Field label="Izvor" htmlFor="edit-source">
            <Input id="edit-source" value={form.source ?? ""} onChange={(e) => update("source", e.target.value || null)} />
          </Field>
          <Field label="Izvor URL" htmlFor="edit-sourceUrl">
            <Input id="edit-sourceUrl" value={form.sourceUrl ?? ""} onChange={(e) => update("sourceUrl", e.target.value || null)} placeholder="https://..." />
          </Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>
            Otkaži
          </Button>
          <Button onClick={save} disabled={saving || !form.name.trim()}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Sačuvaj
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({
  label,
  htmlFor,
  children,
  className,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <Label htmlFor={htmlFor} className="mb-1.5 block">
        {label}
      </Label>
      {children}
    </div>
  );
}