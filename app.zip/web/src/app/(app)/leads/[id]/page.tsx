"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ArrowLeft,
  Phone,
  Mail,
  Globe,
  MapPin,
  Star,
  MessageSquare,
  Loader2,
  Send,
  ExternalLink,
  Ban,
  Camera,
  Activity,
  Sparkles,
  AlertTriangle,
  Search,
  CheckCircle2,
} from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { formatDate } from "@/lib/utils";
import { EmailDraftEditor, GenerateEmailButton } from "@/components/email-draft-editor";
import { EditLeadDialog } from "./edit-dialog";
import { startLeadScrapeJob } from "@/lib/activity-store";

interface LeadData {
  id: number;
  name: string;
  category: string | null;
  phoneRaw: string | null;
  phoneE164: string | null;
  email: string | null;
  websiteRaw: string | null;
  websiteNormalized: string | null;
  address: string | null;
  city: string | null;
  postalCode: string | null;
  googleRating: number | null;
  reviewsCount: number | null;
  source: string | null;
  sourceUrl: string | null;
  statusId: number | null;
  statusName: string | null;
  statusColor: string | null;
  doNotContact: boolean;
  createdAt: number | null;
  comments: { id: number; body: string; createdAt: number | null }[];
  analysis: {
    visualScore: number | null;
    seoScore: number | null;
    overallScore: number | null;
    aiSummary: string | null;
    issuesJson: string | null;
    visualNotes: string | null;
  } | null;
  emailSends: {
    id: number;
    subject: string;
    body: string;
    status: string;
    generatedByAi: boolean;
    reviewed: boolean;
    sentAt: number | null;
    queuedAt: number | null;
    replied: boolean;
  }[];
  screenshots?: { id: number; path: string }[];
  blocked: boolean;
}

export default function LeadDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const [lead, setLead] = useState<LeadData | null>(null);
  const [statuses, setStatuses] = useState<{ id: number; name: string; color: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [comment, setComment] = useState("");
  const [postingComment, setPostingComment] = useState(false);
  const [scraping, setScraping] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [enriching, setEnriching] = useState(false);
  const [enrichStatus, setEnrichStatus] = useState<string | null>(null);
  // Inline job status (kad scrape/analyze traje — vidljivo na samoj stranici)
  const [scrapeJobStatus, setScrapeJobStatus] = useState<{
    status: string;
    pages: number;
    total: number;
    hasScreenshot: boolean;
  } | null>(null);
  const [analyzeJobStatus, setAnalyzeJobStatus] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [leadRes, statusRes] = await Promise.all([fetch(`/api/leads/${id}`), fetch("/api/statuses")]);
    const leadData = leadRes.ok ? await leadRes.json() : null;
    const statusData = statusRes.ok ? await statusRes.json() : [];
    if (!leadRes.ok) {
      toast({ variant: "destructive", title: "Greška", description: "Sesija je istekla ili lead nije dostupan." });
    }
    setLead(leadData);
    setStatuses(statusData);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

// Auto-screenshot: ako je uključeno u settings i lead ima website,
// a nema još screenshot-а — pokreni scrape u pozadini posle load-a.
  const [autoScrapeOn, setAutoScrapeOn] = useState<boolean | null>(null);
  const autoScreenshotTriggered = useRef(false);

  useEffect(() => {
    let cancelled = false;
    void fetch("/api/settings/auto-screenshot")
      .then((r) => (r.ok ? r.json() : { enabled: false }))
      .then((d) => {
        if (!cancelled) setAutoScrapeOn(!!d.enabled);
      })
      .catch(() => {
        if (!cancelled) setAutoScrapeOn(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!autoScrapeOn) return;
    if (autoScreenshotTriggered.current) return;
    if (!lead) return;
    if (!lead.websiteNormalized) return;
    if (lead.screenshots && lead.screenshots.length > 0) return;
    autoScreenshotTriggered.current = true;
    void fetch("/api/scrape", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ leadId: Number(id) }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.ok) {
          toast({ title: "Auto-scrape pokrenut", description: "Screenshot se priprema u pozadini." });
        }
      })
      .catch(() => {});
  }, [autoScrapeOn, lead, id]);

  async function changeStatus(statusId: string) {
    const res = await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ statusId: Number(statusId) }),
    });
    if (res.ok) {
      toast({ title: "Status ažuriran" });
      load();
    }
  }

  async function addComment() {
    if (!comment.trim()) return;
    setPostingComment(true);
    const res = await fetch(`/api/leads/${id}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ body: comment }),
    });
    setPostingComment(false);
    if (res.ok) {
      setComment("");
      load();
    }
  }

  async function toggleBlock() {
    const action = lead?.blocked ? "unblock" : "blocklist";
    const res = await fetch("/api/leads/bulk", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ids: [Number(id)], action }),
    });
    if (res.ok) {
      toast({ title: lead?.blocked ? "Uklonjeno iz blocklist-a" : "Dodato u blocklist" });
      load();
    }
  }

  async function scrape() {
    setScraping(true);
    setScrapeJobStatus({ status: "queued", pages: 0, total: 0, hasScreenshot: false });
    try {
      const res = await fetch("/api/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId: Number(id) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      if (data.jobId) {
        const jobId = data.jobId;
        startLeadScrapeJob({
          jobId,
          leadId: Number(id),
          leadName: lead?.name ?? `Lead #${id}`,
        });
        toast({
          title: "Scrape pokrenut",
          description: "Prati progress inline ispod ili u Activity panelu (donji desni ugao).",
        });
        // Inline poll — vidljivo direktno na lead detail
        const poll = setInterval(async () => {
          try {
            const r = await fetch(`/api/scrape/status/${jobId}`, { cache: "no-store" });
            if (!r.ok) return;
            const d = await r.json();
            setScrapeJobStatus({
              status: d.status,
              pages: d.pages_scraped ?? 0,
              total: d.total_pages ?? 0,
              hasScreenshot: !!d.screenshot,
            });
            if (d.status === "done" || d.status === "failed") {
              clearInterval(poll);
              if (d.status === "done") {
                toast({
                  title: "Scrape završen",
                  description: d.screenshot
                    ? "Screenshot spreman — klikni Analiziraj za M3 ocenu."
                    : "Sajt skrejpovan ali bez screenshot-a.",
                });
                await load();
              }
            }
          } catch {}
        }, 1500);
      } else {
        toast({ title: "Scrape pokrenut", description: data.message || "Proces traje nekoliko sekundi." });
      }
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
      setScrapeJobStatus(null);
    } finally {
      setScraping(false);
    }
  }

  async function analyze() {
    setAnalyzing(true);
    setAnalyzeJobStatus("queued");
    try {
      const res = await fetch(`/api/analyze/${id}`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      const a = data.analysis ?? {};
      const overall = a.overallScore;
      // Ako score ostane null, pokaži zašto
      if (overall === null || overall === undefined) {
        const reason =
          a.visualReason ||
          a.seoReason ||
          "Sajt verovatno nema dovoljno sadržaja za M3 da ga oceni.";
        toast({
          variant: "destructive",
          title: "M3 vratio prazan rezultat",
          description: reason,
        });
      } else {
        toast({
          title: "Analiza završena",
          description: `Ukupno: ${overall}/10 · Vizuelno: ${a.visualScore ?? "—"}/10 · SEO: ${a.seoScore ?? "—"}/10`,
        });
      }
      setAnalyzeJobStatus("done");
      await load();
    } catch (e) {
      setAnalyzeJobStatus("failed");
      toast({ variant: "destructive", title: "Greška pri analizi", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setAnalyzing(false);
    }
  }

  async function ensureScreenshot() {
    // Ako nema screenshot-a, prvo pokreni scrape, pa analiziraj
    if (!lead?.screenshots || lead.screenshots.length === 0) {
      await scrape();
    }
  }

  async function enrich() {
    setEnriching(true);
    setEnrichStatus("Kontaktiram scrape-leads servis…");
    // Heartbeat — tokom fetch-a (koji može trajati 30-60s zbog scrape-leads pollinga)
    // ažuriraj status svake 3s da korisnik vidi da nešto radi.
    const stages = [
      { after: 0, msg: "Kontaktiram scrape-leads servis…" },
      { after: 3000, msg: "Pokrećem Google Maps pretragu za biznis…" },
      { after: 8000, msg: "Skrejpujem detalje biznisa (to traje najduže)…" },
      { after: 25000, msg: "Skrejpujem detalje biznisa (to traje najduže)…" },
      { after: 45000, msg: "Skrejpujem detalje biznisa (to traje najduže)…" },
    ];
    const timers: ReturnType<typeof setTimeout>[] = [];
    for (const s of stages.slice(1)) {
      timers.push(setTimeout(() => setEnrichStatus(s.msg), s.after));
    }
    try {
      setEnrichStatus("Tražim biznis u Google Maps…");
      const res = await fetch(`/api/leads/${id}/enrich`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška");
      if (data.updated) {
        setEnrichStatus(
          `Ažurirano: ${(data.fields ?? []).join(", ") || "sva prazna polja"} · match ${Math.round((data.confidence ?? 0) * 100)}%`,
        );
        toast({
          title: "Enrich završen",
          description: `Match ${Math.round((data.confidence ?? 0) * 100)}% · ažurirano: ${(data.fields ?? []).join(", ")}`,
        });
        await load();
      } else {
        setEnrichStatus(data.reason ?? "Nema Google Maps mesta koje odgovara ovom leadu.");
        toast({
          variant: "destructive",
          title: "Enrich bez rezultata",
          description: data.reason ?? "Nema Google Maps mesta koje odgovara ovom leadu.",
        });
      }
    } catch (e) {
      setEnrichStatus(e instanceof Error ? e.message : String(e));
      toast({ variant: "destructive", title: "Enrich greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      timers.forEach(clearTimeout);
      // Zadrži status poruku 5s da korisnik vidi rezultat pre nego što se banner skloni
      setTimeout(() => {
        setEnriching(false);
        setEnrichStatus(null);
      }, 5000);
    }
  }

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!lead) {
    return (
      <div className="p-6">
        <p className="text-muted-foreground">Lead nije pronađen.</p>
        <Button asChild variant="link" className="px-0">
          <Link href="/campaigns">← Nazad</Link>
        </Button>
      </div>
    );
  }

  const issues: string[] = lead.analysis?.issuesJson ? safeParse(lead.analysis.issuesJson) : [];
  const notes: string[] = lead.analysis?.visualNotes ? safeParse(lead.analysis.visualNotes) : [];

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="border-b px-6 py-4">
        <button onClick={() => router.back()} className="mb-2 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" />
          Nazad
        </button>
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="truncate text-xl font-bold tracking-tight">{lead.name}</h1>
              {lead.doNotContact && <Badge variant="destructive">Ne kontaktiraj</Badge>}
              {lead.category && <Badge variant="secondary">{lead.category}</Badge>}
              {lead.screenshots && lead.screenshots.length > 0 ? (
                <Badge variant="outline" className="border-green-300 bg-green-50 text-green-700">
                  <Camera className="mr-1 h-3 w-3" /> Screenshot
                </Badge>
              ) : (
                <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
                  <Camera className="mr-1 h-3 w-3" /> Nema screenshota
                </Badge>
              )}
              {lead.analysis?.overallScore != null && (
                <Badge variant="outline" className="border-primary/30 bg-primary/5 text-primary">
                  <Sparkles className="mr-1 h-3 w-3" /> M3: {lead.analysis.overallScore}/10
                </Badge>
              )}
              {lead.reviewsCount != null && lead.reviewsCount > 0 && (
                <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
                  <Star className="mr-1 h-3 w-3" /> {lead.googleRating?.toFixed(1) ?? "—"} ({lead.reviewsCount})
                </Badge>
              )}
            </div>
            <p className="mt-0.5 text-sm text-muted-foreground">
              {[lead.city, lead.source].filter(Boolean).join(" · ") || "Bez dodatnih podataka"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={String(lead.statusId ?? "")} onValueChange={changeStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {statuses.map((s) => (
                  <SelectItem key={s.id} value={String(s.id)}>
                    <span className="mr-1.5 inline-block h-2 w-2 rounded-full" style={{ background: s.color }} />
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <EditLeadDialog
              leadId={Number(id)}
              initial={{
                name: lead.name,
                category: lead.category,
                phoneRaw: lead.phoneRaw,
                email: lead.email,
                websiteRaw: lead.websiteRaw,
                address: lead.address,
                city: lead.city,
                postalCode: lead.postalCode,
                googleRating: lead.googleRating,
                reviewsCount: lead.reviewsCount,
                source: lead.source,
                sourceUrl: lead.sourceUrl,
              }}
              onSaved={load}
            />
            <Button variant="outline" size="icon" onClick={toggleBlock} title={lead.blocked ? "Ukloni blokadu" : "Blokiraj"}>
              <Ban className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="grid flex-1 grid-cols-1 gap-4 overflow-auto p-6 lg:grid-cols-3">
        {/* Left: contact + analysis */}
        <div className="space-y-4 lg:col-span-2">
          {/* Contact card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Kontakt</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <InfoRow icon={<Phone className="h-4 w-4" />} label="Telefon" value={lead.phoneE164 || lead.phoneRaw}>
                  {lead.phoneE164 && (
                    <a href={`tel:${lead.phoneE164}`} className="flex items-center gap-2 hover:text-primary">
                      {lead.phoneE164} {lead.phoneRaw && lead.phoneRaw !== lead.phoneE164 && <span className="text-xs text-muted-foreground">({lead.phoneRaw})</span>}
                    </a>
                  )}
                </InfoRow>
                <InfoRow icon={<Mail className="h-4 w-4" />} label="Email" value={lead.email}>
                  {lead.email && (
                    <a href={`mailto:${lead.email}`} className="hover:text-primary">
                      {lead.email}
                    </a>
                  )}
                </InfoRow>
                <InfoRow icon={<Globe className="h-4 w-4" />} label="Website" value={lead.websiteNormalized}>
                  {lead.websiteNormalized && (
                    <a href={`https://${lead.websiteNormalized}`} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-primary">
                      {lead.websiteNormalized}
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </InfoRow>
                <InfoRow icon={<MapPin className="h-4 w-4" />} label="Adresa" value={[lead.address, lead.city, lead.postalCode].filter(Boolean).join(", ") || null} />
                <InfoRow icon={<Star className="h-4 w-4" />} label="Google ocena" value={lead.googleRating ? `${lead.googleRating.toFixed(1)} (${lead.reviewsCount ?? 0} recenzija)` : null} />
                {lead.sourceUrl && (
                  <InfoRow icon={<Activity className="h-4 w-4" />} label="Izvor" value={lead.source}>
                    <a href={lead.sourceUrl} target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-primary">
                      {lead.source || "Izvor"}
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </InfoRow>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Analysis */}
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <CardTitle className="text-base">Sajt & analiza</CardTitle>
                <div className="flex flex-wrap items-center gap-2">
                  {lead.websiteNormalized && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={scrape}
                      disabled={scraping}
                      title="Skrejpuj sajt ovog leada i napravi screenshot. Korak 1 od 2 (pre Analiziraj)."
                    >
                      {scraping ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
                      Skrejpuj sajt
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={enrich}
                    disabled={enriching}
                    title="Nađi ovaj biznis u Google Maps i dopuni prazna polja (recenzije, ocena, telefon, adresa, website). Ne dira ručne izmene."
                  >
                    {enriching ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
                    Enrich iz Google Maps
                  </Button>
                  <Button
                    size="sm"
                    onClick={analyze}
                    disabled={analyzing || !lead.analysis}
                    title="Pošalji screenshot sajta MiniMax M3 na vizuelnu + SEO ocenu. Zahteva da Scrape bude završen prvo."
                  >
                    {analyzing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                    M3 analiza
                  </Button>
                </div>
              </div>
              <CardDescription>Vizuelna i SEO ocena (MiniMax M3)</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Inline job progress — vidljiv DOK traje scrape ili analyze */}
              {(scrapeJobStatus || analyzeJobStatus) && (
                <div className="mb-3 space-y-2">
                  {scrapeJobStatus && scrapeJobStatus.status !== "done" && scrapeJobStatus.status !== "failed" && (
                    <div className="rounded-md border border-blue-200 bg-blue-50 p-3 text-sm">
                      <div className="flex items-center gap-3">
                        <Loader2 className="h-4 w-4 shrink-0 animate-spin text-blue-600" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-blue-900">
                            {scrapeJobStatus.status === "queued"
                              ? "Skrejpujem sajt… (pokretanje)"
                              : "Skrejpujem sajt i pravim screenshot…"}
                          </p>
                          <p className="text-xs text-blue-700">
                            {scrapeJobStatus.status === "queued"
                              ? "Worker se budi, obično traje 5-15 sekundi."
                              : `Stranica ${scrapeJobStatus.pages}/${scrapeJobStatus.total || "?"} · sajt ${lead?.websiteNormalized ?? ""}`}
                          </p>
                        </div>
                      </div>
                      {scrapeJobStatus.total > 0 && (
                        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-blue-100">
                          <div
                            className="h-full bg-blue-600 transition-all"
                            style={{ width: `${(scrapeJobStatus.pages / scrapeJobStatus.total) * 100}%` }}
                          />
                        </div>
                      )}
                    </div>
                  )}
                  {scrapeJobStatus?.status === "done" && (
                    <div className="flex items-center gap-3 rounded-md border border-green-200 bg-green-50 p-3 text-sm">
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-green-600" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-green-900">
                          {scrapeJobStatus.hasScreenshot ? "✓ Screenshot spreman" : "✓ Scrape završen (bez screenshot-a)"}
                        </p>
                        <p className="text-xs text-green-700">
                          {scrapeJobStatus.pages} {scrapeJobStatus.pages === 1 ? "strana" : "strane"} skrejpano
                          {scrapeJobStatus.hasScreenshot ? " · klikni M3 analiza za ocenu" : ""}
                        </p>
                      </div>
                    </div>
                  )}
                  {scrapeJobStatus?.status === "failed" && (
                    <div className="flex items-center gap-3 rounded-md border border-red-200 bg-red-50 p-3 text-sm">
                      <AlertTriangle className="h-4 w-4 shrink-0 text-red-600" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-red-900">Scrape failed</p>
                        <p className="text-xs text-red-700">Proveri scaper servis (port 8001).</p>
                      </div>
                    </div>
                  )}
                  {analyzeJobStatus && analyzeJobStatus !== "done" && analyzeJobStatus !== "failed" && (
                    <div className="flex items-center gap-3 rounded-md border border-purple-200 bg-purple-50 p-3 text-sm">
                      <Loader2 className="h-4 w-4 animate-spin text-purple-600" />
                      <div className="flex-1">
                        <p className="font-medium text-purple-900">M3 analizira sajt</p>
                        <p className="text-xs text-purple-700">Ovo može potrajati 10-30 sekundi.</p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Enrich status banner — vidi se DOK enrich traje i 4s posle završetka */}
              {enriching && enrichStatus && (
                <div className="mb-3 flex items-center gap-3 rounded-md border border-emerald-200 bg-emerald-50 p-3 text-sm">
                  <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-emerald-900">Enrich u toku</p>
                    <p className="truncate text-xs text-emerald-700">{enrichStatus}</p>
                  </div>
                  <span className="shrink-0 text-xs text-emerald-600">~30-60s</span>
                </div>
              )}

              {analyzing ? (
                <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
                  <Loader2 className="h-10 w-10 animate-spin text-primary" />
                  <p className="font-medium">MiniMax M3 analizira sajt…</p>
                  <p className="text-xs text-muted-foreground">Ovo može potrajati 10-30 sekundi.</p>
                </div>
              ) : lead.analysis ? (
                <div className="space-y-4">
                  {/* Veliki screenshot preview */}
                  <div className="overflow-hidden rounded-md border bg-muted">
                    <img
                      src={`/api/screenshot/${id}`}
                      alt="Screenshot sajta"
                      className="block w-full"
                      onError={(e) => {
                        e.currentTarget.style.display = "none";
                        const parent = e.currentTarget.parentElement;
                        if (parent && !parent.querySelector(".no-screenshot")) {
                          const div = document.createElement("div");
                          div.className = "no-screenshot flex h-32 items-center justify-center text-sm text-muted-foreground";
                          div.textContent = "Screenshot nije dostupan. Klikni „Scrape“ da ga ažuriraš.";
                          parent.appendChild(div);
                        }
                      }}
                    />
                  </div>

                  {/* Skorovi */}
                  <div className="grid grid-cols-3 gap-3">
                    <ScoreBox label="Ukupno" score={lead.analysis.overallScore} highlight />
                    <ScoreBox label="Vizuelno" score={lead.analysis.visualScore} />
                    <ScoreBox label="SEO" score={lead.analysis.seoScore} />
                  </div>

                  {/* Ako je score null — prikaži zašto */}
                  {(lead.analysis.overallScore === null || lead.analysis.overallScore === undefined) && (
                    <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-xs text-amber-800">
                      <AlertTriangle className="mr-1 inline h-3.5 w-3.5" />
                      <strong>Nema skora</strong> —{" "}
                      {lead.analysis.visualScore === null && "vizuelna ocena: nedostaje screenshot ili M3 odgovor nije parsiran. "}
                      {lead.analysis.seoScore === null && "SEO ocena: nema scrapanih stranica. "}
                      Probaj prvo kliknuti „Scrape".
                    </div>
                  )}

                  {lead.analysis.aiSummary && (
                    <div className="rounded-md border border-primary/20 bg-primary/5 p-3 text-sm">
                      <div className="mb-1 flex items-center gap-1 font-medium">
                        <Sparkles className="h-3.5 w-3.5 text-primary" />
                        AI sumar
                      </div>
                      <p className="text-foreground/80">{lead.analysis.aiSummary}</p>
                    </div>
                  )}
                  {notes.length > 0 && (
                    <div>
                      <p className="mb-1 text-sm font-medium">Napomene ({notes.length})</p>
                      <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
                        {notes.map((n, i) => (
                          <li key={i}>{n}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {issues.length > 0 && (
                    <div>
                      <p className="mb-1 text-sm font-medium text-amber-700">Problemi ({issues.length})</p>
                      <ul className="list-inside list-disc space-y-1 text-sm text-amber-700/90">
                        {issues.map((n, i) => (
                          <li key={i}>{n}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Analizirano: {lead.analysis ? new Date().toLocaleString("sr") : "—"}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {/* Čak i bez analize, prikaži screenshot ako postoji */}
                  {lead.screenshots && lead.screenshots.length > 0 ? (
                    <div className="overflow-hidden rounded-md border bg-muted">
                      <img
                        src={`/api/screenshot/${id}`}
                        alt="Screenshot sajta"
                        className="block w-full"
                      />
                    </div>
                  ) : (
                    <div className="flex h-40 items-center justify-center rounded-md border border-dashed bg-muted/40 text-sm text-muted-foreground">
                      <div className="text-center">
                        <Camera className="mx-auto mb-1 h-8 w-8" />
                        Nema screenshot-a
                      </div>
                    </div>
                  )}
                  <div className="flex flex-col items-center justify-center py-4 text-center text-sm text-muted-foreground">
                    <Sparkles className="mb-2 h-8 w-8" />
                    {lead.websiteNormalized
                      ? lead.screenshots && lead.screenshots.length > 0
                        ? "Klikni „Analiziraj\" za M3 ocenu dizajna i SEO-a."
                        : "Klikni „Scrape\" prvo da dohvatiš screenshot, pa „Analiziraj\"."
                      : "Lead nema website — analiza nije moguća."}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right: comments + emails */}
        <div className="space-y-4">
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <MessageSquare className="h-4 w-4" />
                Komentari ({(lead.comments ?? []).length})
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex gap-2">
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="Dodaj belešku..."
                  className="min-h-[60px]"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) addComment();
                  }}
                />
                <Button size="icon" onClick={addComment} disabled={postingComment || !comment.trim()} className="shrink-0">
                  {postingComment ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </div>
              <div className="max-h-[300px] space-y-2 overflow-auto">
                {(lead.comments ?? []).length === 0 ? (
                  <p className="py-4 text-center text-sm text-muted-foreground">Još uvek nema komentara.</p>
                ) : (
                  lead.comments.map((c) => (
                    <div key={c.id} className="rounded-md border bg-muted/30 p-2.5">
                      <p className="text-sm">{c.body}</p>
                      <p className="mt-1 text-xs text-muted-foreground">{formatDate(c.createdAt)}</p>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Email</CardTitle>
                {lead.email && <GenerateEmailButton leadId={Number(id)} onGenerated={load} />}
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {lead.emailSends.length === 0 ? (
                <p className="py-4 text-center text-sm text-muted-foreground">
                  {lead.email ? "Klikni „Generiši email“ da M3 napravi draft." : "Lead nema email."}
                </p>
              ) : (
                lead.emailSends.map((e) => <EmailDraftEditor key={e.id} leadId={Number(id)} draft={e} onUpdate={load} />)
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function InfoRow({
  icon,
  label,
  value,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | null;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-2">
      <span className="mt-0.5 text-muted-foreground">{icon}</span>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        {children ? <div className="text-sm font-medium">{children}</div> : <p className="text-sm font-medium">{value || "—"}</p>}
      </div>
    </div>
  );
}

function ScoreBox({ label, score, highlight }: { label: string; score: number | null; highlight?: boolean }) {
  if (score === null || score === undefined) {
    return (
      <div className="rounded-md border p-3 text-center">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-lg font-bold text-muted-foreground">—</p>
      </div>
    );
  }
  const color = score >= 7 ? "text-green-600" : score >= 4 ? "text-amber-600" : "text-red-600";
  const cls = highlight ? "rounded-md border-2 border-primary bg-primary/5 p-3 text-center" : "rounded-md border p-3 text-center";
  return (
    <div className={cls}>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-2xl font-bold ${color}`}>{score.toFixed(1)}</p>
    </div>
  );
}

function safeParse(s: string): string[] {
  try {
    const v = JSON.parse(s);
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}
