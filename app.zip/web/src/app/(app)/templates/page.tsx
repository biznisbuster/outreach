"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Save, Loader2, Trash2, FileText } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface Prompt {
  id: number;
  name: string;
  type: string;
  body: string;
  isDefault: boolean;
  campaignId: number | null;
  updatedAt: number | null;
}

const TYPE_LABELS: Record<string, string> = {
  email_personalization: "Email personalizacija",
  score: "Vizuelna ocena",
  seo_summary: "SEO sumar",
  assistant: "AI asistent",
};

const PLACEHOLDERS: Record<string, { placeholder: string; hint: string }[]> = {
  email_personalization: [
    { placeholder: "{{context}}", hint: "JSON sa lead, site, maps, sender podacima" },
    { placeholder: "{{sender_from_name}}", hint: "Ime pošiljaoca" },
    { placeholder: "{{sender_email}}", hint: "Email pošiljaoca" },
  ],
  seo_summary: [{ placeholder: "{{seo_metrics}}", hint: "JSON sa SEO metrikama sajta" }],
  score: [],
  assistant: [],
};

export default function TemplatesPage() {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [body, setBody] = useState("");
  const [name, setName] = useState("");
  const [activeType, setActiveType] = useState<string>("all");
  const [newName, setNewName] = useState("");
  const [newType, setNewType] = useState("email_personalization");
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch(`/api/prompts${activeType !== "all" ? `?type=${activeType}` : ""}`);
    const data = await res.json();
    setPrompts(data);
    setLoading(false);
    if (!activeId && data.length > 0) {
      setActiveId(data[0].id);
      setBody(data[0].body);
      setName(data[0].name);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeType]);

  async function save() {
    if (!activeId) return;
    setSaving(true);
    const res = await fetch(`/api/prompts/${activeId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, body }),
    });
    setSaving(false);
    if (res.ok) {
      toast({ title: "Sačuvano" });
      load();
    } else {
      toast({ variant: "destructive", title: "Greška" });
    }
  }

  async function createPrompt() {
    if (!newName.trim()) return;
    setCreating(true);
    const res = await fetch("/api/prompts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, type: newType, body: "" }),
    });
    setCreating(false);
    if (res.ok) {
      const data = await res.json();
      toast({ title: "Kreirano" });
      setNewName("");
      load();
      setActiveId(data.id);
      setBody("");
      setName(data.name);
    }
  }

  async function remove(id: number) {
    if (!confirm("Obrisati ovaj šablon?")) return;
    const res = await fetch(`/api/prompts/${id}`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Obrisano" });
      if (activeId === id) setActiveId(null);
      load();
    }
  }

  function selectPrompt(p: Prompt) {
    setActiveId(p.id);
    setBody(p.body);
    setName(p.name);
  }

  const active = prompts.find((p) => p.id === activeId);

  return (
    <div>
      <div className="border-b px-6 py-4">
        <h1 className="text-xl font-bold tracking-tight">Šabloni / Promptovi</h1>
        <p className="text-sm text-muted-foreground">AI promptovi za generisanje emailova i analiza. Default su već podešeni.</p>
      </div>

      <div className="grid h-[calc(100vh-9rem)] grid-cols-1 md:grid-cols-[280px_1fr]">
        {/* Left: list */}
        <div className="border-r">
          <Tabs value={activeType} onValueChange={setActiveType} className="w-full">
            <TabsList className="m-3 grid w-auto grid-cols-2">
              <TabsTrigger value="all">Sve</TabsTrigger>
              <TabsTrigger value="email_personalization">Email</TabsTrigger>
            </TabsList>
            <TabsContent value={activeType} className="m-0">
              <div className="px-3 pb-3">
                <div className="space-y-2">
                  <Input
                    placeholder="Naziv novog šablona"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                  />
                  <div className="flex gap-2">
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                      value={newType}
                      onChange={(e) => setNewType(e.target.value)}
                    >
                      {Object.entries(TYPE_LABELS).map(([k, v]) => (
                        <option key={k} value={k}>
                          {v}
                        </option>
                      ))}
                    </select>
                    <Button size="sm" onClick={createPrompt} disabled={creating || !newName.trim()}>
                      <Plus className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="overflow-y-auto px-2 pb-2">
                {loading ? (
                  <div className="flex justify-center p-4 text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                  </div>
                ) : prompts.length === 0 ? (
                  <p className="px-3 py-6 text-center text-xs text-muted-foreground">Nema šablona.</p>
                ) : (
                  prompts.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => selectPrompt(p)}
                      className={`flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm transition-colors ${
                        activeId === p.id ? "bg-primary/10 text-primary" : "hover:bg-accent"
                      }`}
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <FileText className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                          <span className="truncate font-medium">{p.name}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">{TYPE_LABELS[p.type] || p.type}</p>
                      </div>
                      {p.isDefault && <Badge variant="secondary">Default</Badge>}
                    </button>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Right: editor */}
        <div className="overflow-auto p-4">
          {active ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex-1 space-y-2">
                  <Label>Naziv</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                {!active.isDefault && (
                  <Button variant="ghost" size="icon" onClick={() => remove(active.id)} className="ml-2 mt-6">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                )}
              </div>
              <div className="rounded-md border bg-muted/50 p-3 text-xs">
                <p className="mb-1 font-medium">Tip: {TYPE_LABELS[active.type]}</p>
                {PLACEHOLDERS[active.type]?.length > 0 && (
                  <div className="text-muted-foreground">
                    <span className="font-medium">Placeholder-i: </span>
                    {PLACEHOLDERS[active.type].map((p) => (
                      <span key={p.placeholder} className="ml-2">
                        <code>{p.placeholder}</code> — {p.hint}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label>Prompt (telo)</Label>
                <Textarea
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  className="min-h-[400px] font-mono text-sm"
                />
              </div>
              <div className="flex justify-end">
                <Button onClick={save} disabled={saving}>
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  Sačuvaj
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              <p>Izaberi šablon sa leve strane ili kreiraj novi.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}