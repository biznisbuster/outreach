"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, UploadCloud, FileText, CheckCircle2, Copy, AlertTriangle } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface PreviewRow {
  name: string;
  city: string | null;
  email: string | null;
  websiteNormalized: string | null;
  phoneE164: string | null;
  dedup: string;
  category: string | null;
}
interface Preview {
  preview: boolean;
  total: number;
  newCount: number;
  duplicateCount: number;
  invalidCount: number;
  newRows: PreviewRow[];
  invalidRows: { index: number; name: string; city: string; errors: string[] }[];
}

export default function ImportPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [campaigns, setCampaigns] = useState<{ id: number; name: string }[]>([]);
  const [campaignId, setCampaignId] = useState<string>(params.get("campaignId") || "");
  const [text, setText] = useState("");
  const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false);
  const [committing, setCommitting] = useState(false);
  const [preview, setPreview] = useState<Preview | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch("/api/campaigns")
      .then((r) => r.json())
      .then((d) => {
        setCampaigns(d);
        if (!campaignId && d.length > 0) setCampaignId(String(d[0].id));
      });
  }, [campaignId]);

  function onFile(file: File) {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setText(String(reader.result || ""));
    reader.readAsText(file);
  }

  async function analyze() {
    if (!text.trim()) {
      toast({ variant: "destructive", title: "Prazan unos", description: "Nalepi podatke ili izaberi fajl." });
      return;
    }
    setLoading(true);
    setPreview(null);
    try {
      const res = await fetch("/api/import", {
        method: "POST",
        headers: { "Content-Type": "text/plain" },
        body: text,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška pri parsiranju");
      setPreview(data);
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setLoading(false);
    }
  }

  async function commit() {
    if (!campaignId) {
      toast({ variant: "destructive", title: "Izaberi kampanju" });
      return;
    }
    if (!preview || preview.newRows.length === 0) return;
    setCommitting(true);
    try {
      const res = await fetch("/api/import/commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ campaignId: Number(campaignId), leads: preview.newRows }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Greška pri unosu");
      toast({
        title: "Uspešno uvezeno",
        description: `Uneto ${data.inserted} leadova${data.skipped ? `, preskočeno ${data.skipped} duplikata` : ""}.`,
      });
      router.push(`/campaigns/${campaignId}`);
    } catch (e) {
      toast({ variant: "destructive", title: "Greška", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setCommitting(false);
    }
  }

  const sample = `naziv,kategorija,telefon,email,website,grad,google_ocena,broj_recenzija,izvor,izvor_url
Top Frizerski Salon,Friler,011/123-4567,info@topfrizerski.rs,https://www.topfrizerski.rs,Beograd,4.5,127,Google Maps,https://maps.google.com/...
Majstor Milan,Vodoinstalater,064/987-6543,,majstormilan.rs,Novi Sad,4.8,89,Google Maps,https://maps.google.com/...`;

  return (
    <div>
      <div className="border-b px-6 py-4">
        <h1 className="text-xl font-bold tracking-tight">Import leadova</h1>
        <p className="text-sm text-muted-foreground">Uvezi leadove iz CSV ili JSON fajla. Podržano automatsko mapiranje kolona.</p>
      </div>

      <div className="space-y-6 p-6">
        {/* Šablon kolona */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="h-4 w-4" />
              Očekivane kolone
            </CardTitle>
            <CardDescription>Imena kolona se prepoznaju automatski (srpski/engleski). Obavezna polja: naziv, grad.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-sm sm:grid-cols-3">
              {[
                ["naziv *", "ime biznisa"],
                ["kategorija *", "frizer/majstor..."],
                ["telefon", "→ +381 normalizacija"],
                ["email", "validacija"],
                ["website", "→ bez www/https"],
                ["adresa", ""],
                ["grad *", ""],
                ["postanski_broj", ""],
                ["google_ocena", "1–5"],
                ["broj_recenzija", ""],
                ["izvor", "npr. Google Maps"],
                ["izvor_url", ""],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between border-b border-dashed py-1">
                  <code className="text-xs">{k}</code>
                  {v && <span className="text-xs text-muted-foreground">{v}</span>}
                </div>
              ))}
            </div>
            <div className="mt-3 flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setText(sample)}>
                <Copy className="h-3.5 w-3.5" />
                Umetni primer
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Upload */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">1. Izaberi fajl ili nalepi podatke</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div
              className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/30 p-8 text-center transition-colors hover:border-primary/50 hover:bg-accent/30"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files[0];
                if (f) onFile(f);
              }}
            >
              <UploadCloud className="mb-2 h-8 w-8 text-muted-foreground" />
              {fileName ? (
                <p className="text-sm font-medium">{fileName}</p>
              ) : (
                <>
                  <p className="text-sm font-medium">Klikni ili prevuci fajl ovde</p>
                  <p className="text-xs text-muted-foreground">CSV ili JSON</p>
                </>
              )}
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.json,.txt"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onFile(f);
                }}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">...ili nalepi sadržaj direktno</Label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder={sample}
                className="min-h-[120px] font-mono text-xs"
              />
            </div>
            <Button onClick={analyze} disabled={loading || !text.trim()}>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
              Analiziraj i prikaži pregled
            </Button>
          </CardContent>
        </Card>

        {/* Preview */}
        {preview && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <CheckCircle2 className="h-4 w-4 text-green-600" />
                2. Pregled
              </CardTitle>
              <CardDescription>Potvrdi pre nego što uneseš leadove u bazu.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <Stat label="Novi" value={preview.newCount} color="text-green-600" />
                <Stat label="Duplikati" value={preview.duplicateCount} color="text-amber-600" />
                <Stat label="Nevažeći" value={preview.invalidCount} color="text-red-600" />
              </div>

              {preview.newRows.length > 0 && (
                <div>
                  <h4 className="mb-2 text-sm font-medium">Novi leadovi ({Math.min(preview.newRows.length, 50)} prikazano)</h4>
                  <div className="max-h-[300px] overflow-auto rounded-md border">
                    <Table>
                      <TableHeader className="sticky top-0 bg-card">
                        <TableRow>
                          <TableHead>Naziv</TableHead>
                          <TableHead>Grad</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Website</TableHead>
                          <TableHead>Telefon</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {preview.newRows.slice(0, 50).map((r, i) => (
                          <TableRow key={i}>
                            <TableCell className="font-medium">{r.name}</TableCell>
                            <TableCell className="text-sm">{r.city || "—"}</TableCell>
                            <TableCell className="text-sm">{r.email || "—"}</TableCell>
                            <TableCell className="text-sm">{r.websiteNormalized || "—"}</TableCell>
                            <TableCell className="text-sm">{r.phoneE164 || "—"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {preview.invalidRows.length > 0 && (
                <div className="rounded-md border border-red-200 bg-red-50 p-3">
                  <div className="mb-2 flex items-center gap-2 text-sm font-medium text-red-800">
                    <AlertTriangle className="h-4 w-4" />
                    Nevažeći redovi ({preview.invalidCount})
                  </div>
                  <div className="max-h-[160px] overflow-auto space-y-1 text-xs text-red-700">
                    {preview.invalidRows.map((r, i) => (
                      <div key={i}>
                        <span className="font-medium">{r.name || "(bez naziva)"}</span> {r.city && `· ${r.city}`} — {r.errors.join(", ")}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3 border-t pt-4 sm:flex-row sm:items-end sm:justify-between">
                <div className="space-y-1.5">
                  <Label>3. Kampanja</Label>
                  {campaigns.length === 0 ? (
                    <p className="text-sm text-muted-foreground">Nema kampanja. Kreiraj kampanju prvo.</p>
                  ) : (
                    <Select value={campaignId} onValueChange={setCampaignId}>
                      <SelectTrigger className="w-full sm:w-[280px]">
                        <SelectValue placeholder="Izaberi kampanju" />
                      </SelectTrigger>
                      <SelectContent>
                        {campaigns.map((c) => (
                          <SelectItem key={c.id} value={String(c.id)}>
                            {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
                <Button size="lg" onClick={commit} disabled={committing || !campaignId || preview.newRows.length === 0}>
                  {committing ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                  Unesi {preview.newRows.length} leadova
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-md border bg-card p-3 text-center">
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
