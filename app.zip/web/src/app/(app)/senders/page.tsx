"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Send, Trash2, Loader2, CheckCircle2, XCircle, Mail, Power } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { timeAgo } from "@/lib/utils";

interface Sender {
  id: number;
  email: string;
  fromName: string;
  smtpHost: string;
  smtpPort: number;
  username: string;
  passwordMasked: string;
  dailyCap: number;
  hourlyCap: number;
  minDelaySec: number;
  maxDelaySec: number;
  active: boolean;
  lastUsedAt: number | null;
}

export default function SendersPage() {
  const [senders, setSenders] = useState<Sender[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [testing, setTesting] = useState<number | null>(null);
  const [testResult, setTestResult] = useState<{ senderId: number; ok: boolean; msg: string } | null>(null);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/senders");
    const data = await res.json();
    setSenders(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggleActive(s: Sender) {
    const res = await fetch(`/api/senders/${s.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !s.active }),
    });
    if (res.ok) load();
  }

  async function remove(s: Sender) {
    if (!confirm(`Obrisati sender ${s.email}?`)) return;
    const res = await fetch(`/api/senders/${s.id}`, { method: "DELETE" });
    if (res.ok) load();
  }

  async function test(s: Sender) {
    setTesting(s.id);
    setTestResult(null);
    try {
      const res = await fetch(`/api/senders/${s.id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testEmail ? { toEmail: testEmail } : {}),
      });
      const data = await res.json();
      setTestResult({ senderId: s.id, ok: data.ok, msg: data.error || data.mode || "OK" });
    } catch (e) {
      setTestResult({ senderId: s.id, ok: false, msg: e instanceof Error ? e.message : String(e) });
    } finally {
      setTesting(null);
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Senderi (aliasi)</h1>
          <p className="text-sm text-muted-foreground">SMTP nalozi sa rotacijom i throttle limitima.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" />
          Novi sender
        </Button>
      </div>

      <div className="space-y-4 p-6">
        {loading ? (
          <div className="flex h-32 items-center justify-center text-muted-foreground">
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Učitavanje...
          </div>
        ) : senders.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <Mail className="mb-3 h-10 w-10 text-muted-foreground" />
              <h3 className="font-semibold">Nema sendera</h3>
              <p className="mb-4 text-sm text-muted-foreground">Dodaj prvi SMTP alias da možeš da šalješ emailove.</p>
              <Button onClick={() => setOpen(true)}>
                <Plus className="h-4 w-4" /> Dodaj sender
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {senders.map((s) => (
              <Card key={s.id}>
                <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                  <div className="min-w-0">
                    <CardTitle className="flex items-center gap-2 truncate text-base">
                      {s.fromName} <span className="text-xs font-normal text-muted-foreground">&lt;{s.email}&gt;</span>
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {s.smtpHost}:{s.smtpPort} · {s.username} · {s.passwordMasked}
                    </CardDescription>
                  </div>
                  <Badge variant={s.active ? "success" : "secondary"}>{s.active ? "Aktivan" : "Pauziran"}</Badge>
                </CardHeader>
                <CardContent>
                  <div className="mb-3 grid grid-cols-3 gap-2 text-xs">
                    <Stat label="Hourly cap" value={s.hourlyCap} />
                    <Stat label="Daily cap" value={s.dailyCap} />
                    <Stat label="Delay" value={`${s.minDelaySec}-${s.maxDelaySec}s`} />
                  </div>
                  <p className="mb-3 text-xs text-muted-foreground">Poslednji put korišćen: {timeAgo(s.lastUsedAt)}</p>
                  {testResult?.senderId === s.id && (
                    <div
                      className={`mb-3 flex items-start gap-2 rounded-md p-2 text-xs ${
                        testResult.ok ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"
                      }`}
                    >
                      {testResult.ok ? <CheckCircle2 className="mt-0.5 h-3.5 w-3.5" /> : <XCircle className="mt-0.5 h-3.5 w-3.5" />}
                      {testResult.msg}
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="test@email.com (opciono)"
                      value={testEmail}
                      onChange={(e) => setTestEmail(e.target.value)}
                      className="h-8 text-xs"
                    />
                    <Button size="sm" variant="outline" onClick={() => test(s)} disabled={testing === s.id}>
                      {testing === s.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
                      Test
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => toggleActive(s)} title={s.active ? "Pauziraj" : "Aktiviraj"}>
                      <Power className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(s)}>
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Prozor slanja (env)</CardTitle>
            <CardDescription>Podešava se u .env fajlu, ne u UI-ju.</CardDescription>
          </CardHeader>
          <CardContent className="font-mono text-xs text-muted-foreground">
            <div>SEND_WINDOW_START=09:00 · SEND_WINDOW_END=17:00</div>
            <div>SEND_WINDOW_TZ=Europe/Belgrade · SEND_WINDOW_DAYS=mon-fri</div>
            <div>DEFAULT_SENDER_HOURLY_CAP=10 · DEFAULT_SENDER_DAILY_CAP=50</div>
          </CardContent>
        </Card>
      </div>

      <CreateSenderDialog open={open} onOpenChange={setOpen} onCreated={load} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-md border bg-muted/30 p-2 text-center">
      <p className="text-[10px] uppercase text-muted-foreground">{label}</p>
      <p className="text-sm font-semibold">{value}</p>
    </div>
  );
}

function CreateSenderDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: () => void;
}) {
  const [email, setEmail] = useState("");
  const [fromName, setFromName] = useState("");
  const [smtpHost, setSmtpHost] = useState("smtp.gmail.com");
  const [smtpPort, setSmtpPort] = useState(465);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [dailyCap, setDailyCap] = useState(50);
  const [hourlyCap, setHourlyCap] = useState(10);
  const [minDelay, setMinDelay] = useState(30);
  const [maxDelay, setMaxDelay] = useState(120);
  const [loading, setLoading] = useState(false);

  async function create() {
    if (!email || !fromName || !username || !password) {
      toast({ variant: "destructive", title: "Popuni sva obavezna polja" });
      return;
    }
    setLoading(true);
    const res = await fetch("/api/senders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email,
        fromName,
        smtpHost,
        smtpPort,
        username,
        password,
        dailyCap,
        hourlyCap,
        minDelaySec: minDelay,
        maxDelaySec: maxDelay,
      }),
    });
    setLoading(false);
    if (res.ok) {
      toast({ title: "Sender kreiran" });
      onCreated();
      onOpenChange(false);
      // reset
      setEmail("");
      setFromName("");
      setPassword("");
    } else {
      const data = await res.json().catch(() => ({}));
      toast({ variant: "destructive", title: "Greška", description: data.error || "Kreiranje nije uspelo" });
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Novi SMTP sender</DialogTitle>
          <DialogDescription>Šifra se čuva enkriptovana (AES-256-GCM).</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 space-y-1.5">
            <Label>Ime pošiljaoca *</Label>
            <Input value={fromName} onChange={(e) => setFromName(e.target.value)} placeholder="Marko Marković" />
          </div>
          <div className="col-span-2 space-y-1.5">
            <Label>Email *</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="marko@tvojdomen.rs" />
          </div>
          <div className="space-y-1.5">
            <Label>SMTP host *</Label>
            <Input value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Port</Label>
            <Input type="number" value={smtpPort} onChange={(e) => setSmtpPort(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label>Username *</Label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Password (app password) *</Label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Hourly cap</Label>
            <Input type="number" value={hourlyCap} onChange={(e) => setHourlyCap(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label>Daily cap</Label>
            <Input type="number" value={dailyCap} onChange={(e) => setDailyCap(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label>Min delay (s)</Label>
            <Input type="number" value={minDelay} onChange={(e) => setMinDelay(Number(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label>Max delay (s)</Label>
            <Input type="number" value={maxDelay} onChange={(e) => setMaxDelay(Number(e.target.value))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Otkaži
          </Button>
          <Button onClick={create} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Kreiraj
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}