/**
 * Bulk akcije za više leadova.
 *
 * - scrape: pokreće scrape za svaki izabrani lead (jedan po jedan, sa pauzom)
 * - analyze: pokreće analyze (koristi scrape servis + M3) za svaki lead
 *
 * Akcije su dugotrajne. Vraćamo job_id odmah, a posao se izvršava u
 * pozadini i registruje u ActivityPanelu.
 */
import { NextRequest } from "next/server";
import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { inArray, eq, isNull, or, sql } from "drizzle-orm";
import { z } from "zod";
import { logAudit } from "@/lib/audit";

const bulkReqSchema = z.object({
  leadIds: z.array(z.number().int().positive()).optional(),
  /** Ako leadIds nije prosleđen — selektuj sve leadove u datoj kampanji. */
  campaignId: z.number().int().positive().optional(),
  /** Ako je true, targetira sve leadove bez screenshota. */
  onlyWithoutScreenshot: z.boolean().optional(),
  /** Ako je true, targetira sve leadove bez analyze rezultata. */
  onlyWithoutAnalysis: z.boolean().optional(),
});

const SCRAPER_URL = process.env.SCRAPER_URL || "http://localhost:8001";

interface BulkJob {
  id: string;
  action: "scrape" | "analyze";
  total: number;
  done: number;
  failed: number;
  current: number | null;
  startedAt: number;
  finishedAt: number | null;
  errors: { leadId: number; reason: string }[];
  /** Prekinuto preko cancelBulkJob() */
  cancelled: boolean;
}

const _BULK: Map<string, BulkJob> = new Map();
const _ABORT: Map<string, AbortController> = new Map();

export function getBulkJob(id: string): BulkJob | undefined {
  return _BULK.get(id);
}

export function cancelBulkJob(id: string): boolean {
  const ctrl = _ABORT.get(id);
  if (!ctrl) return false;
  ctrl.abort();
  const job = _BULK.get(id);
  if (job) job.cancelled = true;
  return true;
}

async function scrapeOneLead(leadId: number, signal: AbortSignal): Promise<{ ok: boolean; reason?: string }> {
  if (signal.aborted) return { ok: false, reason: "cancelled" };
  try {
    const r = await fetch(`${SCRAPER_URL}/scrape`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lead_id: leadId, max_pages: 20 }),
      signal,
    });
    if (!r.ok) {
      const txt = await r.text().catch(() => r.statusText);
      return { ok: false, reason: `HTTP ${r.status} ${txt.slice(0, 100)}` };
    }
    const data = await r.json();
    const jobId = data.job_id ?? data.jobId;
    if (!jobId) return { ok: false, reason: "nema jobId" };

    // poll za završetak (max 90s)
    for (let i = 0; i < 90; i++) {
      if (signal.aborted) return { ok: false, reason: "cancelled" };
      await new Promise((r) => setTimeout(r, 1000));
      const s = await fetch(`${SCRAPER_URL}/scrape/status/${jobId}`, { signal }).catch(() => null);
      if (!s || !s.ok) continue;
      const sd = await s.json().catch(() => ({} as { status?: string; screenshot?: string | null }));
      if (sd.status === "done") return { ok: true };
      if (sd.status === "failed") return { ok: false, reason: "scraper failed" };
    }
    return { ok: false, reason: "timeout" };
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : String(e) };
  }
}

async function analyzeOneLead(leadId: number, signal: AbortSignal): Promise<{ ok: boolean; reason?: string }> {
  if (signal.aborted) return { ok: false, reason: "cancelled" };
  try {
    // Next.js API radi fetch unutar istog servera
    const baseUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
    const r = await fetch(`${baseUrl}/api/analyze/${leadId}`, {
      method: "POST",
      signal,
    });
    if (!r.ok) {
      const txt = await r.text().catch(() => r.statusText);
      return { ok: false, reason: `HTTP ${r.status} ${txt.slice(0, 200)}` };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : String(e) };
  }
}

async function runBulk(
  jobId: string,
  action: "scrape" | "analyze",
  leadIds: number[],
  ctrl: AbortController,
) {
  const job: BulkJob = {
    id: jobId,
    action,
    total: leadIds.length,
    done: 0,
    failed: 0,
    current: null,
    startedAt: Date.now(),
    finishedAt: null,
    errors: [],
    cancelled: false,
  };
  _BULK.set(jobId, job);

  for (const leadId of leadIds) {
    if (ctrl.signal.aborted) break;
    job.current = leadId;
    const fn = action === "scrape" ? scrapeOneLead : analyzeOneLead;
    const res = await fn(leadId, ctrl.signal);
    if (res.ok) job.done++;
    else {
      job.failed++;
      job.errors.push({ leadId, reason: res.reason ?? "unknown" });
    }
    // Pauza između leadova da ne preopteretimo scrape servis
    await new Promise((r) => setTimeout(r, 1500));
  }
  job.finishedAt = Date.now();
  job.current = null;
  _ABORT.delete(jobId);
  logAudit(action === "scrape" ? "scrape.start" : "analyze.start", "bulk", null, { jobId, total: leadIds.length, done: job.done, failed: job.failed });
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = bulkReqSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const { leadIds, campaignId, onlyWithoutScreenshot, onlyWithoutAnalysis } = parsed.data;

  if (!leadIds && !campaignId) return bad("leadIds ili campaignId je obavezan");

  const action = req.headers.get("x-bulk-action") as "scrape" | "analyze" | null;
  if (action !== "scrape" && action !== "analyze") {
    return bad("X-Bulk-Action header mora biti 'scrape' ili 'analyze'");
  }

  const db = getDb();
  let targets: { id: number }[] = [];
  if (leadIds && leadIds.length > 0) {
    targets = db.select({ id: schema.leads.id }).from(schema.leads).where(inArray(schema.leads.id, leadIds)).all();
  } else if (campaignId) {
    const conds: any[] = [eq(schema.leads.campaignId, campaignId)];
    if (onlyWithoutScreenshot) {
      conds.push(sql`NOT EXISTS (SELECT 1 FROM screenshots s WHERE s.lead_id = ${schema.leads.id})`);
    }
    if (onlyWithoutAnalysis) {
      conds.push(sql`NOT EXISTS (SELECT 1 FROM site_analysis sa WHERE sa.lead_id = ${schema.leads.id})`);
    }
    targets = db
      .select({ id: schema.leads.id })
      .from(schema.leads)
      .where(and(...conds))
      .all();
  }

  if (targets.length === 0) {
    return ok({ jobId: null, message: "Nema leadova za procesiranje", count: 0 });
  }

  const jobId = `bulk-${action}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const ctrl = new AbortController();
  _ABORT.set(jobId, ctrl);

  // Pokreni u pozadini
  void runBulk(jobId, action, targets.map((t) => t.id), ctrl);

  return ok({
    jobId,
    count: targets.length,
    message: `${action === "scrape" ? "Scrape" : "Analyze"} pokrenut za ${targets.length} leadova.`,
  });
}

import { and } from "drizzle-orm"; // re-export for clarity