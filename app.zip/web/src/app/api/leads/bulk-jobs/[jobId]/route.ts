import { getBulkJob, cancelBulkJob } from "@/app/api/leads/bulk-jobs/route";
import { requireSession, ok, notFound, unauthorized } from "@/lib/api";

export async function GET(_req: Request, { params }: { params: Promise<{ jobId: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { jobId } = await params;
  const job = getBulkJob(jobId);
  if (!job) return notFound("Bulk job ne postoji (završio je ili je restartovan server)");
  return ok(job);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ jobId: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { jobId } = await params;
  const ok2 = cancelBulkJob(jobId);
  return ok({ cancelled: ok2 });
}