import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const db = getDb();
  const items = db
    .select()
    .from(schema.comments)
    .where(eq(schema.comments.leadId, Number(idStr)))
    .orderBy(sql`${schema.comments.createdAt} DESC`)
    .all();
  return ok(items);
}

const createSchema = z.object({ body: z.string().min(1) });

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const data = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(data);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.comments)
    .values({ leadId: Number(idStr), body: parsed.data.body })
    .returning()
    .all();
  return ok(rows[0], 201);
}
