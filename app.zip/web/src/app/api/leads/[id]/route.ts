import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const db = getDb();

  const [row] = db
    .select({
      lead: schema.leads,
      statusName: schema.statuses.name,
      statusColor: schema.statuses.color,
    })
    .from(schema.leads)
    .leftJoin(schema.statuses, eq(schema.leads.statusId, schema.statuses.id))
    .where(eq(schema.leads.id, id))
    .all();
  if (!row) return notFound("Lead nije pronađen");

  const comments = db
    .select()
    .from(schema.comments)
    .where(eq(schema.comments.leadId, id))
    .orderBy(sql`${schema.comments.createdAt} DESC`)
    .all();
  const analysis = db
    .select()
    .from(schema.siteAnalysis)
    .where(eq(schema.siteAnalysis.leadId, id))
    .orderBy(sql`${schema.siteAnalysis.analyzedAt} DESC`)
    .limit(1)
    .all()[0];
  const scrapes = db.select().from(schema.siteScrapes).where(eq(schema.siteScrapes.leadId, id)).all();
  const screenshots = db.select().from(schema.screenshots).where(eq(schema.screenshots.leadId, id)).all();
  const emailSends = db
    .select()
    .from(schema.emailSends)
    .where(eq(schema.emailSends.leadId, id))
    .orderBy(sql`${schema.emailSends.queuedAt} DESC`)
    .all();
  const blocked = db.select().from(schema.blocklist).where(eq(schema.blocklist.leadId, id)).limit(1).all();

  return ok({
    ...row.lead,
    statusName: row.statusName,
    statusColor: row.statusColor,
    comments,
    analysis,
    scrapes,
    screenshots,
    emailSends,
    blocked: blocked.length > 0,
  });
}

const patchSchema = z.object({
  name: z.string().optional(),
  category: z.string().optional().nullable(),
  phoneRaw: z.string().optional().nullable(),
  phoneE164: z.string().optional().nullable(),
  email: z.string().optional().nullable(),
  websiteRaw: z.string().optional().nullable(),
  websiteNormalized: z.string().optional().nullable(),
  address: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  postalCode: z.string().optional().nullable(),
  googleRating: z.number().optional().nullable(),
  reviewsCount: z.number().optional().nullable(),
  source: z.string().optional().nullable(),
  sourceUrl: z.string().optional().nullable(),
  statusId: z.number().optional().nullable(),
  doNotContact: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const body = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .update(schema.leads)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(schema.leads.id, id))
    .returning()
    .all();
  const updated = rows[0];
  if (!updated) return notFound("Lead nije pronađen");
  return ok(updated);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const db = getDb();
  db.delete(schema.leads).where(eq(schema.leads.id, id)).run();
  return ok({ ok: true });
}
