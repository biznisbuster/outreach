import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq } from "drizzle-orm";
import { logAudit } from "@/lib/audit";

const SCRAPER_LEADS_URL = process.env.SCRAPER_LEADS_URL || "http://localhost:8002";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: leadIdStr } = await params;
  const leadId = Number(leadIdStr);
  const db = getDb();
  const [lead] = db.select().from(schema.leads).where(eq(schema.leads.id, leadId)).all();
  if (!lead) return bad("Lead ne postoji");
  if (!lead.name) return bad("Lead nema ime");

  // Ako lead ima Google Maps sourceUrl sa place_id, koristi /enrich-url
  // (100% tačan match, bez fuzzy grešaka). Inače fallback na /enrich-lead.
  const hasMapsUrl = lead.sourceUrl && /google\.[a-z.]+\/maps\//i.test(lead.sourceUrl);

  let res: Response;
  try {
    if (hasMapsUrl) {
      res = await fetch(`${SCRAPER_LEADS_URL}/enrich-url`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: lead.sourceUrl,
          city: lead.city || "",
          country: "RS",
          max_results: 20,
        }),
      });
    } else {
      res = await fetch(`${SCRAPER_LEADS_URL}/enrich-lead`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: lead.name,
          city: lead.city || "",
          category: lead.category,
          country: "RS",
          max_results: 8,
        }),
      });
    }
  } catch (e) {
    return bad(`Scrape-leads servis nedostupan: ${e instanceof Error ? e.message : String(e)}`);
  }
  const data = await res.json();
  if (!res.ok) return bad(data.detail || `Scraper greška: ${res.status}`);

  if (!data.match) {
    return ok({
      updated: false,
      reason: data.reason || "Nema Google Maps mesta koje odgovara",
      jobId: data.jobId,
      source: data.source || (hasMapsUrl ? "url" : "fuzzy"),
    });
  }

  const d = data.data;
  // Ažuriraj samo polja koja su prazna ili zastarela (ne diramo name/city/phone ako već imaju)
  const updates: Record<string, unknown> = {
    googleRating: d.google_rating ?? lead.googleRating,
    reviewsCount: d.reviews_count ?? lead.reviewsCount,
    address: d.address ?? lead.address,
    sourceUrl: d.google_maps_url ?? lead.sourceUrl,
  };
  if (!lead.websiteNormalized && d.website) {
    const { normalizeWebsite } = await import("@/lib/dedup");
    updates.websiteRaw = d.website;
    updates.websiteNormalized = normalizeWebsite(d.website);
  }
  if (!lead.phoneE164 && d.phone_e164) {
    updates.phoneRaw = d.phone_raw ?? d.phone_e164;
    updates.phoneE164 = d.phone_e164;
  }
  if (!lead.email && d.email) {
    updates.email = d.email;
  }
  if (d.latitude && d.longitude) {
    updates.latitude = d.latitude;
    updates.longitude = d.longitude;
  }

  const fieldsUpdated = Object.keys(updates);
  if (fieldsUpdated.length > 0) {
    db.update(schema.leads).set(updates).where(eq(schema.leads.id, leadId)).run();
    logAudit("lead.update", "lead", leadId, {
      source: data.source || (hasMapsUrl ? "enrich-google-maps-url" : "enrich-google-maps-fuzzy"),
      confidence: data.confidence,
      jobId: data.jobId,
      fields: fieldsUpdated,
    });
  }

  return ok({
    updated: fieldsUpdated.length > 0,
    confidence: data.confidence,
    source: data.source || (hasMapsUrl ? "url" : "fuzzy"),
    jobId: data.jobId,
    fields: fieldsUpdated,
    data: d,
  });
}