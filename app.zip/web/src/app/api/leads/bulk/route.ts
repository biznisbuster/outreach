import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { inArray, eq } from "drizzle-orm";
import { z } from "zod";
import { logAudit } from "@/lib/audit";

const bulkSchema = z.object({
  ids: z.array(z.number()).min(1),
  action: z.enum(["setStatus", "blocklist", "delete", "unblock"]),
  statusId: z.number().optional(),
  reason: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = bulkSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");

  const { ids, action, statusId, reason } = parsed.data;
  const db = getDb();

  if (action === "setStatus") {
    if (!statusId) return bad("statusId je obavezan");
    db.update(schema.leads)
      .set({ statusId, updatedAt: new Date() })
      .where(inArray(schema.leads.id, ids))
      .run();
    logAudit("lead.bulk_status", "lead", null, { ids, statusId });
  } else if (action === "blocklist") {
    db.update(schema.leads)
      .set({ doNotContact: true, updatedAt: new Date() })
      .where(inArray(schema.leads.id, ids))
      .run();
    // ubaci u blocklist ako već nisu
    for (const id of ids) {
      const exists = db.select().from(schema.blocklist).where(eq(schema.blocklist.leadId, id)).limit(1).all();
      if (exists.length === 0) {
        db.insert(schema.blocklist).values({ leadId: id, reason: reason || "Bulk blokada" }).run();
      }
    }
    logAudit("lead.bulk_blocklist", "lead", null, { ids, reason });
  } else if (action === "unblock") {
    db.update(schema.leads)
      .set({ doNotContact: false, updatedAt: new Date() })
      .where(inArray(schema.leads.id, ids))
      .run();
    db.delete(schema.blocklist).where(inArray(schema.blocklist.leadId, ids)).run();
    logAudit("lead.bulk_status", "lead", null, { ids, action: "unblock" });
  } else if (action === "delete") {
    // Sačuvaj imena pre brisanja za audit
    const leadNames = db
      .select({ id: schema.leads.id, name: schema.leads.name })
      .from(schema.leads)
      .where(inArray(schema.leads.id, ids))
      .all();
    db.delete(schema.leads).where(inArray(schema.leads.id, ids)).run();
    logAudit(
      "lead.bulk_delete",
      "lead",
      null,
      { ids, count: ids.length, names: leadNames.map((l) => l.name) },
    );
  }

  return ok({ ok: true, affected: ids.length });
}
