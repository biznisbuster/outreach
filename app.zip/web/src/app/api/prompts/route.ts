import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { desc, eq, and } from "drizzle-orm";
import { z } from "zod";

export async function GET(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const db = getDb();
  const conds = [];
  if (type) conds.push(eq(schema.promptTemplates.type, type));
  const rows = db
    .select()
    .from(schema.promptTemplates)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(schema.promptTemplates.isDefault), desc(schema.promptTemplates.updatedAt))
    .all();
  return ok(rows);
}

const createSchema = z.object({
  name: z.string().min(1),
  type: z.enum(["email_personalization", "score", "seo_summary", "assistant"]),
  body: z.string().min(1),
  isDefault: z.boolean().optional().default(false),
  campaignId: z.number().optional().nullable(),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.promptTemplates)
    .values({
      name: parsed.data.name,
      type: parsed.data.type,
      body: parsed.data.body,
      isDefault: parsed.data.isDefault ?? false,
      campaignId: parsed.data.campaignId ?? null,
    })
    .returning()
    .all();
  return ok(rows[0], 201);
}