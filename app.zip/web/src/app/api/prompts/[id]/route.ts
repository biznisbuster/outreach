import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq } from "drizzle-orm";
import { z } from "zod";

const patchSchema = z.object({
  name: z.string().optional(),
  body: z.string().optional(),
  isDefault: z.boolean().optional(),
  type: z.enum(["email_personalization", "score", "seo_summary", "assistant"]).optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const body = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .update(schema.promptTemplates)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(schema.promptTemplates.id, id))
    .returning()
    .all();
  const updated = rows[0];
  if (!updated) return notFound();
  return ok(updated);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const db = getDb();
  db.delete(schema.promptTemplates).where(eq(schema.promptTemplates.id, Number(idStr))).run();
  return ok({ ok: true });
}