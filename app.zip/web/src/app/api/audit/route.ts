import { requireSession, ok, unauthorized } from "@/lib/api";
import { listAudit, leadHistory, recentLeadEvents } from "@/lib/audit";

export async function GET(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const url = new URL(req.url);
  const entity = url.searchParams.get("entity");
  const entityId = url.searchParams.get("entityId");
  const leadId = url.searchParams.get("leadId");
  const limit = Number(url.searchParams.get("limit") ?? "100");

  if (leadId) {
    return ok({ entries: leadHistory(Number(leadId), limit) });
  }
  if (entity === "lead") {
    return ok({ entries: recentLeadEvents(limit) });
  }
  return ok({
    entries: listAudit({
      entity: entity ?? undefined,
      entityId: entityId ? Number(entityId) : undefined,
      limit,
    }),
  });
}