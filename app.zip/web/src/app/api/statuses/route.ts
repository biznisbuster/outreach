import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { asc } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  const db = getDb();
  const items = db.select().from(schema.statuses).orderBy(asc(schema.statuses.sortOrder)).all();
  return ok(items);
}

const createSchema = z.object({
  name: z.string().min(1),
  color: z.string().default("#6b7280"),
  isTerminalWon: z.boolean().default(false),
  isTerminalLost: z.boolean().default(false),
  sortOrder: z.number().default(0),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.statuses)
    .values({ ...parsed.data, isActive: true, systemDefault: false })
    .returning()
    .all();
  return ok(rows[0], 201);
}
