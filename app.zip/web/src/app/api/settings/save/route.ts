import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { getAllSettings, setSetting, clearSetting, SETTINGS_CATALOG } from "@/lib/settings";
import { z } from "zod";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  return ok({ settings: getAllSettings(), catalog: SETTINGS_CATALOG });
}

const saveSchema = z.object({
  changes: z.array(
    z.object({
      key: z.string(),
      value: z.string(),
      isSecret: z.boolean().optional(),
      clear: z.boolean().optional(),
    }),
  ),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = saveSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");

  let saved = 0;
  for (const ch of parsed.data.changes) {
    const def = SETTINGS_CATALOG[ch.key];
    if (def?.type === "number") {
      const n = Number(ch.value);
      if (ch.value !== "" && !Number.isFinite(n)) {
        return bad(`"${def.label}" mora biti broj`);
      }
    }
    if (ch.clear) {
      clearSetting(ch.key);
    } else {
      setSetting(ch.key, ch.value ?? "", ch.isSecret ?? !!def?.isSecret);
    }
    saved++;
  }
  return ok({ saved });
}