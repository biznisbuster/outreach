import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { ImapFlow } from "imapflow";

export async function POST() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const host = process.env.IMAP_HOST;
  const user = process.env.IMAP_USER;
  const pass = process.env.IMAP_PASSWORD;
  if (!host || !user || !pass) {
    return NextResponse.json({ ok: false, message: "IMAP_* env promenljive nisu podešene." });
  }

  try {
    const client = new ImapFlow({
      host,
      port: Number(process.env.IMAP_PORT || 993),
      secure: true,
      auth: { user, pass },
      logger: false,
    });
    await client.connect();
    const status = await client.status(process.env.IMAP_FOLDER || "INBOX", { messages: true, unseen: true });
    await client.logout();
    return NextResponse.json({
      ok: true,
      message: `Konektovano. INBOX: ${status.messages} poruka, ${status.unseen} nepročitanih.`,
    });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    return NextResponse.json({ ok: false, message: `Greška: ${msg}` });
  }
}
