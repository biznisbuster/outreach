import { requireSession, ok, unauthorized } from "@/lib/api";
import { getSettingBool } from "@/lib/settings";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  return ok({ enabled: getSettingBool("auto_screenshot_on_open") });
}