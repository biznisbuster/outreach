import fs from "node:fs";
import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq, desc } from "drizzle-orm";
import { completeVision, completeJson, isMinimaxConfigured } from "@/lib/minimax";

function loadDefaultPrompt(type: string): string | null {
  const db = getDb();
  const row = db
    .select()
    .from(schema.promptTemplates)
    .where(eq(schema.promptTemplates.type, type))
    .orderBy(desc(schema.promptTemplates.isDefault))
    .limit(1)
    .all()[0];
  return row?.body ?? null;
}

function fileToDataUrl(filePath: string): string | null {
  try {
    if (!fs.existsSync(filePath)) return null;
    const buf = fs.readFileSync(filePath);
    const b64 = buf.toString("base64");
    return `data:image/png;base64,${b64}`;
  } catch {
    return null;
  }
}

export async function POST(_req: Request, { params }: { params: Promise<{ leadId: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { leadId: leadIdStr } = await params;
  const leadId = Number(leadIdStr);
  const db = getDb();

  if (!isMinimaxConfigured()) {
    return bad("MiniMax API ključ nije podešen. Dodaj MINIMAX_API_KEY u Podešavanja.");
  }

  const [lead] = db.select().from(schema.leads).where(eq(schema.leads.id, leadId)).all();
  if (!lead) return notFound("Lead nije pronađen");
  if (!lead.websiteNormalized && !lead.websiteRaw) {
    return bad("Lead nema website — analiza nije moguća.");
  }

  let screenshot = db
    .select()
    .from(schema.screenshots)
    .where(eq(schema.screenshots.leadId, leadId))
    .orderBy(desc(schema.screenshots.capturedAt))
    .limit(1)
    .all()[0];

  let scrape = db
    .select()
    .from(schema.siteScrapes)
    .where(eq(schema.siteScrapes.leadId, leadId))
    .orderBy(desc(schema.siteScrapes.startedAt))
    .limit(1)
    .all()[0];

  // Ako nema screenshot-a, pokreni scrape (stari scraper servis port 8001).
  // Stari API: POST /scrape sa body {lead_id, max_pages}. Vraća job_id odmah
  // i izvršava u pozadini. Čekamo da screenshot/scrape redovi stignu u bazu.
  if (!screenshot || !scrape) {
    const scraperUrl = process.env.SCRAPER_URL || "http://localhost:8001";
    let scraperAvailable = false;
    try {
      // 1) health check
      const healthRes = await fetch(`${scraperUrl}/health`, { signal: AbortSignal.timeout(2000) });
      if (!healthRes.ok) {
        return bad(
          `Scrape servis (${scraperUrl}) health=${healthRes.status}. ` +
            `Servis nije ispravan — pokrenite ga ponovo.`,
        );
      }
      // 2) trigger scrape job
      const r = await fetch(`${scraperUrl}/scrape`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lead_id: leadId, max_pages: 20 }),
        signal: AbortSignal.timeout(5000),
      });
      if (r.ok) {
        scraperAvailable = true;
        // 3) poll-uj bazu dok scrape ne završi (max 60s)
        for (let i = 0; i < 60; i++) {
          await new Promise((res) => setTimeout(res, 1000));
          screenshot = db
            .select()
            .from(schema.screenshots)
            .where(eq(schema.screenshots.leadId, leadId))
            .orderBy(desc(schema.screenshots.capturedAt))
            .limit(1)
            .all()[0];
          scrape = db
            .select()
            .from(schema.siteScrapes)
            .where(eq(schema.siteScrapes.leadId, leadId))
            .orderBy(desc(schema.siteScrapes.startedAt))
            .limit(1)
            .all()[0];
          if (screenshot && scrape) break;
        }
      } else {
        const errBody = await r.text().catch(() => "");
        return bad(
          `Scrape servis (${scraperUrl}) odbio zahtev: HTTP ${r.status} ${errBody.slice(0, 200)}`,
        );
      }
    } catch (e) {
      return bad(
        `Scrape servis (${scraperUrl}) nije dostupan: ${e instanceof Error ? e.message : String(e)}. ` +
          `Pokrenite scraper servis pre analize.`,
      );
    }
    if (!scraperAvailable) {
      return bad(`Scrape servis se vratio kao neuspešan.`);
    }
  }

  const pages = scrape
    ? db.select().from(schema.sitePages).where(eq(schema.sitePages.scrapeId, scrape.id)).all()
    : [];

  // --- 1) Vizuelna ocena (M3 vision) ---
  let visualScore: number | null = null;
  let visualNotes: string[] = [];
  let visualRaw: string | null = null;
  let issues: string[] = [];
  let visualReason: string | null = null;

  if (!screenshot) {
    visualReason = "Nema screenshot-a — klikni Scrape prvo.";
  } else {
    const dataUrl = fileToDataUrl(screenshot.path);
    if (!dataUrl) {
      visualReason = `Screenshot fajl ne može da se pročita (${screenshot.path})`;
    } else {
      const scorePrompt = loadDefaultPrompt("score");
      if (!scorePrompt) {
        visualReason = "Prompt sablon score nije pronadjen u bazi";
      } else {
        try {
          const raw = await completeVision(
            scorePrompt,
            "Oceni dizajn ovog homepage-a na osnovu screenshot-a.",
            dataUrl,
            { temperature: 0.2 },
          );
          visualRaw = raw;
          const parsed = safeParseJson(raw);
          if (parsed && typeof parsed.score === "number") {
            visualScore = Math.max(1, Math.min(10, Math.round(parsed.score)));
            visualNotes = Array.isArray(parsed.notes) ? parsed.notes : [];
            if (Array.isArray(parsed.issues)) issues = parsed.issues;
          } else {
            visualReason = "M3 odgovor nije parsiran kao JSON";
            console.error("[analyze] vision raw response:", raw?.slice(0, 500));
          }
        } catch (e) {
          visualReason = `M3 vision greška: ${e instanceof Error ? e.message : String(e)}`;
          console.error("[analyze] vision greška:", e);
        }
      }
    }
  }

  // --- 2) SEO sumar (M3 text) ---
  let seoScore: number | null = null;
  let aiSummary: string | null = null;
  let seoReason: string | null = null;

  const totalWords = pages.reduce((s, p) => s + (p.wordCount || 0), 0);
  const avgWord = pages.length ? Math.round(totalWords / pages.length) : 0;
  const titleOptimal = pages.filter((p) => {
    const m = safeParseJsonObj(p.seoMetricsJson);
    return m?.title_optimal;
  }).length;
  const metaOptimal = pages.filter((p) => {
    const m = safeParseJsonObj(p.seoMetricsJson);
    return m?.meta_optimal;
  }).length;
  const altRatios = pages
    .map((p) => safeParseJsonObj(p.seoMetricsJson)?.alt_ratio)
    .filter((v): v is number => typeof v === "number");
  const avgAlt = altRatios.length ? altRatios.reduce((a, b) => a + b, 0) / altRatios.length : 0;
  const sdCount = pages.filter((p) => safeParseJsonObj(p.seoMetricsJson)?.has_structured_data).length;
  const categories: Record<string, number> = {};
  for (const p of pages) {
    const c = p.category || "Other";
    categories[c] = (categories[c] || 0) + 1;
  }

  if (pages.length === 0) {
    seoReason = "Nema scrapanih stranica — klikni Scrape prvo.";
  } else {
    const seoPrompt = loadDefaultPrompt("seo_summary");
    if (!seoPrompt) {
      seoReason = "Prompt sablon seo_summary nije pronadjen";
    } else {
      const seoMetrics = JSON.stringify(
        {
          total_pages: pages.length,
          avg_word_count: avgWord,
          title_optimal_pct: Math.round((titleOptimal / pages.length) * 100),
          meta_optimal_pct: Math.round((metaOptimal / pages.length) * 100),
          avg_alt_ratio: Math.round(avgAlt * 100) / 100,
          structured_data_pct: Math.round((sdCount / pages.length) * 100),
          categories,
        },
        null,
        2,
      );
      const filled = seoPrompt.replace("{{seo_metrics}}", seoMetrics);
      try {
        const raw = await completeJson<{ seo_score?: number; summary?: string; issues?: string[] }>(
          "Ti si SEO analitičar.",
          filled,
          { temperature: 0.2 },
        );
        if (typeof raw.seo_score === "number") seoScore = Math.max(1, Math.min(10, Math.round(raw.seo_score)));
        if (typeof raw.summary === "string") aiSummary = raw.summary;
        if (Array.isArray(raw.issues) && issues.length === 0) issues = raw.issues;
      } catch (e) {
        seoReason = `M3 SEO greška: ${e instanceof Error ? e.message : String(e)}`;
        console.error("[analyze] seo greška:", e);
      }
    }
  }

  // --- 3) overall = prosečno vizuelno + SEO ---
  const scores = [visualScore, seoScore].filter((v): v is number => v !== null && v !== undefined);
  const overall = scores.length ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10 : null;

  // --- upis u site_analysis ---
  const existing = db.select().from(schema.siteAnalysis).where(eq(schema.siteAnalysis.leadId, leadId)).all();
  const payload = {
    leadId,
    scrapeId: scrape?.id ?? null,
    visualScore,
    visualNotes: JSON.stringify(visualNotes),
    seoScore,
    totalPages: pages.length,
    totalWords,
    overallScore: overall,
    issuesJson: JSON.stringify(issues),
    aiSummary,
    analyzedAt: new Date(),
  };
  if (existing.length > 0) {
    db.update(schema.siteAnalysis)
      .set(payload)
      .where(eq(schema.siteAnalysis.id, existing[0].id))
      .run();
  } else {
    db.insert(schema.siteAnalysis).values(payload).run();
  }

  return ok({
    ok: true,
    analysis: {
      ...payload,
      visualNotes,
      issues,
      // Dijagnostika — pomaže UI da objasni zašto je score null
      visualReason: visualScore === null ? visualReason : null,
      seoReason: seoScore === null ? seoReason : null,
      hasScreenshot: !!screenshot,
      hasScrape: !!scrape,
      pagesCount: pages.length,
    },
  });
}

function safeParseJson(raw: string): { score?: number; notes?: string[]; issues?: string[] } | null {
  try {
    let txt = raw.trim();
    // skini <think>...</think> ako ga M3 doda
    const thinkEnd = txt.lastIndexOf("</think>");
    if (thinkEnd >= 0) txt = txt.slice(thinkEnd + "</think>".length).trim();
    // skini markdown fence
    const fence = txt.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fence) txt = fence[1].trim();
    const first = txt.search(/[{[]/);
    if (first > 0) txt = txt.slice(first);
    const last = Math.max(txt.lastIndexOf("}"), txt.lastIndexOf("]"));
    if (last >= 0) txt = txt.slice(0, last + 1);
    return JSON.parse(txt);
  } catch {
    return null;
  }
}

function safeParseJsonObj(s: string | null): Record<string, unknown> | null {
  if (!s) return null;
  try {
    return JSON.parse(s);
  } catch {
    return null;
  }
}
