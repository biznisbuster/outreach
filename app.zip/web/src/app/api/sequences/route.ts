import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq, desc, asc } from "drizzle-orm";
import { z } from "zod";

export async function GET(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const url = new URL(req.url);
  const campaignId = url.searchParams.get("campaignId");
  if (!campaignId) return bad("campaignId obavezan");
  const db = getDb();
  const sequences = db
    .select()
    .from(schema.sequences)
    .where(eq(schema.sequences.campaignId, Number(campaignId)))
    .orderBy(desc(schema.sequences.createdAt))
    .all();
  const result = sequences.map((s) => ({
    ...s,
    steps: db
      .select()
      .from(schema.sequenceSteps)
      .where(eq(schema.sequenceSteps.sequenceId, s.id))
      .orderBy(asc(schema.sequenceSteps.stepNumber))
      .all(),
  }));
  return ok(result);
}

const createSchema = z.object({
  campaignId: z.number(),
  name: z.string().min(1),
  active: z.boolean().optional().default(true),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.sequences)
    .values({
      campaignId: parsed.data.campaignId,
      name: parsed.data.name,
      active: parsed.data.active ?? true,
    })
    .returning()
    .all();
  return ok(rows[0], 201);
}