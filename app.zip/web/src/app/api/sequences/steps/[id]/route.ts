import { getDb, schema } from "@/lib/db";
import { requireSession, ok, unauthorized } from "@/lib/api";
import { eq } from "drizzle-orm";

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const db = getDb();
  db.delete(schema.sequenceSteps).where(eq(schema.sequenceSteps.id, Number(idStr))).run();
  return ok({ ok: true });
}