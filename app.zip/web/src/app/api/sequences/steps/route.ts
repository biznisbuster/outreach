import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { z } from "zod";

const createSchema = z.object({
  sequenceId: z.number(),
  stepNumber: z.number().int().min(1),
  delayDays: z.number().int().min(0).default(0),
  promptTemplateId: z.number().optional().nullable(),
  sendWindowOnly: z.boolean().optional().default(true),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.sequenceSteps)
    .values({
      sequenceId: parsed.data.sequenceId,
      stepNumber: parsed.data.stepNumber,
      delayDays: parsed.data.delayDays,
      promptTemplateId: parsed.data.promptTemplateId ?? null,
      sendWindowOnly: parsed.data.sendWindowOnly ?? true,
      active: true,
    })
    .returning()
    .all();
  return ok(rows[0], 201);
}