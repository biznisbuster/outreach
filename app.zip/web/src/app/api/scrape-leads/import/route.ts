import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq, and } from "drizzle-orm";
import { z } from "zod";
import { dedupKey, normalizePhoneE164, normalizeWebsite } from "@/lib/dedup";

const SCRAPER_LEADS_URL = process.env.SCRAPER_LEADS_URL || "http://localhost:8002";

const importSchema = z.object({
  jobId: z.string().min(1),
  campaignId: z.number().int().positive(),
  rows: z
    .array(
      z.object({
        name: z.string(),
        address: z.string().nullable().optional(),
        city: z.string().nullable().optional(),
        country: z.string().nullable().optional(),
        phone_e164: z.string().nullable().optional(),
        phone_raw: z.string().nullable().optional(),
        website: z.string().nullable().optional(),
        email: z.string().nullable().optional(),
        category: z.string().nullable().optional(),
        rating: z.coerce.number().nullable().optional(),
        reviews_count: z.coerce.number().nullable().optional(),
        latitude: z.coerce.number().nullable().optional(),
        longitude: z.coerce.number().nullable().optional(),
        google_place_id: z.string().nullable().optional(),
        google_maps_url: z.string().nullable().optional(),
        source: z.string().nullable().optional(),
      }),
    )
    .min(1),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = importSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const { jobId, campaignId, rows } = parsed.data;

  // Verify job exists & is finished (best-effort — if scraper is down, allow import anyway)
  try {
    const r = await fetch(`${SCRAPER_LEADS_URL}/scrape-leads/status/${jobId}`, { cache: "no-store" });
    if (r.ok) {
      const j = await r.json();
      if (j.status !== "done") {
        return bad(`Job ${jobId} nije završen (status=${j.status})`);
      }
    }
  } catch {
    // scraper unavailable — skip verification, let user proceed
  }

  const db = getDb();
  const [campaign] = db
    .select({ id: schema.campaigns.id })
    .from(schema.campaigns)
    .where(eq(schema.campaigns.id, campaignId))
    .all();
  if (!campaign) return bad("Kampanja ne postoji");

  const [noviStatus] = db
    .select({ id: schema.statuses.id })
    .from(schema.statuses)
    .where(eq(schema.statuses.systemDefault, true))
    .orderBy(schema.statuses.sortOrder)
    .all();

  let created = 0;
  let updated = 0;
  let duplicates = 0;
  const createdIds: number[] = [];
  const updatedIds: number[] = [];

  for (const row of rows) {
    if (!row.name || !row.name.trim()) continue;

    const phoneE164 = normalizePhoneE164(row.phone_e164 || row.phone_raw);
    const websiteNormalized = normalizeWebsite(row.website);
    const key = dedupKey({
      website: websiteNormalized,
      phoneE164,
      name: row.name,
      city: row.city ?? null,
    });

    const [existing] = db
      .select({
        id: schema.leads.id,
        reviewsCount: schema.leads.reviewsCount,
        googleRating: schema.leads.googleRating,
        sourceUrl: schema.leads.sourceUrl,
        phoneE164: schema.leads.phoneE164,
      })
      .from(schema.leads)
      .where(eq(schema.leads.dedupKey, key))
      .all();

    // Ako nema dedup_key match, probaj fallback: isti telefon (ako nije prazan).
    // Ovo pokriva slučaj kad scrape-ov biznis nema website (pa se dedup_key
    // razlikuje) ali ima telefon koji se već nalazi u bazi.
    let existingByPhone: { id: number; reviewsCount: number | null; googleRating: number | null; sourceUrl: string | null } | undefined;
    if (!existing && phoneE164) {
      const [byPhone] = db
        .select({
          id: schema.leads.id,
          reviewsCount: schema.leads.reviewsCount,
          googleRating: schema.leads.googleRating,
          sourceUrl: schema.leads.sourceUrl,
        })
        .from(schema.leads)
        .where(eq(schema.leads.phoneE164, phoneE164))
        .all();
      existingByPhone = byPhone;
    }

    const existingRow = existing
      ? { ...existing }
      : existingByPhone
        ? { ...existingByPhone, phoneE164: phoneE164 ?? null }
        : null;

    if (existingRow) {
      // MERGE logika: ako lead već postoji, ažuriraj SAMO prazna/zaostala polja
      // iz scrape-a. Ne diramo ručne izmene (status, comments, doNotContact,
      // custom edits) — to je isti pattern kao /api/leads/{id}/enrich.
      const updates: Record<string, unknown> = {};
      if (row.reviews_count != null && (existingRow.reviewsCount == null || existingRow.reviewsCount === 0)) {
        updates.reviewsCount = row.reviews_count;
      }
      if (row.rating != null && existingRow.googleRating == null) {
        updates.googleRating = row.rating;
      }
      if (row.google_maps_url && !existingRow.sourceUrl) {
        updates.sourceUrl = row.google_maps_url;
      }
      if (Object.keys(updates).length > 0) {
        db.update(schema.leads).set(updates).where(eq(schema.leads.id, existingRow.id)).run();
        updatedIds.push(existingRow.id);
        updated++;
      } else {
        duplicates++;
      }
      continue;
    }

    const [ins] = db
      .insert(schema.leads)
      .values({
        campaignId,
        name: row.name.trim(),
        category: row.category ?? null,
        phoneRaw: row.phone_raw ?? null,
        phoneE164,
        email: row.email ?? null,
        websiteRaw: row.website ?? null,
        websiteNormalized,
        address: row.address ?? null,
        city: row.city ?? null,
        googleRating: row.rating ?? null,
        reviewsCount: row.reviews_count ?? null,
        source: row.source ?? "maps",
        sourceUrl: row.google_maps_url ?? null,
        statusId: noviStatus?.id ?? null,
        dedupKey: key,
      })
      .returning({ id: schema.leads.id })
      .all();

    if (ins) {
      created++;
      createdIds.push(ins.id);
    }
  }

  return ok({ created, updated, duplicates, createdIds, updatedIds, campaignId });
}