import { requireSession, ok, bad, unauthorized } from "@/lib/api";

const SCRAPER_LEADS_URL = process.env.SCRAPER_LEADS_URL || "http://localhost:8002";

export async function POST(_req: Request, { params }: { params: Promise<{ jobId: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { jobId } = await params;

  try {
    const res = await fetch(`${SCRAPER_LEADS_URL}/scrape-leads/import/${jobId}`, {
      method: "POST",
    });
    const data = await res.json();
    if (!res.ok) return bad(data.detail || `Scraper greška: ${res.status}`);
    return ok(data);
  } catch (e) {
    return bad(`Scraper-leads servis nije dostupan: ${e instanceof Error ? e.message : String(e)}`);
  }
}