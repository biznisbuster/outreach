import { requireSession, ok, bad, unauthorized } from "@/lib/api";

const SCRAPER_LEADS_URL = process.env.SCRAPER_LEADS_URL || "http://localhost:8002";

function friendlyDownError(e: unknown) {
  const msg = e instanceof Error ? e.message : String(e);
  return `Scrape-leads servis (port 8002) nije dostupan. Pokreni ga u scraper-leads/ direktorijumu sa: cd scraper-leads && uv run python -m maps_cold_calling.api. (Detalji: ${msg})`;
}

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return bad("Neispravan unos");
  const { category, city, country, max_results, extract_emails, stealth, language } = body;
  if (!category || !city) return bad("category i city su obavezni");

  try {
    const res = await fetch(`${SCRAPER_LEADS_URL}/scrape-leads`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        category,
        city,
        country: country || "RS",
        language: language || "sr",
        max_results: max_results ?? 20,
        extract_emails: !!extract_emails,
        stealth: stealth || "lite",
      }),
    });
    const data = await res.json();
    if (!res.ok) return bad(data.detail || `Scraper greška: ${res.status}`);
    return ok(data);
  } catch (e) {
    return bad(friendlyDownError(e));
  }
}

/**
 * GET /api/scrape-leads — health probe za scrape-leads servis.
 * Vraća {ok: true, version, ...} ako servis radi, ili {ok: false, error} ako ne.
 * Koristi ga ScrapeLeadsDialog da prikaže upozorenje PRE nego korisnik klikne "Pokreni".
 */
export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  try {
    // FastAPI app nema root handler; pokušaj sa /docs (uvek postoji od FastAPIja)
    // ili sa /scrape-leads/changelog (lak endpoint koji postoji u scraper-leads).
    const res = await fetch(`${SCRAPER_LEADS_URL}/scrape-leads/changelog?limit=1`, {
      signal: AbortSignal.timeout(2000),
    });
    if (!res.ok) {
      return ok({ ok: false, reason: `status ${res.status}`, url: SCRAPER_LEADS_URL }, 200);
    }
    await res.json().catch(() => ({}));
    return ok({ ok: true, url: SCRAPER_LEADS_URL });
  } catch (e) {
    return ok(
      {
        ok: false,
        reason: friendlyDownError(e),
        url: SCRAPER_LEADS_URL,
      },
      200,
    );
  }
}