import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq } from "drizzle-orm";
import { encrypt } from "@/lib/crypto";
import { verifySmtp, sendEmail } from "@/lib/email/sender";
import { z } from "zod";

const patchSchema = z.object({
  email: z.string().email().optional(),
  fromName: z.string().optional(),
  smtpHost: z.string().optional(),
  smtpPort: z.number().int().optional(),
  username: z.string().optional(),
  password: z.string().optional(), // ako se prosleđuje, re-šifrujemo
  dailyCap: z.number().int().optional(),
  hourlyCap: z.number().int().optional(),
  minDelaySec: z.number().int().optional(),
  maxDelaySec: z.number().int().optional(),
  active: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const body = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();

  const update: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.password) {
    update.passwordEncrypted = encrypt(parsed.data.password);
    delete update.password;
  }

  const rows = db
    .update(schema.senders)
    .set(update)
    .where(eq(schema.senders.id, id))
    .returning()
    .all();
  const updated = rows[0];
  if (!updated) return notFound();
  return ok(updated);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const db = getDb();
  db.delete(schema.senders).where(eq(schema.senders.id, Number(idStr))).run();
  return ok({ ok: true });
}

const testSendSchema = z.object({ toEmail: z.string().email().optional() });

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const body = await req.json().catch(() => ({}));
  const parsed = testSendSchema.safeParse(body || {});
  const toEmail = parsed.success && parsed.data.toEmail ? parsed.data.toEmail : undefined;

  const db = getDb();
  const [sender] = db.select().from(schema.senders).where(eq(schema.senders.id, Number(idStr))).all();
  if (!sender) return notFound("Sender ne postoji");

  if (!toEmail) {
    const v = await verifySmtp(sender.smtpHost, sender.smtpPort, sender.username, sender.passwordEncrypted);
    return ok({ ...v, mode: "verify" });
  }

  const res = await sendEmail({
    host: sender.smtpHost,
    port: sender.smtpPort,
    username: sender.username,
    passwordEncrypted: sender.passwordEncrypted,
    fromEmail: sender.email,
    fromName: sender.fromName,
    toEmail,
    subject: "Outreach test email",
    body: "Ovo je testni email iz Outreach aplikacije.\n\nAko ga vidiš, SMTP radi ispravno.",
    emailSendId: 0,
  });
  return ok({ ...res, mode: "test_send" });
}