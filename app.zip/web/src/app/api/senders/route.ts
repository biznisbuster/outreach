import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { desc } from "drizzle-orm";
import { encrypt } from "@/lib/crypto";
import { z } from "zod";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  const db = getDb();
  const rows = db
    .select({
      id: schema.senders.id,
      email: schema.senders.email,
      fromName: schema.senders.fromName,
      smtpHost: schema.senders.smtpHost,
      smtpPort: schema.senders.smtpPort,
      username: schema.senders.username,
      passwordMasked: schema.senders.passwordEncrypted, // ne vraćamo pravu šifru — maskiraj na klijentu
      dailyCap: schema.senders.dailyCap,
      hourlyCap: schema.senders.hourlyCap,
      minDelaySec: schema.senders.minDelaySec,
      maxDelaySec: schema.senders.maxDelaySec,
      active: schema.senders.active,
      lastUsedAt: schema.senders.lastUsedAt,
    })
    .from(schema.senders)
    .orderBy(desc(schema.senders.id))
    .all();
  // vrati maskiranu šifru (klijent ne vidi pravu)
  const masked = rows.map((r) => ({ ...r, passwordMasked: r.passwordMasked ? "••••••••" : "" }));
  return ok(masked);
}

const createSchema = z.object({
  email: z.string().email(),
  fromName: z.string().min(1),
  smtpHost: z.string().min(1),
  smtpPort: z.number().int().min(1).default(465),
  username: z.string().min(1),
  password: z.string().min(1), // plain na ulazu, šifrujemo
  dailyCap: z.number().int().min(1).default(Number(process.env.DEFAULT_SENDER_DAILY_CAP || 50)),
  hourlyCap: z.number().int().min(1).default(Number(process.env.DEFAULT_SENDER_HOURLY_CAP || 10)),
  minDelaySec: z.number().int().min(0).default(30),
  maxDelaySec: z.number().int().min(0).default(120),
  active: z.boolean().default(true),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const passwordEncrypted = encrypt(parsed.data.password);
  const rows = db
    .insert(schema.senders)
    .values({
      email: parsed.data.email,
      fromName: parsed.data.fromName,
      smtpHost: parsed.data.smtpHost,
      smtpPort: parsed.data.smtpPort,
      username: parsed.data.username,
      passwordEncrypted,
      dailyCap: parsed.data.dailyCap,
      hourlyCap: parsed.data.hourlyCap,
      minDelaySec: parsed.data.minDelaySec,
      maxDelaySec: parsed.data.maxDelaySec,
      active: parsed.data.active,
    })
    .returning()
    .all();
  return ok(rows[0], 201);
}