import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { generateEmailDraft } from "@/lib/email/generate";

const schema_req = z.object({
  leadId: z.number(),
  promptTemplateId: z.number().optional(),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = schema_req.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const { leadId, promptTemplateId } = parsed.data;

  const db = getDb();
  const [lead] = db.select().from(schema.leads).where(eq(schema.leads.id, leadId)).all();
  if (!lead) return notFound("Lead ne postoji");
  if (!lead.email) return bad("Lead nema email");

  const draft = await generateEmailDraft(leadId, promptTemplateId);
  if (!draft) return bad("MiniMax API ključ nije podešen ili prompt ne postoji.");

  // upis u email_sends kao draft (pregledaj najnoviji draft za lead)
  const rows = db
    .insert(schema.emailSends)
    .values({
      leadId,
      subject: draft.subject,
      body: draft.body,
      status: "draft",
      generatedByAi: true,
      promptTemplateId: promptTemplateId ?? null,
    })
    .returning()
    .all();

  return ok({ ok: true, draft: rows[0] }, 201);
}