import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq, and, ne, sql } from "drizzle-orm";
import { z } from "zod";
import { generateEmailDraft } from "@/lib/email/generate";

const schema_req = z.object({
  campaignId: z.number(),
  promptTemplateId: z.number().optional(),
  onlyWithWebsite: z.boolean().optional().default(true),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = schema_req.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const { campaignId, promptTemplateId, onlyWithWebsite } = parsed.data;

  const db = getDb();

  const whereParts = [
    eq(schema.leads.campaignId, campaignId),
    eq(schema.leads.doNotContact, false),
    ne(schema.leads.email, ""),
    sql`${schema.leads.email} IS NOT NULL`,
  ];
  if (onlyWithWebsite) {
    whereParts.push(sql`${schema.leads.websiteNormalized} IS NOT NULL`);
  }

  const leads = db
    .select({ id: schema.leads.id })
    .from(schema.leads)
    .where(and(...whereParts))
    .all();

  let generated = 0;
  let failed = 0;
  const errors: { leadId: number; error: string }[] = [];

  for (const l of leads) {
    const draft = await generateEmailDraft(l.id, promptTemplateId);
    if (!draft) {
      failed++;
      errors.push({ leadId: l.id, error: "MiniMax poziv nije uspeo" });
      continue;
    }
    db.insert(schema.emailSends)
      .values({
        leadId: l.id,
        subject: draft.subject,
        body: draft.body,
        status: "draft",
        generatedByAi: true,
        promptTemplateId: promptTemplateId ?? null,
      })
      .run();
    generated++;
  }

  return ok({ ok: true, generated, failed, total: leads.length, errors: errors.slice(0, 20) });
}