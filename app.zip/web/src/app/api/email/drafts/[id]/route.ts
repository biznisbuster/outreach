import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq } from "drizzle-orm";
import { z } from "zod";

const patchSchema = z.object({
  subject: z.string().optional(),
  body: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const body = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .update(schema.emailSends)
    .set({ ...parsed.data })
    .where(eq(schema.emailSends.id, Number(idStr)))
    .returning()
    .all();
  const updated = rows[0];
  if (!updated) return notFound();
  return ok(updated);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const db = getDb();
  db.delete(schema.emailSends).where(eq(schema.emailSends.id, Number(idStr))).run();
  return ok({ ok: true });
}