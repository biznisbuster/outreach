import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq } from "drizzle-orm";
import { z } from "zod";

const approveSchema = z.object({
  senderId: z.number().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const body = await req.json().catch(() => null);
  const parsed = approveSchema.safeParse(body || {});
  const db = getDb();
  const id = Number(idStr);
  const [es] = db.select().from(schema.emailSends).where(eq(schema.emailSends.id, id)).all();
  if (!es) return notFound("Email nije pronađen");
  if (es.status !== "draft") return bad("Samo draft može da se odobri");
  const rows = db
    .update(schema.emailSends)
    .set({
      status: "queued",
      reviewed: true,
      queuedAt: new Date(),
      senderId: parsed.success && parsed.data.senderId ? parsed.data.senderId : es.senderId,
    })
    .where(eq(schema.emailSends.id, id))
    .returning()
    .all();
  return ok({ ok: true, emailSend: rows[0] });
}