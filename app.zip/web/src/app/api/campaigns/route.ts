import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  const db = getDb();
  const items = db.select().from(schema.campaigns).orderBy(schema.campaigns.createdAt).all();
  return ok(items);
}

const createSchema = z.object({
  name: z.string().min(1),
  category: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .insert(schema.campaigns)
    .values({
      name: parsed.data.name,
      category: parsed.data.category ?? null,
      city: parsed.data.city ?? null,
    })
    .returning()
    .all();
  return ok(rows[0], 201);
}
