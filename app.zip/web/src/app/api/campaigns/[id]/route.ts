import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized, notFound } from "@/lib/api";
import { eq, sql } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const db = getDb();
  const [c] = db.select().from(schema.campaigns).where(eq(schema.campaigns.id, id)).all();
  if (!c) return notFound("Kampanja nije pronađena");
  const leadsCount = db
    .select({ c: sql<number>`count(*)` })
    .from(schema.leads)
    .where(eq(schema.leads.campaignId, id))
    .all()[0]?.c ?? 0;
  return ok({ ...c, leadsCount });
}

const patchSchema = z.object({
  name: z.string().min(1).optional(),
  category: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  promptTemplateId: z.number().optional().nullable(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const body = await req.json().catch(() => null);
  const parsed = patchSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");
  const db = getDb();
  const rows = db
    .update(schema.campaigns)
    .set(parsed.data)
    .where(eq(schema.campaigns.id, id))
    .returning()
    .all();
  const updated = rows[0];
  if (!updated) return notFound("Kampanja nije pronađena");
  return ok(updated);
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { id: idStr } = await params;
  const id = Number(idStr);
  const db = getDb();
  db.delete(schema.campaigns).where(eq(schema.campaigns.id, id)).run();
  return ok({ ok: true });
}
