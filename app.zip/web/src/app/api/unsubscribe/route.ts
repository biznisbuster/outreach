import { NextResponse } from "next/server";
import { getDb, schema } from "@/lib/db";
import { eq } from "drizzle-orm";
import { verifyHmac } from "@/lib/crypto";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id"));
  const token = url.searchParams.get("token") || "";
  if (!id || !token) {
    return new NextResponse("Neispravan unsubscribe zahtev.", { status: 400 });
  }
  if (!verifyHmac(`unsubscribe:${id}`, token)) {
    return new NextResponse("Nevažeći token.", { status: 403 });
  }
  const db = getDb();
  const [es] = db.select().from(schema.emailSends).where(eq(schema.emailSends.id, id)).all();
  if (!es) return new NextResponse("Email ne postoji.", { status: 404 });

  // markiraj lead kao do_not_contact
  db.update(schema.leads).set({ doNotContact: true }).where(eq(schema.leads.id, es.leadId)).run();
  const exists = db.select().from(schema.blocklist).where(eq(schema.blocklist.leadId, es.leadId)).limit(1).all();
  if (exists.length === 0) {
    db.insert(schema.blocklist).values({ leadId: es.leadId, reason: "Unsubscribe" }).run();
  }
  // zaustavi sve queued za taj lead
  db.update(schema.emailSends)
    .set({ status: "failed", error: "Unsubscribed" })
    .where(eq(schema.emailSends.leadId, es.leadId))
    .run();

  return new NextResponse(
    `<html><body style="font-family:sans-serif;text-align:center;padding:40px">
      <h1 style="color:#16a34a">Uspesno odjavljeno</h1>
      <p>Vise te ne cemo kontaktirati.</p>
    </body></html>`,
    { status: 200, headers: { "Content-Type": "text/html; charset=utf-8" } },
  );
}