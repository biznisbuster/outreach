import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { z } from "zod";
import { isMinimaxConfigured, getMinimaxClient, getMinimaxConfig } from "@/lib/minimax";
import { TOOLS, executeTool } from "@/lib/ai/tools";
import { eq, desc } from "drizzle-orm";
import type { ChatCompletionMessageParam } from "openai/resources/chat/completions";

type StoredMessage = {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_calls?: { id: string; type: "function"; function: { name: string; arguments: string } }[];
  tool_call_id?: string;
  name?: string;
};

const chatSchema = z.object({
  chatId: z.number().optional(),
  message: z.string().min(1),
});

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const parsed = chatSchema.safeParse(body);
  if (!parsed.success) return bad(parsed.error.issues[0]?.message || "Neispravan unos");

  if (!isMinimaxConfigured()) {
    return bad("MiniMax API ključ nije podešen.");
  }

  const db = getDb();

  // učitaj ili kreiraj chat
  let chatId = parsed.data.chatId;
  let messages: StoredMessage[] = [];
  if (chatId) {
    const [row] = db.select().from(schema.aiChats).where(eq(schema.aiChats.id, chatId)).all();
    if (row) messages = JSON.parse(row.messagesJson || "[]");
    else chatId = undefined;
  }

  // učitaj system prompt
  const [sysPrompt] = db
    .select()
    .from(schema.promptTemplates)
    .where(eq(schema.promptTemplates.type, "assistant"))
    .orderBy(desc(schema.promptTemplates.isDefault))
    .limit(1)
    .all();

  const systemContent =
    sysPrompt?.body ||
    "Ti si lični asistent za B2B outreach. Koristi dostupne alate da odgovoriš na pitanja o leadovima i kampanjama.";

  messages.push({ role: "user", content: parsed.data.message });

  const client = getMinimaxClient();
  const cfg = getMinimaxConfig();

  // conversation loop (max 5 iteracija tool poziva)
  for (let i = 0; i < 5; i++) {
    const allMsgs: ChatCompletionMessageParam[] = [
      { role: "system", content: systemContent },
      ...messages.map((m) => buildSdkMessage(m)),
    ];
    const res = await client.chat.completions.create({
      model: cfg.model,
      messages: allMsgs,
      tools: TOOLS,
      tool_choice: "auto",
      temperature: 0.4,
      max_tokens: 1500,
    });
    const choice = res.choices?.[0];
    if (!choice) break;
    const assistantMsg = choice.message;

    // tool pozivi?
    if (assistantMsg.tool_calls && assistantMsg.tool_calls.length > 0) {
      messages.push({
        role: "assistant",
        content: assistantMsg.content || "",
        tool_calls: assistantMsg.tool_calls.map((tc) => ({
          id: tc.id,
          type: "function" as const,
          function: { name: tc.function.name, arguments: tc.function.arguments },
        })),
      });
      for (const tc of assistantMsg.tool_calls) {
        const result = await executeTool(tc.function.name, tc.function.arguments);
        messages.push({
          role: "tool",
          tool_call_id: tc.id,
          name: tc.function.name,
          content: result,
        });
      }
      continue;
    }

    const finalText = assistantMsg.content || "(prazan odgovor)";
    messages.push({ role: "assistant", content: finalText });
    break;
  }

  // persist
  const messagesJson = JSON.stringify(messages);
  if (chatId) {
    db.update(schema.aiChats).set({ messagesJson }).where(eq(schema.aiChats.id, chatId)).run();
  } else {
    const [row] = db
      .insert(schema.aiChats)
      .values({ messagesJson })
      .returning()
      .all();
    chatId = row.id;
  }

  // vrati poslednji assistant odgovor
  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
  return ok({ ok: true, chatId, reply: lastAssistant?.content || "", messages });
}

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  const db = getDb();
  const rows = db
    .select({ id: schema.aiChats.id, createdAt: schema.aiChats.createdAt })
    .from(schema.aiChats)
    .orderBy(desc(schema.aiChats.createdAt))
    .limit(50)
    .all();
  return ok(rows);
}

/** Mapiranje našeg StoredMessage u OpenAI SDK ChatCompletionMessageParam. */
function buildSdkMessage(m: StoredMessage): ChatCompletionMessageParam {
  if (m.role === "system") return { role: "system", content: m.content };
  if (m.role === "user") return { role: "user", content: m.content };
  if (m.role === "tool") {
    return { role: "tool", tool_call_id: m.tool_call_id || "", content: m.content };
  }
  // assistant
  if (m.tool_calls && m.tool_calls.length > 0) {
    return {
      role: "assistant",
      content: m.content || null,
      tool_calls: m.tool_calls.map((tc) => ({
        id: tc.id,
        type: "function" as const,
        function: { name: tc.function.name, arguments: tc.function.arguments },
      })),
    };
  }
  return { role: "assistant", content: m.content };
}