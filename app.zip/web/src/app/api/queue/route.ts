import { getDb, schema } from "@/lib/db";
import { requireSession, ok, unauthorized } from "@/lib/api";
import { desc, eq, sql } from "drizzle-orm";

export async function GET(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const url = new URL(req.url);
  const status = url.searchParams.get("status") || "queued";
  const limit = Math.min(Number(url.searchParams.get("limit") || 200), 500);

  const db = getDb();
  const rows = db
    .select({
      id: schema.emailSends.id,
      subject: schema.emailSends.subject,
      status: schema.emailSends.status,
      queuedAt: schema.emailSends.queuedAt,
      sentAt: schema.emailSends.sentAt,
      reviewed: schema.emailSends.reviewed,
      error: schema.emailSends.error,
      leadId: schema.emailSends.leadId,
      leadName: schema.leads.name,
      leadEmail: schema.leads.email,
      campaignId: schema.leads.campaignId,
      senderId: schema.emailSends.senderId,
      senderEmail: schema.senders.email,
      replied: schema.emailSends.replied,
    })
    .from(schema.emailSends)
    .leftJoin(schema.leads, eq(schema.emailSends.leadId, schema.leads.id))
    .leftJoin(schema.senders, eq(schema.emailSends.senderId, schema.senders.id))
    .where(eq(schema.emailSends.status, status))
    .orderBy(desc(schema.emailSends.queuedAt))
    .limit(limit)
    .all();

  const counts = db
    .select({ status: schema.emailSends.status, c: sql<number>`count(*)` })
    .from(schema.emailSends)
    .groupBy(schema.emailSends.status)
    .all();

  return ok({ items: rows, counts });
}