import { NextResponse } from "next/server";
import fs from "node:fs";
import { getDb, schema } from "@/lib/db";
import { eq, desc } from "drizzle-orm";

export async function GET(_req: Request, { params }: { params: Promise<{ leadId: string }> }) {
  const { leadId: leadIdStr } = await params;
  const db = getDb();
  const row = db
    .select()
    .from(schema.screenshots)
    .where(eq(schema.screenshots.leadId, Number(leadIdStr)))
    .orderBy(desc(schema.screenshots.capturedAt))
    .limit(1)
    .all()[0];
  if (!row || !fs.existsSync(row.path)) {
    return NextResponse.json({ error: "Nije pronađeno" }, { status: 404 });
  }
  const buf = fs.readFileSync(row.path);
  return new NextResponse(new Uint8Array(buf), {
    headers: { "Content-Type": "image/png", "Cache-Control": "private, max-age=60" },
  });
}
