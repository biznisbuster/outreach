import { getDb, schema } from "@/lib/db";
import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { eq } from "drizzle-orm";
import { triggerScrape } from "@/lib/scraping/client";

export async function POST(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const body = await req.json().catch(() => null);
  const leadId = body?.leadId;
  if (!leadId) return bad("leadId je obavezan");

  const db = getDb();
  const [lead] = db.select().from(schema.leads).where(eq(schema.leads.id, Number(leadId))).all();
  if (!lead) return bad("Lead ne postoji");
  if (!lead.websiteNormalized) return bad("Lead nema website");

  try {
    const res = await triggerScrape(Number(leadId));
    return ok({ ok: true, jobId: res.jobId, message: "Scrape pokrenut." });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return bad(`Scraper servis nije dostupan: ${msg}`);
  }
}
