import { requireSession, ok, bad, unauthorized } from "@/lib/api";
import { getScrapeStatus } from "@/lib/scraping/client";

export async function GET(_req: Request, { params }: { params: Promise<{ jobId: string }> }) {
  const session = await requireSession();
  if (!session) return unauthorized();
  const { jobId } = await params;
  try {
    const data = await getScrapeStatus(jobId);
    return ok(data);
  } catch (e) {
    return bad(`Scraper status greška: ${e instanceof Error ? e.message : String(e)}`);
  }
}