import { getDb, schema } from "@/lib/db";
import { requireSession, ok, unauthorized } from "@/lib/api";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorized();
  const db = getDb();
  const items = db
    .select({
      id: schema.emailReplies.id,
      leadId: schema.emailReplies.leadId,
      leadName: schema.leads.name,
      leadEmail: schema.leads.email,
      fromEmail: schema.emailReplies.fromEmail,
      subject: schema.emailReplies.subject,
      receivedAt: schema.emailReplies.receivedAt,
      matchedBy: schema.emailReplies.matchedBy,
      emailSendId: schema.emailReplies.emailSendId,
      sentSubject: schema.emailSends.subject,
    })
    .from(schema.emailReplies)
    .leftJoin(schema.leads, eq(schema.leads.id, schema.emailReplies.leadId))
    .leftJoin(schema.emailSends, eq(schema.emailSends.id, schema.emailReplies.emailSendId))
    .orderBy(desc(schema.emailReplies.receivedAt))
    .limit(200)
    .all();
  return ok(items);
}