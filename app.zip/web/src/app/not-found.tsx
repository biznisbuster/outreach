import Link from "next/link";
import { Button } from "@/components/ui/button";
import { FileQuestion } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 p-4">
      <div className="text-center">
        <FileQuestion className="mx-auto mb-3 h-12 w-12 text-muted-foreground" />
        <h1 className="mb-1 text-2xl font-bold">404 — Stranica ne postoji</h1>
        <p className="mb-4 text-sm text-muted-foreground">Proveri URL ili se vrati na dashboard.</p>
        <Button asChild>
          <Link href="/">← Nazad na dashboard</Link>
        </Button>
      </div>
    </div>
  );
}