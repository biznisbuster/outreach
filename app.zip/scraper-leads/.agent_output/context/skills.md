# Skills — domain knowledge for this project

## Web scraping fundamentals

- **Playwright (Python)**: async-first; supports Chromium/Firefox/WebKit. Persistent browser context for cookies/storage if needed.
- **Stealth**: `playwright-stealth` patches common fingerprinting vectors (navigator.webdriver, chrome object, permissions, plugins).
- **Selector strategy**: prefer stable attributes (`data-*`, `aria-label`, `role`) over classes (Google rewrites class names per deploy).
- **Retry pattern**: exponential backoff with jitter (`tenacity` is the standard library) — never spin on a failing request.

## Google Maps specifics

- Search URL: `https://www.google.com/maps/search/{query}/?hl={lang}&gl={country}`. Filters go in as additional params (`?hl=sr&gl=rs`).
- Results feed lives in `[role="feed"]`. Each result card is `[role="article"]` (in newer layouts) or anchored by `a[href*="/maps/place/"]`.
- Detail panel lives in `[role="main"]`. Per-field values are exposed via buttons with `data-item-id` attribute.
- Stable attributes observed:
  - `data-item-id="phone"` (or similar like `phone:tel:...`)
  - `data-item-id="authority"` for website
  - `data-item-id="address"` for address
  - `data-item-id="category"` for category
- Lat/lng often present in URL hash or `<meta itemprop="latitude">` / `itemprop="longitude"` tags.
- `place_id` is in the URL: `ChIJ...` chunk.

## Serbia-specific data

- Cities: Belgrade, Novi Sad, Niš, Kragujevac, Subotica, Zlatibor, Kopaonik, Vrnjačka Banja, Kruševac, Leskovac, Pančevo, Čačak, Kraljevo, Smederevo, Valjevo, etc. — note both Latin and Cyrillic spellings (Крушевац, Круше́вац).
- Phone format: +381 XX XXX XXXX (mobile starts with 06x; landlines vary by region). Strip leading 0 → prepend country code.
- Postal code: 5 digits, e.g., `37000` for Kruševac.
- Default locale `sr_RS`, timezone `Europe/Belgrade`.

## Email extraction heuristics

- `mailto:` hrefs are reliable but rare on small business sites.
- Obfuscations to handle: `[at]`, `(at)`, `&#64;`, `[dot]`, `(dot)`. Replace with `@`/`.` and apply a permissive regex.
- Conservative regex: `\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b`
- Avoid crawling login walls, PDF generators, or geo-fenced pages — just bail on error/timeout.

## Stealth tier behavioral differences

| Tier | Delays | UA rotation | Typing | Proxy | Other |
|---|---|---|---|---|---|
| off | none | static | instant | none | — |
| lite (default) | 2–5s | random desktop Chrome | all-at-once | optional | locale/tz match |
| standard | +jitter | random | char-by-char 80–200ms | optional | + scroll-jitter |
| aggressive | standard+ | per-request | char-by-char | rotating | + viewport randomization |

## Useful one-liners

```bash
# Inspect a single Maps detail page interactively
uv run python -c "
import asyncio
from playwright.async_api import async_playwright
async def go():
    async with async_playwright() as p:
        b = await p.chromium.launch(headless=False)
        page = await (await b.new_context()).new_page()
        await page.goto('https://www.google.com/maps/search/frizerski+salon+Krusevac/')
        await asyncio.sleep(20); await b.close()
asyncio.run(go())
"
```
