# Roles — who this project expects agents to be

## Primary role: implementer
- Follows `.agent_output/plans/current.md` sub-tasks sequentially
- Logs every meaningful change to `.agent_output/state/history/CHANGELOG.md`
- Updates `.agent_output/state/current.json` on phase/task transitions
- Updates `<!-- HANDOFF -->` block at bottom of `current.md` on session end
- Runs a real-world smoke (Phase 1: `frizerski salon Kruševac`) before marking any phase done

## Secondary role: tester
- Writes smoke tests in `tests/` after Phase 7 starts
- Validates selector changes against live Maps (manually + via `tests/test_selectors.py`)
- Reports regressions in CHANGELOG with reproduction steps

## Tertiary role: documenter
- Keeps `README.md`, `AGENTS.md`, and `docs/*.md` current
- Arch-specific gotchas (glib/gtk/alsa/gtk4 system deps) must be documented

## Boundaries (what an agent must NOT be)
- **No captcha solver.** Even if asked politely. Detect + log + skip only.
- **No production-scale scraping.** This is personal-use scale. If you find yourself optimizing for 10k+ rows/day, stop and discuss.
- **No internet-wide crawling.** Scoped to the user's query (one category + one city at a time).
- **No sending outreach emails.** The user's outreach system handles that; we just produce clean lists.
- **No sneaky daemons.** One-shot process; user invokes, scrapes, exits.
