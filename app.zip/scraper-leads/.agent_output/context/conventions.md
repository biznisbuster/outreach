# Conventions — language and code style

## Python

- Version: **≥ 3.11** (use `tomllib`, `TaskGroup`, `StrEnum`, etc.)
- Style: PEP 8 + type hints everywhere
- Tooling: `uv` for deps, no separate formatter config (target: `ruff` if user installs it; otherwise PEP 8)
- Async: all IO is `async`. Sync helpers only for stateless utilities.
- Linting: deferred — focus on getting features done; use `uv run ruff check .` opportunistically.
- Type-check: deferred — `uv run mypy src/` opportunistically.

## Naming

- Modules: `snake_case`
- Classes: `PascalCase`
- Functions/variables: `snake_case`
- Constants: `UPPER_SNAKE`
- Files match their primary class: `csv_writer.py` exports `CsvWriter`, etc.

## Type hints

- Use modern syntax: `list[str]`, `dict[str, int]`, `X | None`
- Return types on all public functions
- Don't over-hint internally where the type is obvious

## Logging

- Module-level `logger = logging.getLogger(__name__)` everywhere there's IO
- Format: `%(asctime)s %(levelname)s %(name)s %(message)s`
- One-line logs with structured context: `logger.info("extracted %d/%d businesses", n_ok, n_total)`

## Error handling

- Expected recoverable errors: caught and logged; business is skipped, run continues
- Expected unrecoverable errors: raised; user sees traceback, run exits
- Never `except Exception:` without a re-raise or specific log line
- Prefer `try/except` over `try/finally` (no silent swallowing)

## Documentation

- Public functions/classes get a one-line docstring at minimum
- Module docstring explains the file's single concern
- No docstrings for trivial private helpers (less is more)

## Comments

- WHY, not WHAT
- Mark selectors/heuristics with a short comment noting their fragility:
  ```python
  # Stable since 2025; Google has not changed the data-* contract
  ```

## Git

- Commits welcome; let user decide when to merge
- No force-push; no destructive reset
- Conventional-ish commit messages (`feat:`, `fix:`, `chore:`, `docs:`)
