# Rules — non-negotiable project rules

## Hard rules (never violate)

1. **No captcha solving.** Detect → log → skip. Even if the user changes their mind mid-session. Stealth tier escalation is the only mitigation.
2. **No deletions.** Edit, rewrite, archive to `.agent_output/plans/archive/`. Filesystem blocked at harness level but treat as a binding rule.
3. **No `git reset --hard`, `git clean -f`, `git push --force`.** Either by harness blocks or by project rule.
4. **No sudo, no system modifications.** Stay inside `uv` for environment work.
5. **No accessing** `.env`, `*.pem`, `*.key`, AWS creds, `/etc/*`, `~/.ssh/*`, `~/` from outside the project.
6. **No system-wide installs.** Use `uv add` for Python deps; document Arch packages the user should `pacman -S` separately.

## Process rules

7. **Always update CHANGELOG.md after a meaningful change.** See `AGENTS.md` for format.
8. **Always update state/current.json when advancing phase/task.**
9. **Always update `<!-- HANDOFF -->` block of `current.md` on session end.**
10. **Run a real smoke** on a meaningful city (e.g., `frizerski salon Kruševac`) before marking a phase done.
11. **Async cancellation must close the browser context cleanly.** Use `try/finally` around Playwright session.
12. **No captcha solving.** Yes, listed twice. Important.

## Soft rules (violate only with comment in CHANGELOG)

13. **Selectors should have ≥2 fallback candidates** in `utils/selectors.py` once Phase 2 starts.
14. **No hard-coded paths.** Output paths go through CLI flag.
15. **No `print()` in production code paths.** Use `logging`.
16. **Don't add deps without it being a sub-task in `current.md`.** Update plan, then add dep.
17. **Phases ship, then advance.** Don't jump phases; finish the sub-tasks.

## Recovery rules

18. **If a Playwright session gets stuck** (e.g., captcha, infinite load): log, close that page, continue. On the next business, you may get a fresh captcha or fresh load.
19. **If a selector fails 5+ times in a row**: that's a Google Maps change. Stop the run, log "possible selector drift", and surface the issue to the user.
20. **If uv lockfile or browser install breaks**: prefer a clean state — delete `.venv` (safe — uv manages it), re-run `uv sync && uv run playwright install chromium`. Do NOT delete other files.

## When in doubt

- Prefer **less code** over more.
- Prefer **fewer deps** over more.
- Prefer **plain asyncio + stdlib** over framework magic.
- When unsure about a UX decision, default to "user can override via flag".

## What success looks like

A run that produces a clean CSV with 50–200 Kruševac hairdressers, deduplicated, with phones where available, completing in 5–15 minutes without triggering captcha.
