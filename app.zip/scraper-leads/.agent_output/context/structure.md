# Structure — code organization

```
maps_cold_calling/
├── AGENTS.md                       # top-level agent instructions (resume + conventions)
├── README.md                       # user-facing docs (created in Phase 7)
├── .agentignore                    # files to exclude from agent context
├── pyproject.toml                  # uv-managed project file
├── uv.lock                         # dependency lockfile (uv-managed)
├── .python-version                 # uv: pinned Python version
│
├── src/
│   └── maps_cold_calling/          # main package
│       ├── __init__.py
│       ├── __main__.py             # entrypoint for `python -m maps_cold_calling`
│       ├── cli.py                  # argparse CLI
│       ├── config.py               # CLI/env/defaults config loading
│       ├── models.py               # Business dataclass
│       ├── runner.py               # orchestrates sources → exporter
│       │
│       ├── scraper/                # Playwright-based extractors
│       │   ├── __init__.py
│       │   ├── browser.py          # launch_browser() factory
│       │   ├── maps_search.py      # list place URLs
│       │   ├── maps_detail.py      # extract one Business
│       │   └── email.py            # homepage email extraction (opt-in)
│       │
│       ├── sources/                # source adapters (Protocol)
│       │   ├── __init__.py
│       │   ├── base.py             # Source Protocol
│       │   ├── google_maps.py      # GoogleMapsSource
│       │   └── planplus.py         # PlanPlusSource
│       │
│       ├── export/                 # output writers
│       │   ├── __init__.py
│       │   ├── exporter.py         # Exporter Protocol
│       │   ├── csv_writer.py
│       │   ├── json_writer.py
│       │   └── sqlite_writer.py
│       │
│       ├── storage/                # persistence
│       │   ├── __init__.py
│       │   └── checkpoint.py       # JSONL append + resume reader
│       │
│       └── utils/
│           ├── __init__.py
│           ├── selectors.py        # centralized selector fallbacks
│           ├── phone.py            # E.164 normalization (phonenumbers)
│           ├── rate_limit.py       # jitter, humanize
│           ├── retries.py          # tenacity wrappers
│           ├── captcha.py          # detect-only
│           └── dedupe.py           # cross-source dedupe keying
│
├── scripts/
│   └── smoke_browser.py            # opens Maps, asserts title
│
├── tests/
│   ├── test_models.py
│   ├── test_phone.py
│   ├── test_selectors.py
│   └── test_dedupe.py
│
├── docs/
│   └── planplus.md                 # planplus.rs reverse-engineering notes
│
└── examples/
    ├── leads.csv                   # sample output (after first run)
    └── leads.json
```

## Module responsibilities

- **`cli.py`**: only argparse + delegation to `runner.run(config)`. No business logic.
- **`config.py`**: takes parsed CLI args + env vars, returns a typed `RunConfig` dataclass.
- **`runner.py`**: orchestrates the source(s) → per-business pipeline → exporter; handles cancellation cleanly.
- **`scraper/`**: low-level Playwright. **One concern per file**.
- **`sources/`**: implements `Source` Protocol. Knows nothing about CLI or export.
- **`export/`**: implements `Exporter` Protocol. Knows nothing about scraping.
- **`storage/`**: file-backed state (JSONL checkpoints).
- **`utils/`**: stateless helpers.
