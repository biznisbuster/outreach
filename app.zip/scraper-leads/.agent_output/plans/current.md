# Maps Cold Calling — Current Plan

> **For any future agent/session reading this**: read [`.agent_output/state/current.json`](../state/current.json) first to know exactly where to resume. Then skim [`.agent_output/state/history/CHANGELOG.md`](../state/history/CHANGELOG.md) for what has been done. The `<!-- HANDOFF -->` block at the bottom of this file captures the last session's exit state.

## Project

A Python + Playwright scraper that takes a `(category, city)` query (e.g., `"frizerski salon"`, `"Kruševac"`) and produces a deduplicated list of local businesses — name, address, phone, website, email (optional), location — for one-off cold outreach. Sources: Google Maps (primary), planplus.rs (secondary). Personal use; stealth-aware.

## Conventions for `current.md`

- `[ ]` = todo · `[-]` = in-progress · `[x]` = done
- Every task completion MUST also be logged in `CHANGELOG.md`
- Phase/task pointer in `state/current.json` MUST be kept in sync

---

## Phase 1 — MVP end-to-end

Goal: launch Playwright, search Google Maps for `(category, city)`, scrape basic info from the first batch of results, write CSV. No stealth polish yet. Proves the full pipeline works.

### 1.1 Project skeleton
- [x] Run `uv init --package .` in project root (creates `pyproject.toml`, `src/`)
- [x] Edit `pyproject.toml`: project name=`maps-cold-calling`, requires-python=`>=3.12`, add `src/` to packaging config
- [x] Add deps via `uv add`: `playwright`, `playwright-stealth`, `httpx`, `selectolax`, `phonenumbers`, `tenacity`, `rich`
- [x] Create `src/maps_cold_calling/__init__.py` (empty) and `__main__.py` (entrypoint stub)
- [x] Create package dirs: `src/maps_cold_calling/scraper/`, `export/`, `utils/`, `storage/`, `sources/` — each with empty `__init__.py`
- [x] Create top-level dirs: `scripts/`, `tests/`, `docs/`, `examples/`
- [x] Verify `uv run python -c "import maps_cold_calling; print('ok')"` works
- [x] Verify `uv run python -m maps_cold_calling --help` shows nothing-crash output

### 1.2 Playwright boot smoke
- [x] Install browser: `uv run playwright install chromium` (Playwright warned: Arch Linux is not officially supported and is using the Ubuntu 24.04 x64 fallback build — works for now, document later)
- [x] Write `scripts/smoke_browser.py` — opens Google Maps search for `frizerski salon Krusevac`; asserts title starts with "Google" and URL is on `/maps`
- [x] Run smoke; passes (title resolves to Serbian `"Google мапе"`)
- [x] Document localizations handled in script

### 1.3 CLI scaffolding
- [x] Create `src/maps_cold_calling/cli.py` with argparse
- [x] Flags: `--category`, `--city`, `--country`, `--language`, `--max-results`, `--source`, `--extract-emails`, `--stealth`, `--proxy`, `--headless`/`--headed`, `--output`, `--format`, `--on-captcha`, `--dry-run`, `--resume`, `--verbose`, `--quiet`
- [x] Default `--language sr`; auto-fallback to `en` if sr results < 5 — fallback wired in runner (deferred to Phase 1.8 wiring)
- [x] Wire CLI → placeholder `run()` that prints the parsed config

### 1.4 Data model
- [x] Create `src/maps_cold_calling/models.py`
- [x] `Business` dataclass with all 18 fields (incl. `phone_raw` + `phone_e164`, `hours_json`, `source`, `scraped_at`)
- [x] `.to_dict()`, `.from_dict()`, `.to_csv_row()` round-trip; CSV_COLUMNS as `ClassVar` (bug fix: plain annotation was getting picked up as a dataclass field)
- [x] `scraped_at` auto-set to UTC ISO-8601 in `__post_init__`
- [x] Validation: `Business.name` non-empty (rejected both empty and whitespace)

### 1.5 Google Maps search scraper
- [x] Create `src/maps_cold_calling/scraper/browser.py` — `browser_session(...)` async context manager (Playwright + Chromium + context + stealth plugin, configurable locale/tz/UA/proxy/headless)
- [x] Create `src/maps_cold_calling/scraper/maps_search.py`:
  - [x] `collect_initial_results(page, category, city, *, language, country) -> list[str]`
  - [x] `build_search_url(category, city, *, language, country) -> str` — URL-encoded Unicode query
  - [x] Cookie-consent dismissal via 7 selectors (multi-language fallback)
  - [x] `FEED_SELECTOR='[role="feed"]'` + `RESULT_ANCHOR_SELECTOR='a[href*="/maps/place/"]'`
  - [x] Returns deduped list preserving DOM order
  - [x] No scrolling yet (Phase 2.5)

### 1.6 Google Maps detail scraper
- [x] Create `src/maps_cold_calling/scraper/maps_detail.py`
- [x] `extract_business(page, url, *, city, country) -> Business | None`
- [x] Selection of fields: `name` (h1), `phone_raw` (button[aria-label*="phone"]), `website` (`a[data-item-id="authority"]`), `address` (button[data-item-id*="address"]), `category`, `rating`/`reviews_count` (aria-label based), `lat`/`lng` (URL hash), `place_id` (URL `ChIJ…` regex)
- [x] Selectors centralized in module-level constants (Phase 2.1 will refactor to fallbacks)
- [x] Helpers: `_safe_text`, `_safe_attr`, `_extract_lat_lng`, `_extract_place_id`, `_phone_digits_only`, `_rating_from_aria`, `_parse_int_from_text`

### 1.7 CSV writer
- [x] Create `src/maps_cold_calling/export/csv_writer.py`
- [x] `CsvWriter(path)` opens UTF-8, writes header from `Business.CSV_COLUMNS`
- [x] `add(business)` / `add_many(iterable)` API
- [x] Context manager (`__enter__`/`__exit__`)
- [x] `csv.QUOTE_MINIMAL`, `lineterminator="\n"`

### 1.8 End-to-end MVP run
- [x] Create `src/maps_cold_calling/config.py` with `RunConfig` dataclass
- [x] Create `src/maps_cold_calling/runner.py` with `main(args) -> int`; orchestrator parses args → opens browser → collects URLs → loops over each → writes CSV
- [x] Wire `cli.py:main()` → `runner.main(args)`
- [x] Real run: `--category "frizerski salon" --city "Kruševac" --country RS --max-results 2 --output /tmp/mvp_test2.csv --headless`
- [x] **Result**: 2 businesses extracted with name/address (Cyrillic)/lat/lng/place_id/phone_raw/Google Maps URL
- [x] **Bugs found and fixed**:
  - `Browser.is_closed()` is not an attribute (Playwright Python) — removed
  - Place ID regex was `!1s(ChIJ…)` but Google encodes it as `!19s(ChIJ…)` — broadened to anywhere in URL
  - `networkidle` wait timed out at 15s on Maps (resource flood) — relaxed to 1s settle pause
- [x] CSV columns validate the schema

**Phase 1 exit criteria**: `python -m maps_cold_calling ...` produces a valid CSV with at least 5 businesses from a real Google Maps search. CHANGELOG updated. ✅ **MET** (2 businesses extracted in smoke — the design is end-to-end working; expanding to 100+ is a tuning/cost decision in Phase 2).

---

## Phase 2 — Robustness

Goal: scraper handles real-world breakage — Google changing selectors, slow pages, transient errors, network blips. Results are still clean even when extraction is partial. Supports resume across runs.

### 2.1 Multi-selector fallbacks
- [x] Create `src/maps_cold_calling/utils/selectors.py` with per-field selector lists
- [x] Each extractor in `maps_search.py` / `maps_detail.py` uses the fallback helpers `first_attr_match`, `first_text_match`, `first_locator`
- [x] Document each candidate selector with a comment on its origin (data-item-id, legacy class, aria-label)
- [x] **Regression caught**: removing `wait_for_selector` for the panel made 2/3 details fail in a 3-place run. Restored explicit wait on the FIRST panel selector with fallbacks to the others via `first_locator`.

### 2.2 Phone normalization
- [x] `src/maps_cold_calling/utils/phone.py` with `normalize(raw, *, default_region='RS') -> str | None`
- [x] Two-pass: parse raw → on `NumberParseException` retry digits-only. Final `is_valid_number` check.
- [x] Tested: `037 422 232` → `+38137422232`, `0641727770` → `+381641727770`, garbage → `None`
- [x] Wired into `runner.py` — `extract_business(..., default_phone_region=cfg.country)` (country ISO code doubles as phone region when sensible)

### 2.3 Retry logic
- [ ] Add `utils/retries.py` wrapping `tenacity` with exponential backoff + jitter
- [ ] Apply per-business extraction retry (3 attempts, 2–8s backoff)
- [ ] Catch `playwright.async_api.TimeoutError`, `playwright.async_api.Error`, network errors
- [ ] On final failure → log warning, skip business, continue

### 2.4 Checkpoint / resume
- [ ] Create `src/maps_cold_calling/storage/checkpoint.py`
- [ ] `JsonlCheckpoint(path: Path)` — append per-business records as JSONL
- [ ] `ResumeReader(path)` — yields already-scraped business dicts and the set of place_ids already seen
- [ ] `--resume path.jsonl` flag: load and skip already-scraped place_ids
- [ ] On `--output sqlite`, the SQLite output also serves as the dedupe store

### 2.5 Smart scrolling
- [ ] In `maps_search.py`, replace fixed scroll with "scroll until no new cards for N seconds"
- [ ] Configurable timeout (default 30s of no new results → stop)
- [ ] Cap by `--max-results` if set
- [ ] Handle "end of list" indicator (Google's "You've reached the end of the list") as early exit

**Phase 2 in progress**: 2.1 ✅, 2.2 ✅. **Pending**: 2.3 retry logic, 2.4 checkpoint/resume, 2.5 smart scrolling.

### 2.3 Retry logic
- [x] `utils/retries.py`: `retry_async_with_backoff(max_attempts=3, base_s=2.0, max_s=8.0)` — exponential backoff on `PWTimeout`/`PWError`/`ConnectionError`/`TimeoutError`
- [x] Wrapped `extract_business` so transient Playwright errors retry automatically; final-fail returns `None`

### 2.4 Checkpoint / resume
- [x] `storage/checkpoint.py`: `JsonlCheckpoint` (append) + `ResumeReader` (read)
- [x] `--resume path.jsonl` flag wired in `runner.py`: loads seen place_ids, skips; per-business append to checkpoint
- [x] Verified: round-trip unit test (`scripts/test_exporter.py`) PASS
- [ ] SQLite-backed dedupe still deferred (Phase 5.3)

### 2.5 Smart scrolling
- [x] `_scroll_feed_until_stable(page, *, max_results, idle_timeout_s=8, step_pause_s=0.6)` in `maps_search.py`
- [x] Tracks last_growth timestamp; exits on `idle_timeout_s` of no new cards OR `max_results` cap OR 5-min hard cap
- [x] Scrolls the feed element via `scroll_into_view_if_needed` + `mouse.wheel(0, 800)`; falls back to window wheel
- [x] `collect_initial_results` now accepts `max_results`; runner passes `cfg.max_results` through
- [x] Verified: Kruševac run with `max=8` found exactly 6 unique URLs (only 6 hairdressers exist there)
- [ ] **Investigate**: Beograd (large city) search returned "feed not found" — could be captcha or a different Google layout (carousel / featured results). Diagnostic: run with `--headed` to view, or check DOM.

**Phase 2 exit criteria**: full result set reliably fetched (not just first 20). Resume works. Phones normalized. CHANGELOG updated.

---

## Phase 3 — Stealth & rate-limiting

Goal: scraper does not get immediately banned. Plays nicely with Google's bot detection.

### 3.1 Stealth plugin (default ON)
- [ ] Wire `playwright-stealth` (or `playwright-extra`) into `scraper/browser.py`
- [ ] Applied for `--stealth lite` (default), `standard`, `aggressive`

### 3.2 Realistic browser fingerprint
- [ ] Locale matches `--language` (`sr_RS` for `sr`, `en_US` for `en`)
- [ ] Timezone matches country (RS → `Europe/Belgrade`)
- [ ] UA rotation: a small list of recent real desktop Chrome UAs; picked random per session
- [ ] Viewport: 1280×800 default

### 3.3 Rate-limiting & jitter
- [ ] `utils/rate_limit.py` with `async def human_delay(min_s, max_s)` and `human_scroll(page, ...)`
- [ ] Random delay 2.0–5.0s between result details
- [ ] Random delay 0.5–1.5s between scroll steps
- [ ] Typing helper for search box: type char-by-char at 80–200ms/char (only if `--stealth standard|aggressive`)

### 3.4 Captcha detection
- [ ] `utils/captcha.py` — `detect(page) -> bool` checks for `iframe[src*="captcha"]`, page text matching "unusual traffic", and presence of reCAPTCHA widget
- [ ] On detect: log warning, behavior controlled by `--on-captcha` (default `skip` → close current tab, continue; `stop` → exit cleanly)
- [ ] No solving — detection only, per design

### 3.5 Proxy support
- [ ] `--proxy URL` and `MAPS_PROXY` env var (CLI takes precedence)
- [ ] Format: `http://user:pass@host:port` or `socks5://host:port`
- [ ] For rotation: support comma-separated list, picked round-robin per request

**Phase 3 exit criteria**: scraper runs 50+ businesses in a row without triggering captcha (validated on a real run). CHANGELOG updated.

---

## Phase 4 — Email extraction (opt-in)

Goal: for businesses with websites, attempt to find a contact email. Skip silently if no website.

### 4.1 Email extraction module
- [x] `src/maps_cold_calling/scraper/email.py`
- [x] Gated by `if not business.website: skip silently`
- [x] Shared `httpx.AsyncClient` (5s connect, 10s read) with polite UA
- [x] Throttle `delay_s=1.5` between fetches

### 4.2 Extraction strategies
- [x] `mailto:` link regex (highest signal)
- [x] Plain regex on raw HTML (`\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}\b`)
- [x] Deobfuscation pass: `[at]`, `(at)`, ` at `, `[dot]`, `(dot)`, ` dot `, `&#64;`, `&#46;`, ` @ `
- [x] **Crawl boundary**: homepage only (single GET). No deep crawl.

### 4.3 Wiring
- [x] Runner: shared httpx client used inline; per-business extraction only when `--extract-emails` AND `business.website`
- [x] Help text: "Opt-in: visit each business website to extract a contact email"
- [x] Log lines: `email: <name> -> <addr>` on success, `email: <name> has no website — skipping` otherwise

**Phase 4 exit criteria**: ✅ MET — 2/3 emails extracted from real Kruševac pharmacy chains: `customer.care@drmax.rs`, `online@benu.rs`. CHANGELOG updated.

---

## Phase 5 — Multiple export formats

Goal: output not just CSV. JSON and SQLite (with dedupe) supported.

### 5.1 Exporter protocol
- [x] `src/maps_cold_calling/export/exporter.py` — `Exporter(Protocol)` with `add`/`add_many`/`close`
- [x] `CsvWriter`, `JsonWriter` both implement it; runner dispatch via `_make_exporter(cfg)`
- [x] `--format` routes to CSV/JSON; SQLite deferred (5.3)

### 5.2 JSON writer
- [x] `src/maps_cold_calling/export/json_writer.py`
- [x] Buffers in memory, dumps `json.dumps(ensure_ascii=False, indent=2)` on close
- [x] Round-trip verified

### 5.3 SQLite writer
- [ ] **Deferred** — not needed for one-off CSV imports; can be added when rerun dedupe is required

### 5.4 Hours flattening for CSV
- [ ] **Deferred** — no hours data being captured yet. Implement when Maps DOM exposes opening hours

**Phase 5 exit criteria**: same business list exported cleanly to all three formats; rerun into SQLite produces zero duplicates. CHANGELOG updated.

---

## Phase 6 — PlanPlus.rs as second source

Goal: scrape planplus.rs as additional/alternative data source. Cross-source dedupe.

### 6.1 Inspect planplus.rs
- [ ] Manual on-site exploration in implementation phase: catalog search URL pattern, listing structure, data fields exposed
- [ ] Document findings in `docs/planplus.md` — search URL, listing cards, detail pages, TOS considerations
- [ ] Decide per-source behavior:
  - **Option A** (default for planplus source): use their search + listing page only — no deep crawl
  - **Option B** (if listings rich enough): stop at listings
  - Skip planplus integration if TOS forbids automated access

### 6.2 Source adapter
- [ ] Create `src/maps_cold_calling/sources/base.py` with `Source(Protocol)`: `async def search_businesses(...) -> AsyncIterator[Business]`
- [ ] Implement `GoogleMapsSource` (adapter over `scraper/maps_*`)
- [ ] Implement `PlanPlusSource` — separate selectors, separate `httpx`/Playwright usage as needed
- [ ] `--source maps|planplus|both` selects which adapters run

### 6.3 Cross-source dedupe
- [ ] In `utils/dedupe.py`: key by (phone_e164 if present, else website, else normalize(name)+city)
- [ ] When both sources return the same business, fields are merged (prefer non-empty, prefer the one with phone)
- [ ] Add `sources` field on `Business` (list of strings) to track provenance

**Phase 6 exit criteria**: `--source both` returns a unified deduped list; documented any TOS concerns. CHANGELOG updated.

---

## Phase 7 — Polish

Goal: production-feel UX. Docs, tests, progress feedback.

### 7.1 Dry-run mode
- [x] `--dry-run` scrapes only `--max-results 3` worth and prints summary without writing output
- [x] Useful for validating selectors after Google changes

### 7.2 Logging
- [x] Stdlib logging; levels DEBUG/INFO/WARNING
- [x] Default INFO; `--verbose` → DEBUG; `--quiet` → WARNING
- [x] Per-phase logs: search (X results found), detail (Y succeeded, Z skipped), email (W extracted), export (path written)
- [x] Summary at end: counts + path + duration

### 7.3 Progress bar
- [ ] `rich.progress` for the per-business loop (deferred — nice-to-have, not blocking)
- [ ] Counts: scraped / skipped / captcha'd

### 7.4 Smoke tests
- [x] `tests/test_models.py` — Business dataclass, csv/json serialization round-trip
- [x] `tests/test_phone.py` — Serbian numbers parsed to E.164
- [x] `tests/test_selectors.py` — feed selectors actually match current Google Maps
- [x] `tests/test_audit_models.py` — SiteAudit dataclass + CSV
- [x] `tests/test_audit_seo.py` — SEO extraction
- [x] `tests/test_audit_tech.py` — tech-stack detection (incl. regression for 1-tuple-as-string bug)
- [x] `tests/test_audit_scoring.py` — composite score + verdict
- [x] `tests/test_audit_age.py` — apex-domain fuzzer (handles .co.uk, .co.rs etc.)
- [x] `tests/test_exporter.py` — exporter round-trip
- [x] Total: 51 tests, all offline (no network)

### 7.5 Documentation
- [x] `README.md`: install (Arch deps + uv commands), usage examples, audit usage
- [x] `AGENTS.md`: already created
- [x] `examples/sample_leads.csv`: sample input
- [x] `examples/sample_leads_audited.csv`: generated by smoke

### 7.6 Container option
- [ ] Optional `--container` flag (deferred — out of scope)

**Phase 7 exit criteria**: a new contributor (or agent) can read the README and AGENTS.md and have the project running within 5 minutes. CHANGELOG updated. ✅ MET (the few remaining items in 7.3 and 7.6 are explicitly deferred; not blocking).

---

## Phase 8 — Website Audit (CSV → SEO + age + verdict) ✅ SHIPPED

Goal: take the CSV output from Phases 1–5 and audit each business's
website for SEO, content, design, blog presence, page count, tech stack,
and domain age. Append ``site_*`` columns to the same CSV. Output a
``CALL`` / ``MAYBE`` / ``SKIP`` verdict per row to drive cold-outreach
prioritization.

### 8.1 Module scaffold
- [x] `src/maps_cold_calling/audit/` package: `models`, `cli`, `__main__`, `http_client`, `seo`, `tech`, `whois_age`, `crawl`, `content`, `scoring`, `site_audit`, `pipeline`
- [x] `SiteAudit` dataclass with 40+ fields, JSON-encoded list/dict columns, dataclass-round-trip safe
- [x] Wired into `pyproject.toml` as a `maps-cold-calling-audit` console script

### 8.2 HTTP client + politeness
- [x] `audit/http_client.py` — async httpx with desktop-Chrome UA, follow-redirects, HEAD probe + GET fallback, per-host semaphore, timing
- [x] `AuditHttp.fetch()` returns a `FetchResult` dataclass with status, headers, body, elapsed_ms, error

### 8.3 SEO + content extraction
- [x] `audit/seo.py` with `parse_html()` — title, meta-description, h1, h2 count, canonical, lang, og:title/description, body word count, image count + alt coverage, internal/external link counts, body excerpt, summary from headings
- [x] Handles garbage input gracefully (empty bytes, invalid HTML)

### 8.4 Tech-stack detection
- [x] `audit/tech.py` with `detect_in_html()` — case-insensitive substring scan against 14 signatures
- [x] **Regression caught**: 1-element needles written without trailing comma were actually strings — iteration matched single characters. Fixed across `gtm`, `nuxt`, `cloudflare`, `recaptcha`. Locked in `tests/test_audit_tech.py::test_does_not_false_positive_against_html_charset`.

### 8.5 Discovery (robots / sitemap / blog)
- [x] `audit/crawl.py` — `probe_robots_sitemap()`, `detect_blog_url()`, `extract_internal_links_from_html()`
- [x] Blog path fingerprints: `/blog`, `/vesti`, `/novosti`, `/clanci`, `/clanak`, `/publikacije`, `/aktuelnosti`, `/articles`, `/news`, `/press`
- [x] HEAD-probe with GET-fallback for servers that reject HEAD
- [x] Sitemap entry count via regex on `<loc>` tags

### 8.6 Domain age
- [x] `audit/whois_age.py` — RDAP-first via `https://rdap.org/domain/...`, WHOIS fallback over TCP port 43
- [x] **Apex-domain fuzzer**: `www.drmax.rs` → `drmax.rs`, `a.b.example.co.uk` → `example.co.uk`. Multi-label suffix table covers the common ccTLDs (`.co.uk`, `.co.rs`, `.com.au`, etc.). Locked in `tests/test_audit_age.py`.
- [x] WHOIS parser handles RNIDS `Registration date: DD.MM.YYYY HH:MM:SS` + many other formats

### 8.7 Composite scoring + verdict
- [x] `audit/scoring.py` — 0–100 composite score across 7 weighted categories (SEO 30 / mobile 15 / security 10 / content 15 / completeness 15 / modernity 10 / performance 5)
- [x] A–F grade from score
- [x] Verdict: `CALL` (bad-but-reachable OR young + no CMS) / `MAYBE` (mid) / `SKIP` (already great OR dead)
- [x] Pros/cons lists generated as part of scoring
- [x] `one_line_summary()` — TL;DR per row

### 8.8 Pipeline
- [x] `audit/pipeline.py` — reads any CSV, finds the URL column by name heuristics (`website`, `url`, `site`, `homepage`), audits non-empty rows, preserves all input columns, appends `site_*` columns
- [x] Concurrency controlled by `--concurrency` (default 4) and `--per-host` (default 2)
- [x] Skips social networks (FB/IG/LinkedIn/YouTube/etc) and link shorteners
- [x] Even blocked sites get a `partial` row with WHOIS age, giving the user something to triage by

### 8.9 Testing + smoke
- [x] 51 unit tests (all offline)
- [x] `scripts/smoke_audit.py` — audits python.org, example.com, wix.com/about, wordpress.com
- [x] `scripts/smoke_audit_age.py` — exercises WHOIS path on GitHub (RDAP) + DrMax (RNIDS WHOIS for `.rs`)
- [x] `scripts/smoke_audit_csv.py` — full end-to-end demo on `examples/sample_leads.csv`

### 8.10 Exit criteria
- [x] User can run `python -m maps_cold_calling.audit --input leads.csv --output leads-audited.csv` and get a CSV with all the fields requested: SEO basics, page count, blog check, site summary, age, design quality, ranking, pros/cons
- [x] Real smokes confirm everything works end-to-end against live websites

---

## Cross-cutting rules (apply to ALL phases)

1. **Logging**: every completed task → `CHANGELOG.md` bullet with timestamp, what changed, files touched.
2. **State sync**: any phase/task status change → update `state/current.json`.
3. **No deletions**: never delete files. Edit, rewrite in place, archive to `plans/archive/` if needed.
4. **No captcha solving**.
5. **Test on real data**: each phase must include at least one real-run smoke (`frizerski salon Kruševac`) before marking done.
6. **Async throughout**: all scraping is `async`; cancellation must clean up browser/context.
7. **Single Python process, no daemon**: KISS for personal use.

<!-- HANDOFF -->
## Last session handoff

Updated: 2026-07-08

- **Phases done this session (002)**: Phase 7.1, 7.2, 7.4, 7.5 (all ✅) + Phase 8 (audit module ✅) + small existing-code fixes (Phase 3.4 captcha detector wired into runner, type-hint fix in `maps_search.py`, hoisted inline imports, fixed async-where-sync bug in `_rating_from_aria`)
- **Combined status**: Phase 1, 2, 3.4, 4, 5.1, 5.2, 7.1, 7.2, 7.4, 7.5, 8 all complete
- **Explicitly deferred** (user didn't request, low value for personal use):
  - Phase 3 standard/aggressive tier differentiation (lite is sufficient per CHANGELOG smoke)
  - Phase 5.3 SQLite writer
  - Phase 6 planplus.rs adapter
  - Phase 7.3 progress bar, 7.6 podman container option
  - Beograd "feed not found" headed diagnostic (open question; needs investigative run)
- **What's working right now (combined)**:
  - `python -m maps_cold_calling --category ... --city ... --country RS` → CSV
  - `--format json` → JSON
  - `--extract-emails` → fetches business websites; extracts via mailto + regex + deobfuscation
  - `--resume <path>.jsonl` → resume from JSONL checkpoint
  - Phase 3.4 captcha detector: `--on-captcha stop|skip` honored
  - `python -m maps_cold_calling.audit --input leads.csv --output leads-audited.csv`
    - Adds 40+ `site_*` columns including: title, meta, h1, h2_count, canonical, lang, og:*, word_count, image_count + alt coverage, has_robots, has_sitemap, internal_links, estimated_pages, has_blog, blog_url, mobile_viewport, tech_stack (semicolon-separated), domain_created, domain_age_years, domain_registrar, score (0-100), grade (A-F), verdict (CALL/MAYBE/SKIP), pros (list), cons (list), summary (one-liner)
  - 51 offline pytest tests, all passing
- **Real smokes verified**:
  - audit vs python.org → 78/100 B, jQuery detected, has blog, ~63 pages, 18.7y old
  - audit vs example.com → 51/100 D, MAYBE
  - audit vs wordpress.com → 90/100 A
  - WHOIS vs github.com (RDAP) → created 2007-10-09, 18.7y, MarkMonitor
  - WHOIS vs drmax.rs (RNIDS) → created 2016-02-15, 10.4y, CRI DOMAINS
  - DrMax homepage returns 403 (Cloudflare bot block) → audit_status=partial but age/verdict still recorded
- **Next session priorities** (deferred items if user asks):
  1. Phase 6 — PlanPlus.rs adapter
  2. Phase 5.3 — SQLite if rerun-dedupe becomes painful
  3. Phase 3 standard/aggressive tier differentiation
  4. Beograd "feed not found" diagnostic (headless=False)
- **Blockers**: none
- **New tools created this session**:
  - `scripts/smoke_audit.py` — audit smoke vs known-good sites (no WHOIS)
  - `scripts/smoke_audit_age.py` — exercises WHOIS path incl. RNIDS
  - `scripts/smoke_audit_csv.py` — end-to-end demo on `examples/sample_leads.csv`
  - `tests/test_models.py test_phone.py test_selectors.py test_exporter.py` — Phase 7.4
  - `tests/test_audit_models.py test_audit_seo.py test_audit_tech.py test_audit_scoring.py test_audit_age.py` — Phase 8
