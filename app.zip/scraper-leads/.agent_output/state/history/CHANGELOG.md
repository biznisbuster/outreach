# CHANGELOG — Maps Cold Calling

> Append-only log. Every change goes here. Read this first if resuming after context loss; then read `.agent_output/plans/current.md` for the live plan and `.agent_output/state/current.json` for the resume pointer.

Format: `## YYYY-MM-DD — short summary` → bullets for what changed, files touched.

---

## 2026-07-07 — Project bootstrapped

- Created `.agent_output/` scaffold: `sessions/`, `plans/archive/`, `context/`, `state/history/`, `research/discussions/`
- Wrote `.agent_output/plans/current.md` — full 7-phase plan with sub-tasks, conventions, and handoff block
- Wrote `.agent_output/state/current.json` — phase/task pointer for resume
- Initialized this CHANGELOG
- Wrote top-level `AGENTS.md` — continuity + conventions instructions for future agents
- Wrote top-level `.agentignore` — files to keep out of agent context
- Verified environment: `uv 0.11.23` available, `podman` available, on Arch Linux
- Next: Phase 1.1 — initialize Python package via `uv init --package .`

## 2026-07-07 — Phase 1.1–1.3 complete: skeleton, browser smoke, CLI surface

- **1.1 Skeleton**:
  - `uv init --package .` → `pyproject.toml` (Python ≥ 3.12) + `src/` layout
  - Added deps via `uv add`: `playwright`, `playwright-stealth`, `httpx`, `selectolax`, `phonenumbers`, `tenacity`, `rich`
  - Reworked `pyproject.toml` scripts entry: `maps-cold-calling = "maps_cold_calling.cli:main"`
  - `src/maps_cold_calling/__init__.py` exposes `__version__ = "0.1.0"`
  - Created `src/maps_cold_calling/{scraper,sources,export,storage,utils}/` with empty `__init__.py`
  - Created top-level `{scripts,tests,docs,examples}/`
  - Created `__main__.py` calling `cli.main`
  - Verified: `import maps_cold_calling` OK; `python -m maps_cold_calling --help` prints
- **1.2 Browser smoke**:
  - `uv run playwright install chromium` (Arch unsupported → fallback build installed)
  - `scripts/smoke_browser.py`: opens Google Maps with Serbian locale/tz; asserts title starts with "Google" and URL on `/maps`
  - Smoke passes: page title `Google мапе` (Serbian Cyrillic)
- **1.3 CLI**:
  - `src/maps_cold_calling/cli.py` with full flag surface
  - Flags: category/city/country/language/max-results/source/extract-emails/stealth/proxy/headless/output/format/on-captcha/dry-run/resume/verbose/quiet
  - Default `--language sr`; `--country RS`; fallback to `en` flagged deferred to runtime wiring (Phase 1.8)
- **Docs**:
  - `README.md` with install (Arch pacman line) + usage + flag table + resume instructions
- Files touched: ~10 new files in `src/`, `pyproject.toml`, `README.md`, `scripts/smoke_browser.py`, plan/state updates, this CHANGELOG
## 2026-07-07 — Phase 1.4 complete: Business model

- `src/maps_cold_calling/models.py` with `Business` dataclass (18 fields)
- `to_dict()`, `from_dict()`, `to_csv_row()` round-trip verified
- `CSV_COLUMNS` is a `ClassVar` (initial attempt with plain annotation leaked it into `asdict()` — fixed)
- `__post_init__` rejects empty/whitespace `name`
- Verified: `Business(name='…')` constructs, serializes, and round-trips correctly

## 2026-07-07 — Phase 1.5–1.8 complete: end-to-end MVP working

**Browser (1.5)**
- `src/maps_cold_calling/scraper/browser.py` — `browser_session(...)` async context manager
  - Wraps Playwright + Chromium + context + stealth plugin
  - Reads `MAPS_PROXY` env var as fallback to `--proxy`
  - Locale mapped from language (sr → sr-RS, en → en-US); timezone from country (RS → Europe/Belgrade)
  - Random desktop-Chrome UA picked per session
  - Proxy URLs with credentials are redacted in logs
- `cli.py` and `pyproject.toml` both end at `maps_cold_calling.cli:main`

**Maps search (1.5)**
- `src/maps_cold_calling/scraper/maps_search.py`
  - `build_search_url(category, city, *, language, country)` URL-encodes Unicode (Cyrillic `Kruševac` works)
  - `collect_initial_results(page, …)` opens the URL, dismisses the consent banner via 7 multi-language selectors, waits for `[role="feed"]`, dedupes `a[href*="/maps/place/"]` returning DOM order
  - **Bug fixed**: `page.wait_for_load_state("networkidle", timeout=15000)` always timed out — Maps loads lots of resources. Replaced with `await asyncio.sleep(1.0)` settle pause.

**Maps detail (1.6)**
- `src/maps_cold_calling/scraper/maps_detail.py` — `extract_business(page, url, *, city, country)`
- Extracts: `name` (`h1`), `phone_raw` (button[aria-label] starting with phone/telefon), `website` (`a[data-item-id="authority"]`), `address` (button[data-item-id*="address"]), `category` (button[data-item-id*="category"]), `rating` (aria-label matching "X.X stars"), `reviews_count`, `lat`/`lng` (URL hash), `place_id` (URL `ChIJ…`)
- Helpers: `_safe_text`, `_safe_attr`, `_extract_lat_lng`, `_extract_place_id`, `_phone_digits_only`, `_rating_from_aria`, `_parse_int_from_text`
- **Bug fixed**: place_id regex assumed `!1s(ChIJ…)` but Google encodes as `!19s(ChIJ…)` — broadened to `(ChI[A-Za-z0-9_\-]+)` anywhere in URL

**CSV writer (1.7)**
- `src/maps_cold_calling/export/csv_writer.py` — `CsvWriter(path)` opens UTF-8 file, writes `Business.CSV_COLUMNS` header, `add()`/`add_many()` API, context manager

**Runner + wiring (1.8)**
- `src/maps_cold_calling/config.py` — `RunConfig` dataclass
- `src/maps_cold_calling/runner.py` — `main(args)` orchestrator: parses args, configures logging, opens browser, runs search, iterates URLs with per-place error handling
- `cli.py:main()` delegates to `runner.main(args)`
- **`pyproject.toml`** scripts entry: `maps-cold-calling = "maps_cold_calling.cli:main"`

**Real-world smoke**: `--category "frizerski salon" --city "Kruševac" --max-results 2 --output /tmp/mvp_test2.csv --headless` → 2/2 extracted:
- `Frizerski Studio Fantastiko` — phone `037422232` (landline), lat `43.5846402`, lng `21.3247454`, place_id `ChIJzR1iIquHVkcRflU5Arb7m74`
- `Art Win -frizerski salon` — phone `0641727770` (mobile), lat `43.5815221`, lng `21.330181`, place_id `ChIJnwtIP--HVkcRto2wT3Atr68`
- **Bug caught & fixed**: `Browser.is_closed()` is not a Playwright Python attribute — removed from cleanup logic

**Phase 1 exit**: MET. The pipeline runs end-to-end. Phase 2 will improve completeness (rating, reviews, website, category, address cleanup) and add multi-selector fallbacks so we don't regress when Google tweaks the DOM.

- Files touched: `src/maps_cold_calling/{cli,config,runner,models}.py`, `src/maps_cold_calling/scraper/{browser,maps_search,maps_detail}.py`, `src/maps_cold_calling/export/csv_writer.py`, `pyproject.toml`, plan/state updates, this CHANGELOG
- Next: Phase 2.1 — refactor selectors into `src/maps_cold_calling/utils/selectors.py` with multi-candidate fallback lists

## 2026-07-08 — Phase 2.1 + 2.2: selector fallbacks + phone E.164

**2.1 Selector fallbacks**
- New `src/maps_cold_calling/utils/selectors.py`:
  - 7 selector lists (FEED, RESULT_ANCHOR, DETAIL_PANEL, NAME, PHONE_BUTTON, WEBSITE, ADDRESS_BUTTON, CATEGORY_BUTTON, RATING, REVIEWS) — each 3–6 candidates ordered most-reliable first
  - Helpers `first_attr_match`, `first_text_match`, `first_locator` — return first non-empty result across candidates
- Refactored `maps_search.py` to use `FEED_SELECTORS` + `RESULT_ANCHOR_SELECTORS` + `first_locator` for consent dismissal
- Refactored `maps_detail.py` to use the per-field lists + helpers
- **Regression caught & fixed**: removing the explicit `wait_for_selector(DETAIL_PANEL_SELECTOR)` and relying solely on `first_locator` made 2/3 detail pages fail in the 3-place smoke. Restored explicit `wait_for_selector` on `DETAIL_PANEL_SELECTORS[0]` with lazy fallback to `first_locator` for the rest of the chain.
- Added `_strip_address_label()` helper that strips Google’s Cyrillic/Latin `Адреса: ` / `Address: ` prefix from the address aria-label.

**2.2 Phone E.164 normalization**
- New `src/maps_cold_calling/utils/phone.py` with `normalize(raw, *, default_region='RS') -> str | None`
- Two-pass: parse raw → on `NumberParseException`, retry with digits-only. Final `phonenumbers.is_valid_number` check before formatting as E.164.
- Verified: `037/422-232` → `+38137422232`, `0641727770` → `+381641727770`, international `+381641727770` → `+381641727770`, garbage → `None`
- Wired into `extract_business(..., default_phone_region=cfg.country)` in `runner.py`

**Real smoke after Phase 2 refactor**: `--category "frizerski salon" --city "Kruševac" --max-results 3`
- 3/3 extracted (no panel-detection flakes):
  - Frizerski Studio Fantastiko — phone_e164 `+38137422232`, place_id `ChIJzR1iIquHVkcRflU5Arb7m74`
  - Art Win — phone_e164 `+381641727770`, place_id `ChIJnwtIP--HVkcRto2wT3Atr68`
  - ️ IN — phone_e164 `+38137421501`, place_id `ChIJYQrJq-iHVkcRAH72MX_grBQ`
- Addresses cleaned of `Адреса: ` prefix
- **Still empty** for these 3: rating, reviews_count, category, website — could indicate (a) Maps stopped exposing those, (b) these specific businesses genuinely don't publish them, or (c) selector candidates need updating.

**Files touched**:
- new: `src/maps_cold_calling/utils/selectors.py`, `src/maps_cold_calling/utils/phone.py`
- modified: `src/maps_cold_calling/scraper/{maps_search,maps_detail}.py`, `src/maps_cold_calling/runner.py`
- plan/state updates, this CHANGELOG

**Next**: Phase 2.5 (smart scrolling) so we get more than the initial ~20 results, then 2.3 (retries) and 2.4 (JSONL checkpoint).

## 2026-07-08 — Phase 2.5: smart scrolling verified

- `maps_search.py`: new `_scroll_feed_until_stable(page, *, max_results, idle_timeout_s=8, step_pause_s=0.6)`:
  - Pulls URLs from the live DOM at each step
  - Tracks `last_growth` timestamp; stops after `idle_timeout_s` of no new cards
  - Caps at `max_results` if set
  - 5-minute hard cap as safety
  - Scrolls the feed element via `scroll_into_view_if_needed` + `page.mouse.wheel(0, 800)`
- `collect_initial_results(..., max_results=cfg.max_results)` exposes the cap; runner passes it through
- **Verified on Kruševac**: `max-results=8` → 6 unique URLs (only 6 hairdressers exist in Kruševac). Scrolling correctly stopped at the cap, ran in ~9s.
- **Regression spotted (deferred)**: `--city Beograd` returns "feed not found" — possibly captcha or Google’s carousel layout for big-city searches. Needs `--headed` diagnostic.

**Files touched**:
- modified: `src/maps_cold_calling/scraper/maps_search.py`, `src/maps_cold_calling/runner.py`
- plan/state updates, this CHANGELOG

**Next**: Diagnose Beograd "feed not found". Then Phase 2.3 (retry/backoff), 2.4 (JSONL checkpoint). The MVP is shipped — Phase 1-2.5 is a working tool for personal-scale one-off scrapes.

## 2026-07-08 — Diagnostic + rating fix + Phase 2.4 + Phase 4 + Phase 2.3 + Phase 5.1/5.2

**Diagnostic of empty rating/reviews/website fields**
- New `scripts/diag_place.py` dumps `data-item-id` elements, aria-labelled spans, anchors, and H1
- Finding on a Kruševac hairdresser:
  - rating rendered as `span.ceNzKf` with `aria-label="Звездица: 4,7 "` (capital Cyrillic З, comma as decimal)
  - website genuinely absent for small salons
  - "Add a review" only — no review count for places with 0 reviews

**Selector updates (`utils/selectors.py`)**
- `RATING_SELECTORS` widened to 9 candidates (case-insensitive `star`, capital `Звездица` / lowercase `звездица`, `ceNzKf` and `cecioK` classes)
- `REVIEWS_SELECTORS` widened: case-insensitive `reviews` / `utisak` / `recenzi`
- **Bug fix**: `first_attr_match` and `first_text_match` previously used `.first` and only saw one match. Now iterate ALL matches so a populated 2nd element isn't hidden behind an empty 1st.

**Phase 2.4 — JSONL checkpoint/resume**
- `src/maps_cold_calling/storage/checkpoint.py`
  - `JsonlCheckpoint(path)` append-only JSON-line writer
  - `ResumeReader(path)` reads seen place_ids for skip logic
- `--resume path.jsonl` flag in `cli.py` wired through `RunConfig`:
  - On startup, loads seen set
  - Skips businesses whose `google_place_id` is in the seen set
  - Appends each successfully-extracted business to the JSONL
- Verified by `scripts/test_exporter.py` (round-trip OK)

**Phase 5.1 + 5.2 — Exporter protocol + JSON writer**
- `src/maps_cold_calling/export/exporter.py` — `Exporter(Protocol)` with `add`/`add_many`/`close`
- `src/maps_cold_calling/export/json_writer.py` — `JsonWriter` buffers rows in memory, dumps `json.dumps(indent=2)` on close
- `CsvWriter` and `JsonWriter` both implement the protocol
- Runner dispatch via `_make_exporter(cfg)` based on `--format`

**Phase 4 — Email extraction**
- `src/maps_cold_calling/scraper/email.py`
  - `extract_email(url, *, delay_s=1.5, client=None)`
  - Politeness: shared `httpx.AsyncClient`, configurable delay
  - Three-tier extraction strategy in `_extract_from_text`: (1) `mailto:` href regex, (2) plain regex, (3) deobfuscate then regex
  - Deobfuscations handled: `[at]`, `(at)`, ` at `, `[dot]`, `(dot)`, ` dot `, `&#64;`, `&#46;`, ` @ `
  - **Crawl boundary**: homepage only (no deep crawl)
- Wired in `runner.py` — gated by `--extract-emails` AND `business.website is not None`

**Phase 2.3 — Retry/backoff**
- `src/maps_cold_calling/utils/retries.py` — `retry_async_with_backoff(max_attempts=3, base_s=2.0, max_s=8.0)` decorator
- Catches `PlaywrightTimeout`, `PlaywrightError`, `ConnectionError`, `TimeoutError`
- Exponential backoff via doubling + clamp at `max_s`
- Wrapped `extract_business` so each detail extraction retries 3x on transient failures

**New diagnostic / test scripts**
- `scripts/smoke_browser.py` — opens Maps, asserts title starts with "Google"
- `scripts/diag_place.py` — DOM dumper for any place URL
- `scripts/test_email.py` — 6 assertions on text extraction
- `scripts/test_exporter.py` — CSV/JSON/JSONL round-trip

**Real smokes (Kruševac)**:
- 6/6 hairdressers extracted with ratings `4.7, 5.0, 4.7, 4.9, 4.8, 4.2` ✅
- 9/9 pharmacies with `--extract-emails` extracted 2 real emails:
  - Apoteka Dr.Max → `customer.care@drmax.rs`
  - Apoteka BENU MAXI → `online@benu.rs`
  - 1 place with a Facebook URL was skipped (HTTP 400 from FB)

**Files touched this session**:
- new: `src/maps_cold_calling/scraper/email.py`, `src/maps_cold_calling/utils/retries.py`, `src/maps_cold_calling/storage/checkpoint.py`, `src/maps_cold_calling/export/exporter.py`, `src/maps_cold_calling/export/json_writer.py`, `scripts/diag_place.py`, `scripts/test_email.py`, `scripts/test_exporter.py`
- modified: `src/maps_cold_calling/{runner,scraper/maps_detail,scraper/browser}.py`, `src/maps_cold_calling/utils/selectors.py`, plan/state updates, this CHANGELOG

**Status**: MVP+stealth-lite+extraction complete. Phases 1, 2, 4, 5.1, 5.2 done. Phase 3 (tiers beyond lite), 5.3 (SQLite), 6 (planplus.rs), 7 (pytests) remain.

---

## 2026-07-08 — Session 002 start: small fixes + Phase 8 audit scraper

Session started per user request: complete remaining plan items where doable, then build a NEW website audit scraper that takes the leads CSV and augments it with site-quality metrics.

**Plan for this session:**

1. **Small existing-code fixes** (in scope):
   - Fix `maps_search.collect_initial_results` return-type annotation (currently `list[str]` but actually returns `(urls, extras)` tuple) — cosmetic, doesn't break callers
   - Hoist inline `import re` / `import re as _re` in `maps_search._scroll_feed_until_stable` to module top
   - Add `utils/captcha.py` detector (Phase 3.4 — small, isolated, useful) and wire into runner

2. **Phase 7.4 — minimal pytest suite** (high value, low cost):
   - `tests/test_models.py` — Business dataclass, to/from_dict, to_csv_row
   - `tests/test_phone.py` — Serbian E.164 normalization
   - `tests/test_selectors.py` — `_rating_from_aria`, `_parse_int_from_text`, `_extract_place_id` on canned inputs (no network)
   - `tests/test_exporter.py` — exporter round-trip
   - Configure `pyproject.toml` for pytest

3. **Phase 8 — website audit scraper (THE NEW THING user asked for)**:
   - `src/maps_cold_calling/audit/` package with: `cli`, `__main__`, `pipeline`, `http_client`, `seo`, `tech`, `whois_age`, `crawl`, `content`, `scoring`, `reporter`
   - Reads leads CSV, audits each row that has a website
   - Outputs the SAME CSV with appended `site_*` columns + `site_score` / `site_grade` / `site_verdict` / `site_pros` / `site_cons` / `site_summary`
   - Detects: SEO basics, blog presence, page count (sitemap/internal links), tech stack, mobile-friendly, HTTPS, design hints, domain age (RDAP + WHOIS for .rs)
   - Composite 0–100 score + CALL/MAYBE/SKIP verdict for cold outreach prioritization
   - Real smoke against 2–3 sites
   - Update README with audit section

4. **Out of scope this session** (deferred, will note in plan/state):
   - Phase 5.3 SQLite (user didn't ask)
   - Phase 6 planplus.rs (user didn't ask)
   - Phase 3 standard/aggressive tier differentiation (user didn't ask, lite is functional per CHANGELOG)
   - Beograd layout diagnostic (open question, needs headed run)

**ENV**: same Arch Linux + uv 0.11.23 + Playwright Chromium

---

## 2026-07-08 — Session 002 wrap-up: Phase 7 polish + Phase 8 audit module + bug fixes

**Small existing-code fixes**
- `maps_search.py`:
  - Fixed `collect_initial_results` return-type annotation: `list[str]` → `tuple[list[str], dict[str, dict[str, Any]]]`. Actual return was already the tuple; callers (runner) were unpacking correctly; this was cosmetic but visible in editors/type checkers.
  - Hoisted inline `import re` / `import re as _re` to module top. Pre-compiled `_PLACE_ID_RE`, `_FEED_RATING_RE` for clarity and minor perf.
  - Replaced an unescaped backslash in a JS snippet with a raw triple-quoted string (was a `SyntaxWarning`).
- `maps_detail.py`:
  - `_rating_from_aria` was declared `async` but never awaited — callers were returning coroutines. Made it sync and added a thin async alias for back-compat.
- New `src/maps_cold_calling/utils/captcha.py` (Phase 3.4):
  - `detect(page)` checks `/sorry/`, captcha iframes, body-phrase heuristic in 7+ languages.
  - Wired into `runner.py`: after `collect_initial_results`, runs `detect_captcha` and exits per `--on-captcha stop|skip` (exit code 3 for stop, 0 with warning for skip).
- `pyproject.toml`:
  - Second console-script entry: `maps-cold-calling-audit = "maps_cold_calling.audit.cli:main"`
  - Optional `test` extra: `pytest>=8.0.0`
  - `[tool.pytest.ini_options]` block

**Phase 7 polish**
- **7.1** `--dry-run`: already implemented (caps `--max-results` to 3).
- **7.2** stdlib logging with `--verbose` / `--quiet`: already implemented in `_configure_logging`. Confirmed.
- **7.4** Smoke tests: 9 new pytest files, **51 tests, all offline (no network)**:
  - `tests/test_models.py` (Business), `tests/test_phone.py` (E.164), `tests/test_selectors.py` (Maps helpers), `tests/test_exporter.py` (CSV/JSON round-trip)
  - `tests/test_audit_models.py` (SiteAudit + CSV), `tests/test_audit_seo.py` (parse_html on canned HTML), `tests/test_audit_tech.py` (incl. regression for 1-tuple-as-string bug), `tests/test_audit_scoring.py` (CALL/MAYBE/SKIP verdict + summary), `tests/test_audit_age.py` (apex-domain fuzzer)
- **7.5** README rewritten — now documents both CLIs and the audit workflow
- **7.3 (progress bar)** and **7.6 (podman container)** explicitly deferred — not blocking.

**Phase 8 — Website Audit Scraper** (the new module the user asked for)

- New package `src/maps_cold_calling/audit/` (12 files):
  - `models.py` — `SiteAudit` dataclass (40+ fields, JSON-encoded list/dict columns)
  - `cli.py` / `__main__.py` — argparse + entry point for `python -m maps_cold_calling.audit`
  - `pipeline.py` — CSV-in/CSV-out with concurrency + social-network filtering
  - `site_audit.py` — per-site orchestrator (handles `partial` status for blocked pages so WHOIS age still gets recorded)
  - `http_client.py` — `AuditHttp` (async httpx with desktop-Chrome UA, per-host semaphores, follow-redirects, timing)
  - `seo.py` — `parse_html()` (selectolax): title, meta-description, h1, h2 count, canonical, lang, og:title/description, word count, image count + alt-coverage, internal/external links, body excerpt + 1-sentence summary from headings
  - `tech.py` — `detect_in_html()` substring scan against 14 signatures (WordPress, Shopify, Wix, Squarespace, Joomla, Drupal, Ghost, Webflow, Next.js, Nuxt, React, Vue, Bootstrap, Tailwind, jQuery, GA, GTM, FB pixel, Cloudflare, reCAPTCHA)
  - `whois_age.py` — RDAP-first via `https://rdap.org/domain/...`, TCP-WHOIS fallback via `whois.rnids.rs` for `.rs` (and IANA-resolution for arbitrary TLDs). Custom **apex-domain fuzzer** strips `www.` and handles `.co.uk`, `.co.rs`, `.com.au` etc.
  - `crawl.py` — `probe_robots_sitemap()`, `detect_blog_url()`, `extract_internal_links_from_html()`. Blog fingerprints: `/blog`, `/vesti`, `/novosti`, `/clanci`, `/clanak`, `/publikacije`, `/aktuelnosti`, `/articles`, `/news`, `/press`.
  - `scoring.py` — composite 0–100 score weighted: SEO 30 / mobile 15 / security 10 / content 15 / completeness 15 / modernity 10 / performance 5 → A–F grade + **CALL/MAYBE/SKIP** verdict (inverts score with CMS + age): "clear opportunity to pitch" → "personalized" → "already good or dead". Also produces pros/cons lists and a one-line TL;DR.

**Bugs caught and fixed during Phase 8 dev**
- **1-tuple-as-string bug** in `tech.py` signatures: `("gtm", ("googletagmanager.com"))` was a 2-tuple whose second element was a plain string — `for needle in needles` iterated over characters and matched `g` against any HTML. Three needles had this bug (`gtm`, `nuxt`, `cloudflare`). Fixed with trailing commas + regression test `test_does_not_false_positive_against_html_charset`.
- **Apex-domain needed for WHOIS**: WHOIS doesn't return anything for `www.drmax.rs`. Added `_to_apex()` with multi-label suffix table for `.co.*` ccTLDs.
- **RNIDS date format**: `15.02.2016 11:58:51` (DD.MM.YYYY HH:MM:SS) wasn't being parsed — added the format and the `Registration date:` regex.
- **Blocked-page handling**: first version of `_audit_after_lock` returned `audit_status="failed"` early when the homepage was 403'd by Cloudflare. Refactored to do WHOIS/age lookup regardless so blocked sites can still be triaged by age alone. Now `audit_status="partial"` for blocked but data was actually extracted.

**Real smokes** (`scripts/smoke_audit*.py`):
- `smoke_audit.py`: 5 real candidates (`python.org`, `example.com`, `wix.com/about`, `wordpress.com`, `.invalid`)
  - python.org → 78/100 B, jQuery detected, has blog, ~63 pages, score=MAYBE
  - example.com → 51/100 D, MAYBE
  - wix.com/about → 92/100 A, wix+react, ~11177 sitemap pages, SKIP
  - wordpress.com → 90/100 A, wordpress+google_analytics, SKIP
  - .invalid → F, ConnectError recorded
- `smoke_audit_age.py`: 3 candidates (Google, GitHub, DrMax RS)
  - github.com → RDAP works: created 2007-10-09, 18.7 years, MarkMonitor Inc
  - drmax.rs → RNIDS WHOIS works: created 2016-02-15, 10.4 years, CRI DOMAINS
  - google.com → correctly filtered as social/hostile
- `smoke_audit_csv.py`: end-to-end on `examples/sample_leads.csv` → `examples/sample_leads_audited.csv`

**CSV columns appended** (preserves all input columns):
```
audit_status, audit_error, audit_run_at,
site_url, site_http_status, site_response_ms, site_https, site_redirects,
site_page_bytes, site_gzip,
site_title, site_meta_description, site_h1, site_h2_count,
site_canonical, site_lang, site_og_title, site_og_description,
site_word_count, site_image_count, site_image_alt_coverage,
site_has_robots, site_has_sitemap, site_internal_links, site_external_links,
site_estimated_pages, site_has_blog, site_blog_url,
site_mobile_viewport, site_tech_stack,
site_domain, site_domain_created, site_domain_age_years, site_domain_registrar,
site_score, site_grade, site_verdict, site_pros, site_cons, site_summary
```

**Files touched this session**:
- New: `src/maps_cold_calling/audit/{__init__,__main__,cli,models,pipeline,site_audit,http_client,seo,tech,whois_age,crawl,scoring}.py`, `tests/test_models.py`, `tests/test_phone.py`, `tests/test_selectors.py`, `tests/test_exporter.py`, `tests/test_audit_models.py`, `tests/test_audit_seo.py`, `tests/test_audit_tech.py`, `tests/test_audit_scoring.py`, `tests/test_audit_age.py`, `scripts/smoke_audit.py`, `scripts/smoke_audit_age.py`, `scripts/smoke_audit_csv.py`, `examples/sample_leads.csv`
- Modified: `src/maps_cold_calling/scraper/{maps_search,maps_detail}.py`, `src/maps_cold_calling/runner.py`, `src/maps_cold_calling/utils/captcha.py` (new), `pyproject.toml`, `README.md`, plan/state updates, this CHANGELOG

**Session ended — user can now run the full pipeline**:
```bash
uv run python -m maps_cold_calling \
  --category "frizerski salon" --city "Kruševac" --country RS \
  --extract-emails --output leads.csv
uv run python -m maps_cold_calling.audit \
  --input leads.csv --output leads-audited.csv
# Sort leads-audited.csv by site_verdict, then by site_score (CALL first)
```

---

## 2026-07-08 — Verdict threshold retuned after first real run

- The first audit of `/tmp/frizeri_beograd3.csv` (50 Beograd salons) returned **0 CALLs** — even sites with clear flaws (no HTTPS, missing meta, legacy jQuery) ended up MAYBE because the CALL threshold required `score < 55`. Tuning was needed.
- **Updated `_verdict()` in `audit/scoring.py`**:
  - Old: `score < 55 AND (has_blog OR has_cms OR age≤4) → CALL else MAYBE`. 55–80 always MAYBE.
  - New: `score < 70` flips the disposition to **CALL if winnable** (CMS they can edit / has blog / ≤5y old), still MAYBE otherwise. Above 70 stays MAYBE/SKIP.
- **Effect on this real CSV (50 rows, 25 with websites)**: 13 SKIP → 7 MAYBE → **5 CALL** (5 strongest pitches)
- All 51 pytest tests still pass.
- Updated HITS to call out: Sip&Style, BUCKA, D'HAIR, Hair ABBA, NEMANJA HAIR STYLE (oldest at 13y, lowest score at 60)

---

## 2026-07-08 — README rewritten as integration contract

User asked for a "detaljan readme" so an AI integrating a webapp with this scraper would have a complete reference. Rewrote `README.md` (149 → 618 lines) with the following sections, each written as a contract:

1. Quick start (both CLIs)
2. Install — Arch / Debian-Ubuntu VPS / other Linux
3. CLI reference — scraper (every flag + stealth tier meanings)
4. CLI reference — audit (audit steps + verdict semantics + status values)
5. Output schemas — every column for both CLIs, with type and nullability
6. Exit codes
7. Environment variables
8. Webapp integration patterns — three code-complete patterns (subprocess, in-process async, Celery)
9. Sample REST API — concrete endpoint shapes including error mappings
10. Performance, rate limits, stealth
11. Limitations and known issues — explicitly enumerates what won't work
12. Testing
13. Extending the scraper — exact pointers to which files change for common mods
14. Project layout
15. Resume protocol — handover rules for AI agents

Why this matters: the previous README was a 149-line user manual. The new one is a 618-line spec that includes copy-paste FastAPI code, exact column tables, exit-code-to-HTTP mappings, three integration patterns (subprocess / in-process / Celery), and a "what won't work" section so an AI doesn't accidentally promise solved captchas or rendered-JS support.

## 2026-07-08 — FastAPI HTTP wrapper (maps-cold-calling-api)

- Added `src/maps_cold_calling/api.py` — FastAPI service that spawns the CLI as a subprocess per the README §8.1 pattern (Playwright crash cannot take down the webapp). Endpoints: POST /scrape-leads, GET /scrape-leads/status/{job_id}, POST /scrape-leads/import/{job_id}, GET /health.
- Bumped version 0.1.0 → 0.2.0.
- Added `fastapi>=0.115.0`, `uvicorn>=0.32.0` to project dependencies; registered `maps-cold-calling-api` console script.
- Added `Dockerfile` based on `mcr.microsoft.com/playwright/python:v1.61.0-jammy`, exposes 8002, healthcheck wired to /health.
- Files touched: pyproject.toml, src/maps_cold_calling/api.py (new), Dockerfile (new).
- Why: integration with the Outreach webapp — web frontend calls into this HTTP surface instead of importing the Python package.

## 2026-07-08 — Upgraded scraper/maps_search.py to v2 (Maps 2024-2026 burst-aware)

- Replaced `src/maps_cold_calling/scraper/maps_search.py` with the v2 build from `scrape_v2.zip` (previous: `scrape.zip`).
- Why: v1 bailed out at the first 5-15s pause and missed 20-40% of results because Maps loads cards in bursts. v2 idle timeout 30s + 4 scroll mechanisms (scrollTop, mouse wheel, End key, "see more" link) + 10-min hard cap + progress logging + place_id-based dedup.
- Also picked up `scripts/diag_search_exhaustive.py` (new diagnostic).
- Files touched: src/maps_cold_calling/scraper/maps_search.py (replaced), scripts/diag_search_exhaustive.py (new).
- Smoke-tested end-to-end via FastAPI wrapper: 6 rows in 9.9s, exit 0.

## 2026-07-08 — Upgraded to scrape_v3.zip (progress events API)

- Replaced `src/maps_cold_calling/runner.py`, `config.py`, `cli.py` with v3 versions.
- Added `src/maps_cold_calling/progress.py` — new `ProgressEvent`/`ProgressEmitter` with 7 stages (startup/search/detail/email/captcha/export/done) and 5 events (start/progress/end/skip/error). Emits via callback, JSON-lines stdout, or JSON snapshot file.
- New CLI flags: `--progress-stdout`, `--progress-file`.
- Wired progress file into FastAPI wrapper (`api.py`) — each job gets its own `progress.json`; new endpoint `/scrape-leads/progress/{job_id}` returns latest snapshot.
- Added `changelog_api.py` — exposes recent CHANGELOG entries via `/scrape-leads/changelog`.
- Files touched: src/maps_cold_calling/runner.py, config.py, cli.py, progress.py (new), changelog_api.py (new), api.py.
- Why: webapp can now show live stage + count + progress bar instead of a generic spinner.

## 2026-07-08 — Enrichment endpoint (fuzzy Google Maps lookup)

- Added `src/maps_cold_calling/enrich.py` — new router with `POST /enrich-lead`. Takes `{name, city, category, max_results}` → reuses internal `start_scrape()` to query Google Maps → fuzzy-matches result by name (SequenceMatcher) → returns best match data (rating, reviews_count, phone, website, address, lat/lng, place_id, maps_url).
- Wired into `api.py` via `app.include_router(enrich_router)`.
- Fixed circular-import issue (`_current_stage` was unused) and dict-vs-Pydantic-model mismatch in `enrich.py` (now constructs proper `ScrapeReq` model).
- Why: Outreach webapp needs to enrich existing leads that have Google rating but null `reviews_count` — old scraper (port 8001) crawls websites, doesn't query Google Maps. This new endpoint fills the gap.
- Files touched: src/maps_cold_calling/enrich.py (new), src/maps_cold_calling/api.py.
- Integration: Next.js `POST /api/leads/{id}/enrich` proxy + UI "Enrich" button on lead detail.

## 2026-07-08 — Enrich retry chain (name → category → generic)

- `enrich.py` now retries with category as fallback when name query returns 0 results, then falls back to "firma" (generic) as last resort.
- Lowered fuzzy match threshold from 0.55 → 0.45 (category search returns many similar names).
- Returns `bestMatchName` + `bestMatchScore` in failure response so UI can show "best we found was X at Y%".
- Why: Cvjetanović (Niš) doesn't appear in Google Maps under its own name, but does appear under "stomatološka ordinacija" + Niš.
- Files touched: src/maps_cold_calling/enrich.py.

## 2026-07-08 — Enrich import fix

- Moved `from . import api as scraper_api` to function body in `enrich.py` (was a module-level import that needed to come after circular-import check).
- Files touched: src/maps_cold_calling/enrich.py.

## 2026-07-08 — reviews_count extraction fix for 2025+ Maps UI

- `src/maps_cold_calling/utils/selectors.py` — `REVIEWS_SELECTORS` extended with six new
  candidates targeting the 2025+ Maps layout where reviews count lives in a dedicated
  `span[role="img"]` (separate from the rating pill):
    - `span[role="img"][aria-label*="рецензија" i]` (lowercase cyrillic, owner panel)
    - `span[role="img"][aria-label*="Рецензија" i]` (uppercase, neighbour cards)
    - `span[role="img"][aria-label*="Recenzija" i]`, `…recenzija`, `…utisaka`, `…recenzij`
- `src/maps_cold_calling/scraper/maps_detail.py` — new `_parse_reviews_label` helper.
  Accepts all observed aria-label shapes:
    - "1.911 рецензија"        → (None, 1911)
    - "615 рецензија"          → (None, 615)
    - "Звездица: 4,5 Рецензија: 581"          → (4.5, 581)
    - "Звездица: 4,4 Рецензија: 1.589"        → (4.4, 1589)
    - "Rating: 4.5 Reviews: 120"               → (4.5, 120)
    - "5,0 od 5 zvezdica 312 recenzija"         → (5.0, 312)
  - `_normalize_number` now drops dots (Serbian thousands separator) before `int()`.
  - "Reviews:" added to `_REVIEWS_BLOCK_RE`; "rating" added to `_RATING_BLOCK_RE`.
  - Loose rating form ("5,0 od 5 zvezdica", "Rating 4.5 out of 5") covered by a
    secondary regex with no `:` anchor.
  - The loose `_REVIEWS_PHRASE_RE` (no `:`) is only used when the label lacks `:`,
    so "Rating: 4.5 Reviews: 120" doesn't accidentally classify "4.5" as reviews.
- `extract_business_impl` now calls `_parse_reviews_label` and falls back to its
  rating only when the existing RATING_SELECTORS pass missed the rating.
- `tests/test_selectors.py` — 8 new tests covering all observed aria-label shapes
  (cyrillic only, combined, English, Serbian-latin, empty, garbage).
- All 19 selector tests pass; real-world smoke (5 hotels in Beograd, sr) now
  extracts reviews_count for every result (4 / 7 / 1911 / 615 / 5399 / 816).

Why: User reported `reviews_count` was always null on the webapp's leads table
even though Google Maps clearly shows the value (e.g. 1.911 for Hotel Beograd).
Root cause: old selectors only matched the legacy `button[aria-label*="reviews"]`
shape, but 2025+ Maps puts reviews in a separate `span[role="img"]` whose
aria-label is either "1.911 рецензија" (owner) or "Звездица: 4,5 Рецензија: 581"
(neighbour cards).

## 2026-07-08 — Fix api↔enrich circular import

- `src/maps_cold_calling/enrich.py` — moved `from .api import _JOBS` from top-level
  to inside the `enrich_lead` handler (where it's actually used). Top-level
  `from .api import _JOBS` triggered a circular import at module load time:
    - `api.py:98` does `from maps_cold_calling.enrich import router as enrich_router`
    - `enrich.py:19` (now removed) did `from .api import _JOBS` at import time
  - When Python started loading `api.py`, it tried to import `enrich.py`, which
    then tried to import `_JOBS` from the still-partial `api.py` module → ImportError.
  - Lazy import (inside the function body) breaks the cycle: by the time
    `enrich_lead` is called, the `api` module is fully loaded.
- `src/maps_cold_calling/api.py` — confirmed `router` import is safe (APIRouter()
  has no dependency on `api.py`).
- Note: `api.py:350 main()` has no `if __name__ == "__main__":` guard, so
  `python -m maps_cold_calling.api` exits silently. Workaround: run with
  `uvicorn maps_cold_calling.api:app --host 0.0.0.0 --port 8002`. Documented
  in README run commands.
- Verified: enrich endpoint now returns real Google Maps data (Hotel Beograd
  → Hotel Jardin, 4.4★, 31 recenzija).

## 2026-07-08 — /enrich-url endpoint (100% accurate match by Google Maps URL)

- `src/maps_cold_calling/enrich.py` — new endpoint `POST /enrich-url` that
  matches by Google Maps `place_id` instead of fuzzy string similarity.
  - Extracts `!19sChIJ...` from the URL via `_extract_place_id()` regex.
  - If place_id found: runs scrape with the name from the URL, then finds
    the row with matching `google_place_id` (100% accurate).
  - If place_id not found: falls back to existing `/enrich-lead` fuzzy.
  - If city missing: returns clear "Potreban je grad" error.
  - Confidence always 1.0 for URL-based match.
- Why: User reported fuzzy match picking wrong business for "Stomatološka
  ordinacija Kraljevo - DENT IN PLUS" (matched "CIP doo Kraljevo" at 36%
  similarity). With URL-based match, place_id ChIJC1fBWeOpV0cRa04OP_ePetg
  resolves to the exact business with 17 reviews and 4.8★.
- Verified: end-to-end test returned confidence=1.0, source="url", all
  fields populated for the Dentocratia lead.
