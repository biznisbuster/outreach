"""Playwright headless screenshot homepage-a."""
import os
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"


def capture_screenshot(url: str, lead_id: int, out_dir: str = "/data/screenshots") -> str | None:
    """Snima full-page screenshot. Vraća apsolutnu putanju fajla ili None.

    Strategija: pokušaj prvo sa `domcontentloaded` (brz, dovoljno za screenshot),
    pa ako ne uspe retry sa `load` + duži timeout. `networkidle` izbegavamo jer
    sajtovi sa analytics/long-polling nikad ne postignu networkidle.
    """
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"{lead_id}.png")

    attempts = [
        # (wait_until, timeout_ms, post_wait_ms)
        ("domcontentloaded", 20000, 1500),
        ("load", 30000, 1000),
    ]

    for wait_until, timeout_ms, post_wait in attempts:
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(
                    headless=True,
                    args=["--no-sandbox", "--disable-dev-shm-usage"],
                )
                context = browser.new_context(
                    viewport={"width": 1280, "height": 800},
                    device_scale_factor=1,
                    user_agent=USER_AGENT,
                )
                page = context.new_page()
                # Blokiraj teške third-party skripte da ubrzamo load
                page.route(
                    "**/*",
                    lambda route: route.abort()
                    if any(
                        dom in route.request.url
                        for dom in (
                            "google-analytics.com",
                            "googletagmanager.com",
                            "facebook.com",
                            "hotjar.com",
                            "doubleclick.net",
                        )
                    )
                    else route.continue_(),
                )
                page.goto(url, wait_until=wait_until, timeout=timeout_ms)
                page.wait_for_timeout(post_wait)
                page.screenshot(path=out_path, full_page=False)
                browser.close()
            if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
                return out_path
        except (PWTimeout, Exception) as e:
            print(f"[screenshot] pokušaj wait_until={wait_until} za {url} fail: {type(e).__name__}: {e}")
            continue
    return None
