# Outreach

Vlasnik-aplikacija za B2B cold outreach (Srbija, lokalni biznisi). Web app na VPS-u, single-user. Hiper-personalizacija emailova preko MiniMax M3.

## Arhitektura

```
[Browser] → [Next.js :3000]
              ├─ API routes (REST)
              ├─ node-cron worker (scheduler + IMAP poll)
              ├─ Drizzle → SQLite (/data/outreach.db)
              ├─ DB-backed Settings (DB → env → default)
              ├─ ActivityPanel (globalni job tracker)
              ├─ Audit log (bulk_delete, enrich, lead promene)
              ├─ HTTP → [Python FastAPI :8001 scraper servis]
              │            ├─ httpx + trafilatura + extruct + lxml + Playwright
              │            └─ zapisuje rezultate u isti SQLite fajl
              └─ HTTP → [Python FastAPI :8002 maps-cold-calling servis]
                            ├─ Playwright + Google Maps scraper
                            ├─ Progress events (v3): startup→search→detail→email→export→done
                            ├─ Enrich: fuzzy Google Maps lookup za postojeće leadove
                            └─ /scrape-leads, /scrape-leads/status/{id}, /scrape-leads/progress/{id}, /enrich-lead
[Next.js] → nodemailer → [SMTP tvoj domen + aliasi]
[node-cron] → imapflow → [IMAP inbox] → detektuje reply → zaustavlja sekvencu
[Next.js + scraper] → MiniMax M3 (text + vision) za: vizuelnu ocenu, SEO sumar, AI personalizaciju, čet.
```

Docker compose pokreće 4 kontejnera: `web` (Next.js), `scraper` (page-by-page crawl), `scraper-leads` (Google Maps), `caddy` (reverse proxy + auto-TLS).

## Brzo pokretanje (lokalno, dev)

### Preduslovi
- Node.js 20+
- Python 3.11+
- Docker (opciono, za produkciju)

### 1. Kloniraj i instaliraj

```bash
git clone <repo> outreach && cd outreach
cp .env.example .env
# uredi .env — vidi sekciju "Env varijable" ispod
```

### 2. Generiši password hash za login

```bash
cd web
node -e "console.log(require('bcryptjs').hashSync('TVOJA_SIFRA', 10))"
# kopiraj hash u .env kao AUTH_PASSWORD_HASH
```

### 3. Generiši encryption key (32 bajta hex)

```bash
openssl rand -hex 32
# kopiraj u .env kao ENCRYPTION_KEY (64 hex karaktera)
```

### 4. Pokreni migracije i startuj web

```bash
cd web
npm install
npx drizzle-kit migrate
npm run dev
```

Web je na `http://localhost:3000`. Login sa šifrom iz koraka 2.

### ⚠️ Baza podataka — JEDNO mesto, JEDAN fajl

**SINGLE SOURCE OF TRUTH: `data/outreach.db`** (relativno od `web/`: `DATABASE_URL=file:../data/outreach.db`).

- Docker compose mountuje `../data` na `/data` unutar kontejnera — lokalni dev i produkcija dele **isti fajl**.
- `data/.gitkeep` je u git-u; svi `outreach.db*` su gitignored.
- **NIKAD nemoj imati `web/outreach.db`** — relativna putanja `file:./outreach.db` u `.env` pravi NOVI prazan SQLite na tom mestu i tihi gubitak je neizbežan. Ako se `web/outreach.db*` ikad pojavi, obriši ga i restartuj server.
- `web/.env` (tvoj lokalni) ima `DATABASE_URL=file:../data/outreach.db` — to je ispravno.
- Backup: kopiraj `data/outreach.db` (i `-shm`/`-wal` ako postoje). WAL restore: sve tri kopije zajedno na isto mesto.

### 5. (Opciono) Pokreni scraper lokalno

```bash
cd scraper
python3.11 -m venv .venv
.venv/bin/pip install -r pyproject.toml
.venv/bin/playwright install chromium
DATABASE_PATH=/putanja/do/data/outreach.db \
SCREENSHOTS_DIR=/putanja/do/data/screenshots \
.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8001
```

### 6. (Opciono) Pokreni scraper-leads (Google Maps)

```bash
cd scraper-leads
uv sync
uv run playwright install chromium
RUNS_DIR=/putanja/do/data/scraper-runs \
uv run uvicorn maps_cold_calling.api:app --host 127.0.0.1 --port 8002
```

**Napomena o Python verziji**: `pyproject.toml` zahteva `>=3.12`, ali lokalno može i 3.11 ako ga izmeniš u `>=3.11`. CI/CD koristi 3.12.

## Produkcija (Docker)

```bash
# 1. Popuni .env (vidi ispod)
# 2. Build + start
docker compose up -d --build

# Web je na https://localhost (Caddy self-signed)
# ili postavi pravi domen u Caddyfile za Let's Encrypt
```

Prvo pokretanje kreira `data/outreach.db` i automatski seed-uje:
- 10 default statusa (Novi, Zovem, Zvao sam, Javio se, Nije se javio, Dogovoren sastanak, Odgovorio, Klijent, Odbijen, Ne kontaktiraj)
- 4 default prompta (email personalizacija, vizuelna ocena, SEO sumar, AI asistent)
- 1 korisnik (iz `AUTH_PASSWORD_HASH` env)

## Env varijable

### Baza
- `DATABASE_URL` — `file:/data/outreach.db`

### Auth
- `AUTH_PASSWORD_HASH` — bcrypt hash jedinog korisnika
- `AUTH_SECRET` / `NEXTAUTH_SECRET` — random string (32+ bajtova)
- `AUTH_TRUST_HOST=true` — ako app ide iza reverse proxy-ja
- `NEXTAUTH_URL` — puni URL app-a

### Enkripcija
- `ENCRYPTION_KEY` — 64 hex karaktera (32 bajta) za AES-256-GCM šifre sendera

### Scraper
- `SCRAPER_URL` — `http://scraper:8001` (u docker compose) ili `http://127.0.0.1:8001` (lokalno)
- `SCRAPER_LEADS_URL` — `http://scraper-leads:8002` (docker) ili `http://127.0.0.1:8002` (lokalno)

### MiniMax M3
- `MINIMAX_API_KEY` — tvoj token
- `MINIMAX_BASE_URL` — `https://api.minimax.io/v1` (default)
- `MINIMAX_MODEL` — `MiniMax-M3` (default)

### IMAP (reply tracking)
- `IMAP_HOST`, `IMAP_PORT`, `IMAP_USER`, `IMAP_PASSWORD`, `IMAP_FOLDER`
- `IMAP_POLL_MINUTES` — default 5

### Slanje
- `DEFAULT_SENDER_HOURLY_CAP` (10), `DEFAULT_SENDER_DAILY_CAP` (50)
- `SEND_WINDOW_START` (09:00), `SEND_WINDOW_END` (17:00)
- `SEND_WINDOW_TZ` (Europe/Belgrade), `SEND_WINDOW_DAYS` (mon-fri)

### Unsubscribe
- `UNSUBSCRIBE_BASE_URL` — puni URL app-a (npr. `https://outreach.tvojdomen.rs`)

### Scheduler (opciono)
- `SCHEDULER_ENABLED=1` ili `ENABLE_WORKER=1` — pokreni worker u dev modu
- `SCHEDULER_TICK_MS` — override tick intervala (default 60000ms)

## DNS / domen (korisnikovo)

Pre slanja u produkciju:

1. **SPF:** `v=spf1 include:_spf.<tvoj-provajder> ~all` (zavisi od SMTP provajdera)
2. **DKIM:** generiše provajder (Google Workspace / Mailgun / Resend)
3. **DMARC:** `v=DMARC1; p=quarantine; rua=mailto:dmarc@tvojdomen.rs`
4. Setup **warmup**: kreni sa 5/dan po aliasu, linearno do `daily_cap` tokom 2–4 nedelje

Aplikacija ne može da konfiguriše DNS — to je tvoj zadatak.

## Backup

Preporučeno: dnevni `sqlite3 .backup` van VPS-a:

```bash
# /etc/cron.daily/outreach-backup
sqlite3 /data/outreach.db ".backup /backups/outreach-$(date +%F).db"
# sinhronizuj /backups na Backblaze B2 / S3 / rsync
```

## Struktura projekta

```
outreach/
├── docker-compose.yml          # web + scraper + scraper-leads + caddy
├── Caddyfile
├── .env.example
├── SESSION-SUMMARY.md           # handoff za nastavak sesije
├── web/                         # Next.js 16 (App Router) + TS + shadcn/ui
│   ├── src/
│   │   ├── app/                 # rute + API
│   │   ├── components/          # UI komponente (shadcn/ui + custom)
│   │   └── lib/                 # db, minimax, auth, email, ai, scraping, workers
│   │       ├── settings.ts      # DB-backed runtime settings
│   │       ├── activity-store.tsx # ActivityPanel + global job tracker
│   │       ├── audit.ts         # audit_log helperi
│   │       └── dashboard.ts     # getCallTodo() helper
│   ├── drizzle/                 # generisane migracije
│   └── Dockerfile
├── scraper/                     # Python FastAPI (page-by-page crawl)
│   ├── app/
│   │   ├── main.py              # /scrape, /scrape/bulk, /scrape/status/{jobId}
│   │   ├── sitemap_parser.py
│   │   ├── page_scraper.py      # httpx + trafilatura + extruct + lxml
│   │   ├── screenshot.py        # Playwright (v2: domcontentloaded + analytics blokada)
│   │   ├── categorize.py
│   │   ├── seo_metrics.py
│   │   └── db.py                # piše u isti SQLite fajl
│   └── Dockerfile
└── scraper-leads/               # Python FastAPI (Google Maps + v3 progress events)
    ├── src/maps_cold_calling/
    │   ├── api.py               # FastAPI wrapper, --progress-file
    │   ├── enrich.py            # /enrich-lead fuzzy Google Maps lookup
    │   ├── progress.py          # ProgressEvent, ProgressEmitter (v3)
    │   ├── changelog_api.py     # /scrape-leads/changelog
    │   ├── scraper/maps_search.py  # v2: 30s idle, 4 scroll mehanizma
    │   ├── runner.py             # emituje progress events
    │   └── cli.py                # --progress-stdout, --progress-file
    └── Dockerfile                # mcr.microsoft.com/playwright/python:v1.61.0-jammy
```

## API pregled

- `GET /api/campaigns`, `POST /api/campaigns`, `PATCH/DELETE /api/campaigns/[id]`
- `GET /api/leads` (filteri: status, hasEmail, noWebsite, hasPhone, lowScore, city, search, **hasScreenshot**), `GET/PATCH/DELETE /api/leads/[id]`
- `POST /api/leads/[id]/comments`
- `POST /api/leads/[id]/enrich` — Google Maps fuzzy lookup, popunjava reviews_count/google_rating
- `POST /api/leads/bulk` (bulk akcije: setStatus, blocklist, unblock, delete)
- `POST /api/leads/bulk-jobs` (header `X-Bulk-Action: scrape|analyze`) — bulk sekvencijalni scrape/analyze
- `GET /api/leads/bulk-jobs/{jobId}` — bulk job progress
- `DELETE /api/leads/bulk-jobs/{jobId}` — cancel bulk job
- `POST /api/import` (preview), `POST /api/import/commit`
- `GET /api/statuses`
- `POST /api/scrape`, `GET /api/scrape/status/[jobId]` (proxy ka port 8001)
- `POST /api/analyze/[leadId]` (M3 vizuelna + SEO ocena; auto-trigger scrape ako nema screenshota)
- `POST /api/scrape-leads` (start Google Maps job), `GET /api/scrape-leads/status/[jobId]`, `GET /api/scrape-leads/progress/[jobId]`, `POST /api/scrape-leads/import/[jobId]` (parsiraj CSV), `POST /api/scrape-leads/import` (write u leads), `GET /api/scrape-leads/changelog`
- `GET /api/prompts`, `POST /api/prompts`, `PATCH/DELETE /api/prompts/[id]`
- `POST /api/email/generate` (lead → draft), `POST /api/email/generate-bulk` (campaign → drafts)
- `PATCH/DELETE /api/email/drafts/[id]`, `POST /api/email/drafts/[id]/approve` (draft → queued)
- `GET /api/queue?status=...`
- `GET /api/senders`, `POST /api/senders`, `PATCH/DELETE /api/senders/[id]`, `POST /api/senders/[id]` (test send)
- `GET /api/inbox`, `POST /api/admin/imap-poll`
- `GET /api/sequences?campaignId=`, `POST /api/sequences`, `POST /api/sequences/steps`, `DELETE /api/sequences/steps/[id]`
- `POST /api/ai/chat` (function calling), `GET /api/ai/chat`
- `GET /api/settings/save` (lista), `POST /api/settings/save` (izmene), `GET /api/settings/auto-screenshot`
- `POST /api/settings/test-minimax`, `POST /api/settings/test-imap`
- `GET /api/audit?leadId=&entity=lead` — audit log
- `POST /api/admin/tick` (ručno pokreni scheduler tick — za testiranje)
- `GET /api/unsubscribe?id=&token=` (HMAC token, bez auth)

## Bezbednost

- Auth: NextAuth credentials, bcrypt, JWT sesija u HttpOnly Secure kolačiću
- SMTP šifre: AES-256-GCM enkripcija (ključ iz env)
- IMAP šifra i MiniMax ključ: samo u env, nikad u bazi
- CSRF: NextAuth built-in
- Unsubscribe: HMAC token (bez auth)
- Middleware: štiti sve osim `/login`, `/api/auth/*`, `/api/unsubscribe`

## Razvoj

```bash
# Typecheck
cd web && npm run typecheck

# Lint
cd web && npm run lint

# Build (testira SSR)
cd web && npm run build

# Generiši novu migraciju posle izmene schema.ts
cd web && npx drizzle-kit generate
cd web && npx drizzle-kit migrate
```

## Licenca

Privatno.

## Handoff

Kompletna dokumentacija sesije + poznati issue-i u `SESSION-SUMMARY.md`. Za nastavak rada pročitaj prvo taj fajl, pa `web/src/lib/settings.ts` (centralni runtime settings), `web/src/lib/activity-store.tsx` (ActivityPanel) i `scraper-leads/src/maps_cold_calling/api.py` (FastAPI wrapper).